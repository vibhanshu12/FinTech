# -*- coding: utf-8 -*-
"""
Created on Mon Jun  7 21:41:53 2021

@author: Vibhanshu Jain
"""


"""
Created on Wed Feb 24 19:44:50 2021

@author: Jain Vibhanshu
"""
"""
Spyder Editor

This is a temporary script file.
"""
'''
MODULE 3 - Reads the finalised list of data from Module 2 and models the application

'''
import yaml
import os
import pandas as pd
import numpy as np
import glob
import statistics
import time
from functools import reduce
import datetime
from datetime import timedelta
from datetime import datetime
from statsmodels.stats.outliers_influence import variance_inflation_factor

import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.feature_selection import VarianceThreshold
from sklearn.metrics import explained_variance_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split, ParameterGrid
from sklearn.model_selection import TimeSeriesSplit
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold
import statsmodels.api as sm
from sklearn.feature_selection import VarianceThreshold


import pickle
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, roc_auc_score, confusion_matrix, roc_curve, auc, mean_squared_error, log_loss, precision_recall_curve, classification_report, precision_recall_fscore_support

from sklearn.svm import SVC


pd.options.display.max_columns = None


#%matplotlib notebook
import matplotlib.pyplot as plt
#plt.style.use('seaborn-whitegrid')

pd.options.display.max_columns = None
#pd.set_option('display.float_format', '{:.2f}'.format)

# =============================================================================
# root=os.getcwd()
# with open(root+ '\config\config_feature_engineering.yaml') as file:
#     config = yaml.full_load(file)
# =============================================================================
config2={    
   
    "REPO_PATH": r'C:\Users\vishwesh kumar\Videos\LIC',  
    "EXPLORATORY_REPORTS": r'\reports',
    "VIF_THRES": 5,
    "MODEL_DATA": r'\Processed Data',
    "INPUT_DATA_CONSOLIDATED": r'C:\Users\vishwesh kumar\Videos\LIC\Raw Data UW\IHL.csv',
    "INPUT_DATA_CONSOLIDATED_LAP":  r'C:\Users\vishwesh kumar\Videos\LIC\Raw Data UW\LAP.xlsx',
    "INPUT_DATA_SHEETNAME" : r'IHL',
    "TIDY_DATES": ['SANCTION_DATE','FIRST_DISB_DATE','EMISTARTDATE'],    
    "START_DATE": r'01-01-2013',#DD-MM-YYYY
    "END_DATE": r'31-03-2018', #DD-MM-YYYY
   
    "ID_VAR": ['COMP_APPL_ID'],
    "DROP_LIST": [],
    "OBJ_LIST": ['COMP_APPL_ID'],
    "PIPELINE" : 'train',
   
   
    "TARGET_VAR": 'loan',
    "MODEL_REPORTS": '/reports',
   
   
    "KEEP_LIST": [],
    "PIPELINE": "train",    
    "VALIDATION_SPLIT": 5,
    "TEST_SPLIT": 2,
    "PROCESSORS": -1,
    "MODEL": 'LogisticRegression',
    # TODO: simulate through various threshold parameter to optimize accuracy  - AUC, GINI, Precision vs Recall
    "DEFAULT_PROB_THRESHOLD": 0.5
   
}

#Helper Function



def compute_time(start_time,name):
  """
  Compute the time taken to complete an action
  """

  new_time = time.time()
  delta =  datetime.fromtimestamp(new_time - start_time).strftime("%M:%S")
  print('\n')
  print('------------------------------')
  print(name,':',delta)
  print('------------------------------')
  return new_time
 
 
def save_csv_local(df, filename):
  """
  Save file as csv
  """
  df.to_csv(filename,  compression="gzip", index=False)


def make_dir(config,report_type):  
    """
    make directory based on the report type parameter
    """

    directory=os.path.join(config['REPO_PATH']+report_type+"/report_"+ datetime.today().strftime('%d-%m-%Y'))
    if not os.path.exists(directory):
        os.makedirs(directory)
   
    return directory

def read_data(regex,file_type):
    df = pd.DataFrame()
   
    for f in glob.glob(regex):
        # read files f
        if (file_type=="csv"):
            interm = pd.read_csv(f)          
        elif (file_type=="parquet"):
            interm=pd.read_parquet(f, engine='fastparquet')
        elif (file_type=="text"):
            interm=pd.read_csv(f, sep='|')  
       
        interm.drop(interm.tail(2).index,inplace=True)
        df = pd.concat([df, interm])

    return df

def read_latest_data(regex,filetype):
    list_of_files = glob.glob(regex)
    latest_model_data = max(list_of_files, key=os.path.getctime)
    model_df=read_data(latest_model_data,filetype)

    return model_df

def convert_datatypes(model_df,config):
    """
    Preprocess data to convert datatypes of specified columns
    Inputs:     model_df            = dataframe that columns need to be converted
                config              = yaml file containing all config settings
    output:     model_df            = dataframe with converted datatypes
    """
   
    model_df[config['OBJ_LIST']] = model_df[config['OBJ_LIST']].astype(str)
    model_df=model_df.drop(config['DROP_LIST'],axis=1)
   
   
    return model_df



# =============================================================================
# Helper Functions - ML
# =============================================================================
def prepare_model_data(data_noot_woe, config):
    """
    Read the latest generated model data as part of the ML pipeline
    Inputs      : model_df          = dataframe from which predictor and
                                        target variables can be extracted
                : config            = list of ID columns and name of target variable
    outputs     : model_df          = two data frames with preditor and target variable separately
    """
   
   
    model_df_raw=data_noot_woe.copy()
   
    X=model_df_raw.drop(config2['TARGET_VAR'], axis=1)
    X=X.drop(config2['ID_VAR'], axis=1)
   

    y=data_noot_woe[config2['TARGET_VAR']]
    return X,y

def create_dummies(X,config2):
    """
    Create dummy variables for all the categorical predictor variables

    Inputs      : X                 = dataframe with predictor variables
    outputs     : X                 = data frame with categorical columns converted to dummy data
    """
    X = pd.get_dummies(X)

    if config['PIPELINE']!="train":
        #add any additional list of features to the test data:
        #read relevant latest features
        regex=os.path.join(config2['REPO_PATH']+config2['MODEL_FILE']) + '/*'
        list_of_files = glob.glob(regex)
        latest_model_data = max(list_of_files, key=os.path.getctime)
        latest_model_data = latest_model_data[-10:]
        regex = regex[:-1] + latest_model_data +"/*"
        list_of_files = glob.glob(regex)
        r = "features_" + config2['TARGET_VAR'][0]
        list_of_files = [s for s in list_of_files if r in s]
        list_of_files[0] = list_of_files[0].replace("\\","/")
        feature_list = pd.read_pickle(list_of_files[0])
       
        X=pd.concat([X, pd.DataFrame(columns=list(feature_list))], sort=False)
        X=X.fillna(0)
        X=X[feature_list]
   
        return X

def initiate_param_grid():
    """
    TO BE PUT UNDER CONFIG
    Parameter grid for hyperparameter tuning the model
    """
# =============================================================================
#     n_estimators = [int(x) for x in np.linspace(start=50, stop=60, num=1)]
#     min_samples_split = [int(x) for x in np.linspace(start=150, stop=250, num=2)]
#     min_samples_leaf = [int(x) for x in np.linspace(start=60, stop=100, num=1)]
#     max_depth = [int(x) for x in np.linspace(start=4, stop=10, num=1)]
#     max_features = ['sqrt']
#     subsample = [x for x in np.linspace(start=0.5, stop=1.0, num=1)]
# =============================================================================

# =============================================================================
#     param_grid = {'C': [0.01, 0.1, 1],
#                   'solvers' : ['liblinear', 'saga'],
#                   'penalty' : ['l1','l2'],
#                   'class_weight' : ['balanced',{0:1,1:5},{0:1,1:10}]
#                 }
#    
# =============================================================================
    param_grid = [{'C': [0.01, 0.1, 1],'class_weight' : ['balanced',{0:1,1:5},{0:1,1:10}],
                     'penalty': ['l2'],
                     'solver': ['newton-cg','liblinear', 'lbfgs'],
                     },
                    {'C': [0.01, 0.1, 1],'class_weight' : ['balanced',{0:1,1:5},{0:1,1:10}],
                     'penalty': ['l1'],
                     'solver': ['liblinear']},
                     {'C': [0.01, 0.1, 1],'class_weight' : ['balanced',{0:1,1:5},{0:1,1:10}],
                     'penalty': ['none'],
                     'solver': ['newton-cg','liblinear', 'lbfgs'],
                     },]
   

    return param_grid

def build_model(X_train, y_train, param_grid, config):
    """
    Model hyperparameter tuning: Iterate through grid search cv parameters to
    find the best fit for the regressor model

    Inputs: X_train    = matrix with list of predictor variables to be used in the
                         predictive model
          : y_train    = target variable column
          : param_grid = hyperparameter tuning grid search cv initialization
          : config

    Output: model      = trained model with the best accuracy obtained from GridSearch CV
    """


   
   

    #import statsmodels.api as sm
    # Model Building - The most simple approach
   
    # Create an instance of LogisticRegression()
    lr = LogisticRegression(class_weight = 'balanced')#after validation & tuning
    #lr = LogisticRegression(C=1e-05,class_weight = {0:1,1:8.8},penalty='l2', solver ='liblinear')#after validation & tuning
    model = lr.fit(X_train, y_train)
    return model

def build_model_tuned(model,X_train, y_train, param_grid, config):
    """
    Model hyperparameter tuning: Iterate through grid search cv parameters to
    find the best fit for the regressor model

    Inputs: X_train    = matrix with list of predictor variables to be used in the
                         predictive model
          : y_train    = target variable column
          : param_grid = hyperparameter tuning grid search cv initialization
          : config

    Output: model      = trained model with the best accuracy obtained from GridSearch CV
    """


   
   

    #import statsmodels.api as sm
    # Model Building - The most simple approach
   
    # Create an instance of LogisticRegression()
    #lr = LogisticRegression(class_weight = 'balanced')#after validation & tuning
    #lr = LogisticRegression(C=1e-05,class_weight = {0:1,1:8.8},penalty='l2', solver ='liblinear')#after validation & tuning
    model = model.fit(X_train, y_train)
    return model

## Temp



def save_model(model, config):
    """
    Save the trained model as a pickle file

    Inputs: model = model with best accuracy measures
    Output: pickle file of the model saved in local repository

    TODO: make directory name construction generic for different model configurations
    """
    directory = make_dir(config,(config['MODEL_FILE']))
   
    filepath = directory + "/model" + ".pkl"
    with open(filepath, 'wb') as file:
        pickle.dump(model, file)
       
def get_feature_importance(model, X, config, iteration):
    """
    get the list of feature importance from the trained model
    Inputs      : model             = model with best accuracy measures
                  X                 = final data set used for training
                  config            = config files specifying where to save model accuracy reports
                  iteration         = automated generated variable to track the Nth iteration of the
                                        test set
    Outputs     : feature importance file of the model saved in local repository
    """

    variable_importance=(pd.DataFrame(model.best_estimator_.feature_importances_, index=X.columns))

    #save feature importance to local
    directory = make_dir(config,(config['MODEL_REPORTS']+"/model_reports/"))
    filepath=directory + "/feature_importance_iteration_"+str(iteration)+".csv"
    variable_importance.to_csv(filepath)
   
    return variable_importance

def save_features(feature_list,config):
    """
    save the list of features used in model training as a pickle file
    Inputs      : feature_list      = features of the model with best accuracy measures
    Outputs     : pickle file of the feature list saved in local repository
    """

    directory = make_dir(config,(config['MODEL_FILE']))
    filepath=directory + "/features"+".pkl"
    with open(filepath, 'wb') as file:
        pickle.dump(feature_list, file)
       
def save_reports(model_stats_df,config):
    """
    save model statistics reports for each test set split(iteration)
    """
    directory = make_dir(config,(config['MODEL_REPORTS']+"/model_reports/"))
    filepath=directory + "/model_statistics.csv"
    model_stats_df.to_csv(filepath)
   
def get_prediction(model,X_test):
    """
    get the predictions on test data set from the trained model with best accuracy
    Inputs      : model             = model with best accuracy measures
                  X_test            = predictor variables for the test data set for making predictions
    Outputs     : y_pred            = predicted ETA for the test data set using the passed model
    """
    #y_prob=model.predict_proba(X_test)
   
    prob_1=model.predict(X_test)
    prob_0=1-prob_1
    y_prob=pd.DataFrame()
    y_prob['0']=prob_0
    y_prob['1']=prob_1
    y_prob=y_prob.to_numpy()
    return y_prob


def lift_plot_model(ytest, yprob,iteration):
    """
    Plot Lift Chart and table
    Inputs       : ytest             = actual churn (1/0) classification
                   yprob             = predicted churn probability
    Output       : Lift Chart

    """
    n_bins = 10

    actual_ser = pd.Series(ytest).rename('actuals').reset_index()
    proba_ser = pd.Series(yprob).rename('probabilities').reset_index()

    # Join table and drop indicies
    lift_table = pd.concat([actual_ser, proba_ser], axis=1).fillna(0)
    actual_col = 'actuals'

    probability_col = 'probabilities'

    lift_table.sort_values(by=probability_col, ascending=False, inplace=True)

    rows = []

    # Split the data into the number of bins desired.
    for group in np.array_split(lift_table, n_bins):
        score = group[(group[actual_col] == 1)][actual_col].sum()

        rows.append({'NumCases': len(group), 'NumCorrectPredictions': score})

    lift = pd.DataFrame(rows)
    #Cumulative Gains Calculation
    lift['RunningCompleted'] = lift['NumCases'].cumsum() - lift['NumCases']

    lift['PercentCorrect'] = lift['NumCorrectPredictions'].cumsum() / \
    lift['NumCorrectPredictions'].sum() * 100

    lift['AvgCase'] = lift['NumCorrectPredictions'].sum() / len(lift)
    lift['CumulativeAvgCase'] = lift['AvgCase'].cumsum()
   
    #Lift Chart
    lift['LiftLine'] = 1
    lift['Lift'] = lift['NumCorrectPredictions'] / lift['AvgCase']

    plt.plot(lift['Lift'], label= 'Response rate for model');

    plt.plot(lift['LiftLine'], 'r-', label='Normalised \'response rate\' \
    with no model');

    plt.xlabel(str(100/len(lift)) + '% Increments');
    plt.ylabel('Lift');
    plt.legend();
    plt.title("Lift Chart");
    directory = make_dir(config2,(config2['MODEL_REPORTS']+"/model_reports/"))
    filepath=directory + "/lift_plot_iteration"+str(iteration)+".png"
    plt.savefig(filepath)
    plt.close()
   
    return lift


def plot_roc(ytest_roc,yprob_roc,iteration):
        """
        Plot ROC curve
        Inputs       : ytest             = actual churn (1/0) classification
                       yprob             = predicted churn probability
        Output       : Lift Chart

        """
        fig = plt.figure(1, figsize=(6, 6));

        false_positive_rate, true_positive_rate, thresholds = \
        roc_curve(ytest_roc, yprob_roc)
        roc_auc = auc(false_positive_rate, true_positive_rate)

        plt.title("Receiving Operator Characteristic");
        plt.plot(false_positive_rate, true_positive_rate, 'b', \
        label='AUC = %0.2f' % roc_auc);
        plt.legend(loc='lower right');
        plt.plot([0,1], [0,1], 'r--');
        plt.xlim([-0.1, 1.2]);
        plt.ylim([-0.1, 1.2]);
        plt.ylabel("True Positive Rate");
        plt.xlabel("False Positive Rate");
        plt.tight_layout();
       
        directory = make_dir(config2,(config2['MODEL_REPORTS']+"/model_reports/"))
        filepath=directory + "/ROC_curve"+str(iteration)+".png"
        plt.savefig(filepath)
        plt.close()


       

def print_model_stats(ref_name, threshold, prob_test, prob_train, ytest, ytrain):
   
    pred_test  = (prob_test [:,1] >= threshold).astype('int')
    pred_train = (prob_train [:,1]>  threshold).astype('int')

    ## Calculate AUC
    auc_score  = roc_auc_score(ytest, prob_test[:,1])
    train_acc = accuracy_score(ytrain.values.ravel(), pred_train)
    test_acc  = accuracy_score(ytest.values.ravel(), pred_test)
    log_loss_value = log_loss(ytest, prob_test[:,1],eps=1e-15, normalize=True)
    gini=(2*auc_score)-1
    conf_matrix   = confusion_matrix(ytest.values.ravel(), pred_test)
    tn, fp, fn, tp = conf_matrix.ravel()
    precision=tp/(tp+fp)
    recall=tp/(tp+fn)
    f1_score=(2*precision*recall)/(precision+recall)
    train_sample=len(ytrain)
    test_sample=len(ytest)
   


    dfObj = pd.DataFrame(columns=['Iteration_index', 'Train_sample','Test_sample','TP', 'FP','FN','TN',
                                 'Train_acc',
                                'Test_acc', 'Precision','Recall','F1-Score','AUC','GINI','Log_loss'])
    dfObj = dfObj.append({'Iteration_index': ref_name,'Train_sample':train_sample ,'Test_sample':test_sample,'TP': tp,
                          'FP': fp,'FN':fn,'TN':tn,
                         'Train_acc': train_acc,
                        'Test_acc':test_acc,'Precision':precision, 'Recall':recall,'F1-Score':f1_score,
                          'AUC': auc_score,'GINI':gini ,'Log_loss': log_loss_value,}, ignore_index=True)

    lift_table = lift_plot_model(ytest, prob_test[:,1],ref_name)
    plot_roc(ytest, prob_test[:,1],ref_name)
   
   
   
    return dfObj,lift_table

def identify_correlation(model_df, config):
    """
    Identify multi collinearity in a dataframe
    Plot correlation matrix
    """
    #identify only numeric datatypes
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    model_df = model_df.select_dtypes(include=numerics)

    #calculate correlation matrix
    corr = model_df.corr()

    # Generate a mask for the upper triangle
    mask = np.triu(np.ones_like(corr, dtype=np.bool))

    # Set up the matplotlib figure
    f, ax = plt.subplots(figsize=(20, 9))

    # Generate a custom diverging colormap
    cmap = sns.diverging_palette(220, 10, as_cmap=True)

    # TODO: make name construction more generic for future model configurations
    directory = make_dir(config,(config['EXPLORATORY_REPORTS']+"/exploratory_analysis/"))
    filepath = directory + "/correlation_plots_pre_model_build.png"

    # Draw the heatmap with the mask and correct aspect ratio
    img = sns.heatmap(corr, mask=mask, cmap=cmap, vmax=1, vmin=-1, center=0,
                      square=True, linewidths=.5, cbar_kws={"shrink": .5})
    img.figure.savefig(filepath)
   
    corr.to_csv(directory + "/correlation_matrix_pre_model_build.csv")

config={    
   
    "REPO_PATH": r"C:\Users\vishwesh kumar\Videos\LIC",    
    "MODEL_DATA_SAL": r"\Processed Data\salaried",
    "MODEL_DATA_SELF": r"\Processed Data\self",
    "EXPLORATORY_REPORTS": r'\reports',
    "SALARIED_DATA": r'model_train_data_sal',
    "SELF_EMPLOYED_DATA":r'model_train_data_self',
   
    "TARGET_VAR": r'loan',
    "ID_VAR": ['COMP_APPL_ID'],
    "DROP_LIST": [],
    "OBJ_LIST": ['loan','COMP_APPL_ID'],
   
    "VIF_THRES": 5,
    "TEST_SPLIT":2
   
}    
def calculate_vif(model_df,config):    
   
    dropped_cols=list()
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    df = model_df.select_dtypes(include=numerics)
    variables = list(range(df.shape[1]))
    directory = make_dir(config,(config['EXPLORATORY_REPORTS']+"/exploratory_analysis/"))
    filepath = directory + "/VIF_pre_model_build.csv"
   
    dropped = True
    while dropped:
        dropped = False
        vif = [variance_inflation_factor(df.iloc[:, variables].values, ix)
               for ix in range(df.iloc[:, variables].shape[1])]

        maxloc = vif.index(max(vif))
        if max(vif) > config['VIF_THRES']:
            print('dropping \'' + df.iloc[:, variables].columns[maxloc] + '\' at index: ' + str(maxloc))
            dropped_cols.append(df.iloc[:, variables].columns[maxloc])
            del variables[maxloc]
            dropped = True
   
    variable_list=pd.DataFrame(df.columns[variables])
    dropped_cols=pd.DataFrame(dropped_cols)
    variable_list.to_csv(directory + "/VIF_final_pre_model_build.csv")
    dropped_cols.to_csv(directory + "/VIF_dropped_pre_model_build.csv")

from scipy import stats
def ks_score(y, y_pred):
    # y_pred = estimator.predict_proba(X)[:, 1]
    ks = stats.ks_2samp(y_pred[y == 0], y_pred[y == 1]).statistic
    return ks  

def variance_threshold_selector(data, threshold=0.5):
    # https://stackoverflow.com/a/39813304/1956309
    selector = VarianceThreshold(threshold)
    selector.fit(data)
    return data[data.columns[selector.get_support(indices=True)]]

def calc_vif_one_shot(df):
    # Calculating VIF
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    df = df.select_dtypes(include=numerics)
    vif = pd.DataFrame()
    vif["variables"] = df.columns
    vif["VIF"] = [variance_inflation_factor(df.values, i) for i in range(df.shape[1])]
    return(vif)

def get_ks_decile_chart(model, X_test, y_test, iteration,X_train_cols):
    y_pred = model.predict(X_test[X_train_cols])
    y_pred=np.where(y_pred>0.5,1,0)

#    y_prob_test = model.predict_proba(X_test)[:,1]
    prob_1=model.predict(X_test[X_train_cols])
    prob_0=1-prob_1
    y_prob=pd.DataFrame()
    y_prob['0']=prob_0
    y_prob['1']=prob_1
    y_prob=y_prob.to_numpy()
    y_prob_test = y_prob
# =============================================================================
#     conf_mat = confusion_matrix(y_test.values.ravel(), y_pred)
#     print("% of False Positive: {}".format(conf_mat[0][1]*100/(conf_mat[0][0] + conf_mat[0][1] + conf_mat[1][0] + conf_mat[1][1])))
#    
#     print("% of False Negative: {}".format(conf_mat[1][0]*100/(conf_mat[0][0] + conf_mat[0][1] + conf_mat[1][0] + conf_mat[1][1])))
#    
# =============================================================================
    #KS
    ks_df = pd.DataFrame(data={'Actual Value': y_test.values.ravel(),
                                     'Predicted Value': y_pred,
                                     'Probability': y_prob_test[:,1]})
    ks_df.head()
    ks_df.reset_index(inplace=True)
    ks_df.drop(columns='index', axis=1, inplace=True)
    ks_df.sort_values(by='Probability', ascending=False, inplace=True)
    ks_df['rank'] = ks_df['Probability'].rank(method='first')
    ks_df['decile'] = pd.qcut(ks_df['rank'].values, 10).codes
    #ks_df['decile'] = pd.qcut(ks_df['Probability'],10,labels=['1','2','3','4','5','6','7','8','9','10'])
    #
    #ks_df.columns = ['Defaulter','Probability','Decile']
    #
    ks_df.columns = ['Actual Value', 'Predicted Value', 'Probability', 'rank', 'decile']
    #
    #
    ks_df['Actual Value'] = ks_df['Actual Value'].astype(int)
    ks_df['Non_Actual_Value'] = 1-ks_df['Actual Value']
    #
    df1 = pd.pivot_table(data=ks_df,index=['decile'],values=['Actual Value', 'Non_Actual_Value', 'Probability'],
                          aggfunc={'Actual Value':[np.sum],
                                   'Non_Actual_Value':[np.sum],
                                   'Probability' : [np.min,np.max]})
    df1 = df1.reset_index()
    df1.columns = ['decile','Actual_Count','Non-Actual_Count','max_score', 'min_score']
    df1['Total Cust'] = df1['Actual_Count'] + df1['Non-Actual_Count']
    df2 = df1.sort_values(by='min_score',ascending=False)
    #
    #
    df2['Actual_Rate'] = (df2['Actual_Count'] / df2['Total Cust']).apply('{0:.2%}'.format)
    default_sum = df2['Actual_Count'].sum()
    non_default_sum = df2['Non-Actual_Count'].sum()
    df2['Actual %'] = (df2['Actual_Count']/default_sum).apply('{0:.2%}'.format)
    df2['Non_Actual %'] = (df2['Non-Actual_Count']/non_default_sum).apply('{0:.2%}'.format)
    df2['ks_stats'] = np.round(((df2['Actual_Count'] / df2['Actual_Count'].sum()).cumsum() -(df2['Non-Actual_Count'] / df2['Non-Actual_Count'].sum()).cumsum()), 4) * 100
    df2['ks_stats'] = df2['ks_stats'].round(2)
#    directory = make_dir(config2,(config2['MODEL_REPORTS']+"/model_reports/"))
#    filepath=directory + "/model_statistics_ks_stats_" + config2['TARGET_VAR'][0]+ ".csv"
#    df2.to_csv(filepath)
    return df2

def calc_psi_on_woe_bins(X_train_cols,X_train,X_test):
    for idx, i in enumerate(X_train_cols):
        if idx==0:
            df_concat = pd.DataFrame(columns=['Value','Count','Column_name','Count2'])
        df_temp=pd.DataFrame()
        df_temp['Value']=X_train[i].value_counts(dropna=False).to_frame().index
        df_temp['Count']=X_train[i].value_counts().to_frame()[i].values
        df_temp['Column_name']=str(i)
        df_temp=df_temp.round(2)
        print(df_temp)
        df_temp2=pd.DataFrame()
        df_temp2['Value']=X_test[i].value_counts(dropna=False).to_frame().index
        df_temp2['Count2']=X_test[i].value_counts().to_frame()[i].values
        df_temp2['Column_name']=str(i)
        df_temp2=df_temp2.round(2)
        print(df_temp2)
        df_temp_merged=df_temp.merge(df_temp2,how="outer", on=['Column_name','Value'])
        df_temp_merged=df_temp_merged.drop_duplicates()
        df_concat=pd.concat([df_concat, df_temp_merged])
    df_concat['Count_perc']=df_concat['Count']/X_train.shape[0]
    df_concat['Count_perc2']=df_concat['Count2']/X_test.shape[0]
    df_concat['Count_perc_diff']=df_concat['Count_perc']-df_concat['Count_perc2']
    df_concat['Count_perc_ratio']= df_concat['Count_perc'] / df_concat['Count_perc2']
    df_concat['ln_Count_perc_ratio']= np.log(df_concat['Count_perc_ratio'].astype('float'))
    df_concat['psi']= df_concat['Count_perc_diff']*df_concat['ln_Count_perc_ratio']
    df_op=df_concat[['Column_name','psi']].groupby('Column_name').sum()
    return df_op,df_concat

def train_model(data_train_woe, data_test_woe, data_oot_woe, config2):
    """
    Wrapper to train the model on different iterations of train and test data set

    Inputs: X            = Model prepped data frame with predictor variables
            y            = Model prepped data frame with only target variable
            model_df     = Model raw data frame with no features excluded
            config       = config with local repo address to save the reports

    Output: Lookalike Model trained and model accuracy reports generated on various iterations of the
                    test data set
    """
    model_stats_df=pd.DataFrame()
    model_stats_df_oot=pd.DataFrame()
    model_stats_df_train=pd.DataFrame()

    X_train=data_train_woe.drop(columns=[config2['TARGET_VAR'],config2['ID_VAR'][0]])
    X_test=data_test_woe.drop(columns=[config2['TARGET_VAR'],config2['ID_VAR'][0]])
    y_train=data_train_woe[config2['TARGET_VAR']]
    y_test=data_test_woe[config2['TARGET_VAR']]
    X_oot=data_oot_woe.drop(columns=[config2['ID_VAR'][0],config2['TARGET_VAR']])
    y_oot=data_oot_woe[config2['TARGET_VAR']]

# ==================variance===========================================================
    low_variance = variance_threshold_selector(X_train, 0.00000001)
    X_train.columns ^ low_variance.columns
    #LIC Sal:
    #LIC Self:

    X_train_cols=low_variance.columns.tolist()
    X_train_cols
   
    #cibil self
    psi=['L_B_Accounts_opened_in_L12m_sum','Months_since_last_30DPD_deliquency',
         'Max_deliquency_L6M_raw_woe','30DPD_instances_L12m']
    #lic self
    psi=['L_B_COMPANY_TYPE_grp_Unapproved Company_count','COMPANY_TYPE_grp']
   
    X_train_cols = [x for x in X_train_cols if x not in psi]

    #############################
   
   
    X_train[X_train_cols].isna().sum()
    included_stepwise=stepwise_selection(X_train[X_train_cols], y_train,X_train_cols)
    set(X_train_cols)-set(included_stepwise)
   
   
# ============================Stepwise CIBIL self=================================================

   
# ============================Stepwise LIC self=================================================
# 'AGE',
# 'COMPANY_TYPE_grp',
# 'GROSS_MONTHLY_OTHER_INCOME',
# 'L_B_COMPANY_TYPE_grp_Individual_count',
# 'L_B_COMPANY_TYPE_grp_Unapproved Company_count',
# 'L_B_EDUCATIONAL_QUALIFICATION_grp_HSC_count',
# 'L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count',
# 'L_B_EDUCATIONAL_QUALIFICATION_grp_SSC_count',
# 'NET_MONTHLY_INCOME',
# 'PURPOSE'
# ======================stepwiseLIC sal=======================================================
#May 10{'FEMALE_INCLUSION',
# 'L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count','LTV',
# 'Purchase_flag'}
# =============================================================================
    X_train_cols=included_stepwise
# =========================add const====================================================
    X_train['const']=1
    X_test['const']=1
    X_oot['const']=1
    X_train_cols.append('const')
#    calculate_vif(X_train[X_train_cols],config)
#    vif_dropped_5=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\reports\exploratory_analysis\report_12-05-2021\VIF_dropped_pre_model_build.csv')
#    X_train_cols = [x for x in X_train_cols if x not in vif_dropped_5['0'].values.tolist()]
# ==============================VIF===============================================
    X_train_cols=list(set(X_train_cols)-(set(X_train_cols)-set(X_train.columns)))
   
    vif=calc_vif_one_shot(X_train[X_train_cols])
   
    #lic self
    vif_drop_self=['EMI_NMI_woe']
   
    #lic sal
    vif_drop_sal=['L_B_INDUSTRY_TYPE_grp_Govt_count','loan_type_purchase_flag_woe']
   
    #cibil
    vif_drop_sal_cibil=[]
   
    vif_drop_self_cibil=['(0,29]_instance_counts','max_enquiries_Credit Card_31_to_395']
   
    X_train_cols = [x for x in X_train_cols if x not in vif_drop_self]
   
    X_train_cols.append('max_enquiries_Credit Card_31_to_395')
   
    X_train_cols=list(set(X_train_cols))
   
    vif.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\vif2.csv')
    #psi_model_var=calc_psi(X_oot[X_train_cols], X_train[X_train_cols], X_test[X_train_cols],4)
   
# ==============================p-val-drop===============================================    
    #cibil sal
    p_val_drop=['Accounts_opened_in_L12m']
   
    #cibil self
    p_val_drop=['Used Car Loan_30DPD_instances_L12M',
                'Gold Loan_30DPD_instances_L12M','max_enquiries_Auto Loan_31_to_395']

    #LIC self:
    p_val_drop=['L_B_EDUCATIONAL_QUALIFICATION_grp_SSC_count','PURPOSE_raw_woe','FEMALE_INCLUSION']
    #LIC Sal
    p_val_drop=[]

    X_train_cols = [x for x in X_train_cols if x not in p_val_drop]
    #X_train_cols.append('max_enquiries_Credit Card_31_to_395')
   
    X_train[X_train_cols].isna().sum()
##########################################MODEL FIT############################################################
    pos_coef = ['Housing Loan_30DPD_instances_L12M','Auto Loan_30DPD_instances_L12M',
                'max_enquiries_Credit Card_31_to_395']
    X_train_cols = [x for x in X_train_cols if x not in pos_coef]
   
    clashing_cols=['L_B_EDUCATIONAL_QUALIFICATION_grp_HSC_count','L_B_COMPANY_TYPE_grp_Proprietorship Firm_count']
    X_train_cols = [x for x in X_train_cols if x not in clashing_cols]
   
   
   

    log_reg = sm.Logit(y_train,X_train[X_train_cols]).fit()
    model_summary = log_reg.summary()
    model_summary
    import matplotlib.pyplot as plt
    plt.rc('figure', figsize=(12, 7))
    #plt.text(0.01, 0.05, str(model.summary()), {'fontsize': 12}) old approach
    plt.text(0.01, 0.05, str(model_summary), {'fontsize': 10}, fontproperties = 'monospace') # approach improved by OP -> monospace!
    plt.axis('off')
    plt.tight_layout()
    plt.savefig(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\model_summary2.png')
# =============================================================================
############################PSI################################################
    psi=['L_B_COMPANY_TYPE_grp_Unapproved Company_count']
    X_train_cols = [x for x in X_train_cols if x not in psi]

   
   
    psi_model_var_tt,psi_model_var_tt_raw= calc_psi_on_woe_bins(X_train_cols,X_train,X_test)
    psi_model_var_to,psi_model_var_to_raw= calc_psi_on_woe_bins(X_train_cols,X_train,X_oot)
    psi_model_var_woe=pd.DataFrame()
    psi_model_var_woe['Columns']=psi_model_var_tt.index
    psi_model_var_woe['Test']=psi_model_var_tt['psi'].values
    psi_model_var_woe['OOT']=psi_model_var_to['psi'].values
   
    psi_model_var_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\psi2.csv')
    psi_model_var_tt_raw.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\psi_test_raw2.csv')
    psi_model_var_to_raw.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\psi_oot_raw2.csv')
   
# =============================================================================
#    Initiate the parameter grid
#    param_grid = initiate_param_grid()
#    grid_search = GridSearchCV(estimator=model,param_grid=param_grid,n_jobs=-1, cv=5,scoring='roc_auc',verbose=1)
#    model = build_model_tuned(grid_search, X_train[X_train_cols], y_train, param_grid, config2)
#    print("Best: %f using %s" % (model.best_score_, model.best_params_))
#    means = model.cv_results_['mean_test_score']
#    stds = model.cv_results_['std_test_score']
#    params = model.cv_results_['params']
#    model = model.best_estimator_
# =============================================================================
   
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.ensemble import RandomForestClassifier
   
    clf = RandomForestClassifier(random_state=0)
    clf.fit(X_train[X_train_cols],y_train)
    model=clf
########################################################################################
    model=log_reg

    y_prob_train = get_prediction(model, X_train[X_train_cols])  
    y_prob_test = get_prediction(model, X_test[X_train_cols])
    y_prob_oot = get_prediction(model, X_oot[X_train_cols])  

################################################################################################
    #Save Prediction

    X_train_df=pd.DataFrame(X_train[X_train_cols])
    X_test_df=pd.DataFrame(X_test[X_train_cols])
    X_oot_df=pd.DataFrame(X_oot[X_train_cols])
   
    X_train_df['COMP_APPL_ID']=data_train_woe['COMP_APPL_ID'].values
    X_test_df['COMP_APPL_ID']=data_test_woe['COMP_APPL_ID'].values
    X_oot_df['COMP_APPL_ID']=data_oot_woe['COMP_APPL_ID'].values
   
    X_train_df['loan']=y_train.values
    X_test_df['loan']=y_test.values
    X_oot_df['loan']=y_oot.values
   
    X_train_df['loan_pred']=y_prob_train[:,1:]
    X_test_df['loan_pred']=y_prob_test[:,1:]
    X_oot_df['loan_pred']=y_prob_oot[:,1:]
   
    X_train_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\Pred\train2.csv',index=False)
    X_test_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\Pred\test2.csv',index=False)
    X_oot_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\Pred\oot2.csv',index=False)

########################################################################################

    #get model stats  
    iteration=1      
   
    stats_df, lift_table =print_model_stats("_test",config2['DEFAULT_PROB_THRESHOLD'], y_prob_test, y_prob_train, y_test, y_train)            
    model_stats_df=pd.concat([stats_df,model_stats_df])
    save_reports(model_stats_df,config2)
   
    stats_df_oot, lift_table_oot =print_model_stats("_oot",config2['DEFAULT_PROB_THRESHOLD'], y_prob_oot, y_prob_train, y_oot, y_train)            
    model_stats_df_oot=pd.concat([stats_df_oot,model_stats_df_oot])
    save_reports(model_stats_df_oot,config2)

    stats_df_train, lift_table_train =print_model_stats("_train",config2['DEFAULT_PROB_THRESHOLD'], y_prob_train, y_prob_train, y_train, y_train)            
    model_stats_df_train=pd.concat([stats_df_train,model_stats_df_train])
    model_stats_df_train=pd.concat([model_stats_df,model_stats_df_oot,model_stats_df_train])
    save_reports(model_stats_df_train,config2)
   
   
    ###########################feature Imp
   
    cov = model.cov_params()
    std_err = np.sqrt(np.diag(cov))
    z_values = model.params / std_err

    coef=model.params.values
    sd=np.std(X_train[X_train_cols], 0)
    coef_sd=sd*coef
    abs_coef_sd = abs(coef_sd)
    abs_coef_sd_norm = (abs_coef_sd / abs_coef_sd.sum())

    z_values_abs=abs(z_values)
    z_values_abs_norm = (z_values_abs / z_values_abs.sum())

    feature_importance_df=pd.DataFrame()
    feature_importance_df['Columns']=abs_coef_sd.index
   
    feature_importance_df['coef']=coef
    feature_importance_df['sd']=sd.values
    feature_importance_df['coef_sd']=coef_sd.values

    feature_importance_df['abs_coef_sd']=abs_coef_sd.values
   
    feature_importance_df['z_values']=z_values.values
    feature_importance_df['abs_z_values']=z_values_abs.values
   
    feature_importance_df = feature_importance_df[feature_importance_df.Columns != 'const']
   
    feature_importance_df['abs_coef_sd_norm']=feature_importance_df['abs_coef_sd']/feature_importance_df['abs_coef_sd'].sum()
    feature_importance_df['abs_z_values_norm']=feature_importance_df['abs_z_values']/feature_importance_df['abs_z_values'].sum()
   
    feature_importance_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\model_coef2.csv',index=False)
   
#    X_train.drop(columns=['Model_prediction','Rnk_order_bin','loan'], inplace=True)
#    X_test.drop(columns=['Model_prediction','Rnk_order_bin','loan'], inplace=True)
#    X_oot.drop(columns=['Model_prediction','Rnk_order_bin','loan'], inplace=True)
#    X_oot.columns
    ks_chart_df_test=get_ks_decile_chart(model,X_test,y_test,1,X_train_cols)
    ks_chart_df_test['Data']='Test'

   
    ks_chart_df_oot=get_ks_decile_chart(model,X_oot,y_oot,1,X_train_cols)
    ks_chart_df_oot['Data']='OOT'

   
    ks_chart_df_train=get_ks_decile_chart(model,X_train,y_train,1,X_train_cols)
    ks_chart_df_train['Data']='Train'
   
    ks_chart=pd.concat([ks_chart_df_oot,ks_chart_df_test,ks_chart_df_train])

    ks_chart.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\May_21\LIC\Self\ks2.csv',index=False)
   
    #psi_ks=calc_psi(ks_chart_df_oot, ks_chart_df_train, ks_chart_df_test)
    #psi_ks.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\May_13\LIC\Sal\psi_ks_cibil.csv',index=False)


   
   
   
   
# =============================================================================
#     # save the model trained on the largest number of training data points
#     save_model(model_list[iteration - 1], config2)
#     feature_list = list(X_train.columns)
#     save_features(feature_list, config2)
# =============================================================================
   
   
   
    return model_stats_df, lift_table,model_stats_df_oot, lift_table_oot,model_stats_df_train, lift_table_train

def calc_psi(sal_oot, sal_application_train, sal_application_test,n_buckets=5):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    oot_data = sal_oot.select_dtypes(include=numerics)
    test_data = sal_application_test.select_dtypes(include=numerics)
    train_data = sal_application_train.select_dtypes(include=numerics)
    numerical_column_list=test_data.columns.tolist()
    print(numerical_column_list)
    train_data = train_data.to_numpy()
    test_data = test_data.to_numpy()
    oot_data = oot_data.to_numpy()
    psi_values_1 = calculate_psi(train_data, test_data, buckettype='bins', buckets=n_buckets, axis=1)
    psi_values_2 = calculate_psi(train_data, oot_data, buckettype='bins', buckets=n_buckets, axis=1)
    df_psi=pd.DataFrame()
    df_psi['psi_1_tt']=psi_values_1
    df_psi['psi_2_to']=psi_values_2
    df_psi['Column']=numerical_column_list
    return df_psi

def calculate_psi(expected, actual, buckettype='bins', buckets=10, axis=0):
    '''Calculate the PSI (population stability index) across all variables
    Args:
       expected: numpy matrix of original values
       actual: numpy matrix of new values, same size as expected
       buckettype: type of strategy for creating buckets, bins splits into even splits, quantiles splits into quantile buckets
       buckets: number of quantiles to use in bucketing variables
       axis: axis by which variables are defined, 0 for vertical, 1 for horizontal
    Returns:
       psi_values: ndarray of psi values for each variable
    Author:
       Matthew Burke
       github.com/mwburke
       worksofchart.com
    '''

    def psi(expected_array, actual_array, buckets):
        '''Calculate the PSI for a single variable
        Args:
           expected_array: numpy array of original values
           actual_array: numpy array of new values, same size as expected
           buckets: number of percentile ranges to bucket the values into
        Returns:
           psi_value: calculated PSI value
        '''

        def scale_range (input, min, max):
            input += -(np.min(input))
            input /= np.max(input) / (max - min)
            input += min
            return input


        breakpoints = np.arange(0, buckets + 1) / (buckets) * 100

        if buckettype == 'bins':
            breakpoints = scale_range(breakpoints, np.min(expected_array), np.max(expected_array))
        elif buckettype == 'quantiles':
            breakpoints = np.stack([np.percentile(expected_array, b) for b in breakpoints])



        expected_percents = np.histogram(expected_array, breakpoints)[0] / len(expected_array)
        actual_percents = np.histogram(actual_array, breakpoints)[0] / len(actual_array)

        def sub_psi(e_perc, a_perc):
            '''Calculate the actual PSI value from comparing the values.
               Update the actual value to a very small number if equal to zero
            '''
            if a_perc == 0:
                a_perc = 0.0001
            if e_perc == 0:
                e_perc = 0.0001

            value = (e_perc - a_perc) * np.log(e_perc / a_perc)
            return(value)

        psi_value = np.sum(sub_psi(expected_percents[i], actual_percents[i]) for i in range(0, len(expected_percents)))

        return(psi_value)

    if len(expected.shape) == 1:
        psi_values = np.empty(len(expected.shape))
    else:
        psi_values = np.empty(expected.shape[axis])

    for i in range(0, len(psi_values)):
        if len(psi_values) == 1:
            psi_values = psi(expected, actual, buckets)
        elif axis == 0:
            psi_values[i] = psi(expected[:,i], actual[:,i], buckets)
        elif axis == 1:
            psi_values[i] = psi(expected[i,:], actual[i,:], buckets)

    return(psi_values)

import statsmodels.api as sm
def stepwise_selection(X, y,
                       initial_list=[],
                       threshold_in=0.05,
                       threshold_out = 0.05,
                       verbose=True):
    """ Perform a forward-backward feature selection
    based on p-value from statsmodels.api.OLS
    Arguments:
        X - pandas.DataFrame with candidate features
        y - list-like with the target
        initial_list - list of features to start with (column names of X)
        threshold_in - include a feature if its p-value < threshold_in
        threshold_out - exclude a feature if its p-value > threshold_out
        verbose - whether to print the sequence of inclusions and exclusions
    Returns: list of selected features
    Always set threshold_in < threshold_out to avoid infinite looping.
    See https://en.wikipedia.org/wiki/Stepwise_regression for the details
    """
    included = list(initial_list)
    while True:
        changed=False
        # forward step
        excluded = list(set(X.columns)-set(included))
        new_pval = pd.Series(index=excluded)
        for new_column in excluded:
            X = X.reindex(columns=included+[new_column])
            X=X.replace([-np.inf,np.inf], np.nan)
            X=X.fillna(0)
            model = sm.OLS(y, sm.add_constant(pd.DataFrame(X[included+[new_column]]))).fit()
            new_pval[new_column] = model.pvalues[new_column]
        best_pval = new_pval.min()
        if best_pval < threshold_in:
            best_feature = new_pval.argmin()
            included.append(best_feature)
            changed=True
            if verbose:
                print('Add  {:30} with p-value {:.6}'.format(best_feature, best_pval))

        # backward step
        X = X.reindex(columns=included)
        X=X.replace([-np.inf,np.inf], np.nan)
        X=X.fillna(0)
        model = sm.OLS(y, sm.add_constant(pd.DataFrame(X[included]))).fit()
        print('model')
        # use all coefs except intercept
        pvalues = model.pvalues.iloc[1:]
        worst_pval = pvalues.max() # null if pvalues is empty
        if worst_pval > threshold_out:
            changed=True
            worst_feature = pvalues.argmax()
            worst_feature= pvalues.index[worst_feature]
            included.remove(worst_feature)
            if verbose:
                print('Drop {:30} with p-value {:.6}'.format(worst_feature, worst_pval))
        if not changed:
            break
    return included
#LAUNCHER
from optbinning import BinningProcess
def find_optimal_bins(data, config_func, config_general_info):
    '''
    find_optimal_bins_dict is a function to find the optimal bins of a given data.
    It is saved as a dictionary into a json file. These bins can be manually adjusted if required.

    Parameters
    ----------
    data: The dataframe that the column is present
    config_func: Config parameters related to this function
    config_general_info: General config parameters related to the data and model

    Output(s)
    ---------
    bin_dict_sc: A dictionary with bins values for each column
   
    '''
    #data=df.copy()
    #Defining the target and feature values
   
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)].tolist()
     
    feature_target = feature_list + [target_col]
   
    prebin_method = config_func['prebin_method']
    min_prebin_size = config_func['min_prebin_size']
    max_n_prebins = config_func['max_n_prebins']
    min_n_bins = config_func['min_n_bins']
    solver = config_func['solver']
    #monotonic_trend = config_func['monotonic_trend']
     
    param_dict = {
    'monotonic_trend':'auto_asc_desc',
    'divergence' : 'iv',
    'prebinning_method' : prebin_method,
    'min_prebin_size' : min_prebin_size,
    'max_n_prebins' : max_n_prebins,
    'min_n_bins' : min_n_bins,
    'solver': solver
    }
   
    binning_fit_params = {}
    for col in feature_list:
        binning_fit_params[col] = param_dict
       
    special_values = config_func['special_values']
     
    binning_process = BinningProcess(variable_names=feature_list,
                                     binning_fit_params=binning_fit_params,
                                     special_codes=special_values,verbose=True
                                )    
#    
#    list_categorical = df.select_dtypes(include=['object', 'category']).columns.values
#    selection_criteria = {"iv": {"min": 0.005, 'max':0.5, "strategy": "highest"}}
#    
#    binning_process= BinningProcess(categorical_variables=list_categorical,
#                            variable_names=feature_list
#                            )
                                     
    binning_process.fit(data[feature_list], data[target_col])
    return binning_process

config_func = {'prebin_method':'cart',
    'min_prebin_size':0.05,
    'max_n_prebins':1000,
    'min_n_bins':1,
    'solver':'cp',
    #'monotonic_trend':'auto_asc_desc',
    'special_values' : [-999999],
    'input_file_name':'woe_bin_dict'
    }

config_general_info = {'non_feature_columns':['loan', 'COMP_APPL_ID','GUAR_COAP_FLAG'],
    'target_col':'loan',
    'output_folder':r'C:\Users\vishwesh kumar\Videos\LIC',
    'date_col':'FIRST_DISB_DATE'
    }


def get_iv(df, thres):
    df=df.replace([-np.inf,np.inf], np.nan)
    binning_process = find_optimal_bins(df, config_func, config_general_info)
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(df,binning_process, config_func, config_general_info)
    woe_summary_df = binning_process.summary()
    woe_summary_df.drop(['dtype','status','selected','js','quality_score'], axis=1, inplace=True)
    woe_summary_df.columns = ['COLUMN NAME', 'NUMBER OF BINS', 'IV', 'GINI']
    col_to_drop = woe_summary_df[woe_summary_df['IV']< thres]
    col_to_drop = col_to_drop['COLUMN NAME'].tolist()
    df.drop(col_to_drop, axis = 1, inplace = True)
    return df,woe_summary_df,woe_detailed_df

def get_bin_information(data, binning_process, config_func, config_general_info):
    #data=sal_application_train.copy()
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)].tolist()
 
    woe_summary_df = binning_process.summary()
    woe_summary_df.drop(['dtype','status','selected','js','quality_score'], axis=1, inplace=True)
    woe_summary_df.columns = ['COLUMN NAME', 'NUMBER OF BINS', 'IV', 'GINI']
   
    woe_bin_dict = {}
    woe_detailed_df_list = []
    for col in feature_list :
        #########
        optb = binning_process.get_binned_variable(col)
        try:
            woe_bin_dict[col]= optb.splits.tolist()
        except:
            woe_bin_dict[col]=[a.tolist() for a in optb.splits]
        # Remove total (Overall) row
        woe_detailed_df = optb.binning_table.build().iloc[:-1]
        # Remove if special or missing is empty
        woe_detailed_df = woe_detailed_df[woe_detailed_df['Count'] !=0]
        woe_detailed_df.drop('JS', axis=1, inplace=True)
        woe_detailed_df['COLUMN NAME'] = col
        woe_detailed_df = woe_detailed_df[['COLUMN NAME', 'Bin', 'Count', 'Count (%)', 'Non-event',
        'Event','Event rate', 'WoE', 'IV']]
        woe_detailed_df_list.append(woe_detailed_df)
       
    woe_detailed_df = pd.concat(woe_detailed_df_list)
 
    # Remove empty list
    woe_bin_dict = {k:v for k,v in woe_bin_dict.items() if v}
    #Relevant Mapping for scorecardpy (Accepts categorical with multiple seperated with %, %)
    woe_bin_dict = woe_bin_dict.copy()
    for col in data[feature_list].select_dtypes(['object', 'category']).columns:
        my_list = []
        for item in woe_bin_dict[col]:
            # If category is seperate keep it else combine them
            if len(item)==1:
                my_list.append(item[0])
            else:
                my_list.append('%,%'.join(str(item)))
        woe_bin_dict[col] = my_list
   
    # Format woe bin dict for excel
    woe_bins = pd.Series(woe_bin_dict).to_frame('BINS').reset_index()
    woe_bins.rename(columns={'index':'COLUMN NAME'}, inplace=True)
    woe_bins['BINS'] = woe_bins['BINS'].astype(str).str.strip('[]')
     
    return woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict

import scorecardpy as sc
import ast

def adjust_bins_interactively (data, config_func, config_general_info, woe_bin_dict,):
    #data=sal_application_train.copy()
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)]
   
    feature_target= feature_list.tolist() + [target_col]
     
    special_values = config_func['special_values']
    # Create the binnings first
    print(data[feature_target].columns.tolist())
    optimal_bins = sc.woebin(data[feature_target] , y=target_col, break_list=woe_bin_dict,
    special_values=special_values)
    # Interactive Adjusting
#    manually_adjusted_bins= sc.woebin_adj(data[feature_target] , y=target_col, bins=optimal_bins,
#    adj_all_var=True)
    manually_adjusted_bins= sc.woebin_adj(data[feature_target] , y=target_col, bins=optimal_bins)
    # Get the bins as list
    manually_adjusted_bins = ast.literal_eval(manually_adjusted_bins)
    return manually_adjusted_bins

def adjust_bins (data, config_func, config_general_info, woe_bin_dict,):
    #data=sal_application_train.copy()
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)]
   
    feature_target= feature_list.tolist() + [target_col]
     
    special_values = config_func['special_values']
    # Create the binnings first
    print(data[feature_target].columns.tolist())
    optimal_bins = sc.woebin(data[feature_target] , y=target_col, break_list=woe_bin_dict,
    special_values=special_values)
    # Interactive Adjusting
#    manually_adjusted_bins= sc.woebin_adj(data[feature_target] , y=target_col, bins=optimal_bins,
#    adj_all_var=True)
    # Get the bins as list
#    manually_adjusted_bins = ast.literal_eval(manually_adjusted_bins)
#    return manually_adjusted_bins
    return optimal_bins
def apply_manually_adjusted_bins(data, manually_adjusted_bins, config_func, config_general_info):
    #data=sal_application_train.copy()
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)].tolist()
    feature_target = feature_list + [target_col]
     
    binning_fit_params = {}
   
    for k, v in manually_adjusted_bins.items():
        binning_fit_params[k] = {'user_splits':v}
        binning_fit_params[k].update({'user_splits_fixed': len(v)* [True]})

    special_values = config_func['special_values']
    selection_criteria = {"iv": {"min": 0.005, 'max':0.5, "strategy": "highest"}}
    data_cat = data[feature_list].select_dtypes(include=['object', 'category'])
     
    feature_list2=data_cat.columns.tolist()
    len(feature_list)
    feature_list_all=data.drop(columns=['loan']).columns.values
     
    binning_process = BinningProcess(variable_names=feature_list,categorical_variables=feature_list2,
                                      binning_fit_params=binning_fit_params,
                                      special_codes=special_values,verbose=True,
                                      selection_criteria=selection_criteria)
   
    binning_process.fit(data[feature_list],data[target_col])    
    return binning_process
 
 


if __name__ == "__main__":

    #start_time = time.time()

    #----------------------------------------read data-------------------------------------------------
    #Read model data file:  
# =============================================================================
#     regex=os.path.join(config2['REPO_PATH']+config2['MODEL_DATA']) + "/*"
#     model_df=read_latest_data(regex,"csv")
#    
#     model_df=read_latest_data(regex,"csv")
# =============================================================================
    sal_model = pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Processed Data\salaried\model_train_data_salaried_07-05-2021.csv', compression = "gzip")
    self_model= pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Processed Data\self\model_train_data_self_07-05-2021.csv', compression = "gzip")


    ihl = pd.read_csv(config2['INPUT_DATA_CONSOLIDATED'],  encoding = 'unicode_escape')
    lap = pd.read_excel(config2['INPUT_DATA_CONSOLIDATED_LAP'])
   
    ihl_thin=ihl[['COMP_APPL_ID','CUSTOMERID','EMI','NET_MONTHLY_INCOME','GUAR_COAP_FLAG','EMPLOYEMENT_SLAB','EDUCATIONAL_QUALIFICATION']]
    lap_thin=lap[['COMP_APPL_ID','CUSTOMERID','EMI','NET_MONTHLY_INCOME','GUAR_COAP_FLAG','EMPLOYEMENT_SLAB','EDUCATIONAL_QUALIFICATION']]
   
    ihl_lap=pd.concat([ihl_thin,lap_thin])
    #EMI
    ihl_lap.groupby('COMP_APPL_ID').EMI.max()
   
    ihl_lap.EMPLOYEMENT_SLAB.value_counts()
   
    ihl_lap_P=ihl_lap[ihl_lap['GUAR_COAP_FLAG']=='P']
    ihl_lap_P['COMP_APPL_ID'].nunique()
    ###########################################################################################################
    edu_df_P=ihl_lap_P[['COMP_APPL_ID','EMPLOYEMENT_SLAB','EDUCATIONAL_QUALIFICATION']]
   
    edu_df=ihl_lap[['COMP_APPL_ID','GUAR_COAP_FLAG','EMPLOYEMENT_SLAB','EDUCATIONAL_QUALIFICATION']]
   
    temp_df=edu_df.groupby(['EMPLOYEMENT_SLAB','GUAR_COAP_FLAG','EDUCATIONAL_QUALIFICATION']).nunique()
   
    temp_df2=edu_df.groupby(['EMPLOYEMENT_SLAB','EDUCATIONAL_QUALIFICATION']).nunique()
   
    temp_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\LIC models_May_10\education_distribution.csv')
    temp_df2.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\LIC models_May_10\education_distribution2.csv')
###############################################################################################################  
   
   
    emp_df=ihl_lap_P[['COMP_APPL_ID','EMPLOYEMENT_SLAB']]
    emp_df.isna().sum()
   
    emi_df=pd.DataFrame(ihl_lap.groupby('COMP_APPL_ID').EMI.max())
    emi_df=emi_df.reset_index()
   
    #LIC_Sal
    sal_model_thin=sal_model[['COMP_APPL_ID','PURPOSE','INDUSTRY_TYPE_grp','COMPANY_TYPE_grp',
                              'NET_MONTHLY_INCOME','L_B_NET_MONTHLY_INCOME_sum','loan','loan_type','Purchase_flag',
                              'EDUCATIONAL_QUALIFICATION_grp']]
    sal_model_thin.columns=['COMP_APPL_ID','PURPOSE_raw','INDUSTRY_TYPE_grp_raw',
                            'COMPANY_TYPE_grp_raw','NET_MONTHLY_INCOME_raw',
                            'L_B_NET_MONTHLY_INCOME_sum_raw','loan','loan_type','Purchase_flag',
                            'EDUCATIONAL_QUALIFICATION_grp_raw']
   
    sal_model_thin=pd.merge(sal_model_thin,emi_df,how='left',on='COMP_APPL_ID')

    #LIC_Self
    self_model_thin=self_model[['COMP_APPL_ID','PURPOSE','INDUSTRY_TYPE_grp','COMPANY_TYPE_grp',
                              'NET_MONTHLY_INCOME','L_B_NET_MONTHLY_INCOME_sum','loan',
                              'loan_type','Purchase_flag','L_B_AGE_mean',
                              'L_B_EDUCATIONAL_QUALIFICATION_grp_PROFESSIONAL_count',
                              'L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count']]
   
    self_model_thin.columns=['COMP_APPL_ID','PURPOSE_raw','INDUSTRY_TYPE_grp_raw',
                            'COMPANY_TYPE_grp_raw','NET_MONTHLY_INCOME_raw',
                            'L_B_NET_MONTHLY_INCOME_sum_raw','loan','loan_type','Purchase_flag',
                            'L_B_AGE_mean_raw','L_B_EDUCATIONAL_QUALIFICATION_grp_PROFESSIONAL_count_raw',
                              'L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count_raw']
   
    self_model_thin=pd.merge(self_model_thin,emi_df,how='left',on='COMP_APPL_ID')
    self_model_thin=pd.merge(self_model_thin,emp_df,how='left',on='COMP_APPL_ID')
   
    ###########################################################################################
    #self
    sal_model_thin=self_model_thin.copy()
    self_model_thin['EMPLOYEMENT_SLAB'].value_counts()
    #################################################################################

    sal_model_thin['EMI_NMI']=sal_model_thin['EMI']/sal_model_thin['NET_MONTHLY_INCOME_raw']
    sal_model_thin['L_B_EMI_NMI']=sal_model_thin['EMI']/sal_model_thin['L_B_NET_MONTHLY_INCOME_sum_raw']
    del sal_model_thin['NET_MONTHLY_INCOME_raw']
    del sal_model_thin['L_B_NET_MONTHLY_INCOME_sum_raw']
    del sal_model_thin['EMI']
   
    sal_model_thin['loan_type_purchase_flag']=sal_model_thin['loan_type']+"_"+sal_model_thin['Purchase_flag']
    del sal_model_thin['loan_type']
    del sal_model_thin['Purchase_flag']
   
    #self
    sal_model_thin['L_B_EDUCATIONAL_QUALIFICATION_grp_PROF_PG_count']=sal_model_thin['L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count_raw']+sal_model_thin['L_B_EDUCATIONAL_QUALIFICATION_grp_PROFESSIONAL_count_raw']
    del sal_model_thin['L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count_raw']
    del sal_model_thin['L_B_EDUCATIONAL_QUALIFICATION_grp_PROFESSIONAL_count_raw']
   
   
   
    sal_model_thin.columns.tolist()
   
    sal_model_thin,woe_summary_df,woe_detailed_df = get_iv(sal_model_thin, 0.01)
   

    #copy data_train_woe first
    sal_model_thin_train=pd.merge(data_train_woe['COMP_APPL_ID'],sal_model_thin,how='left',on='COMP_APPL_ID')
   
    binning_process = find_optimal_bins(sal_model_thin_train, config_func, config_general_info)
   
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(sal_model_thin_train, binning_process, config_func, config_general_info)
   
    breaks_adj = {'PURPOSE_raw': ["Extension of House / Flat",
                                  "Purchase of Ready House%,%Purchase of Flat Ready Built",
                                  "Home Equity Loan- Repair/Renovation/Extension%,%Improvement / Renovation",
                                  "Construction of House%,%Plot Purchase and House Constn.",
                                  "Purchase of New Flat","Home Entity Loan"],
     'INDUSTRY_TYPE_grp_raw': ["Govt","Others%,%Unlisted Co%,%Rest"],
     #'COMPANY_TYPE_grp_raw': ["CEHL","Unapproved Company%,%CAP4%,%Others%,%Individual%,%Proprietorship Firm"], #lic sal
     'COMPANY_TYPE_grp_raw': ["Unapproved Company","CEHL","CAP4","Others","Individual","Proprietorship Firm"], #lic self
     'L_B_AGE_mean_raw': [28,38,44], #lic self
     #'EDUCATIONAL_QUALIFICATION_grp_raw': ['PG%,%PROFESSIONAL','GRADUATE','DIPLOMA','SSC','HSC%,%OTHER%,%Others'],#lic sal
     #'EMI_NMI': [0.4202735871076584, 0.49749891459941864], #lic sal
     'EMI_NMI': [0.35933640599250793, 0.5027109980583191], #lic self
     #'L_B_EMI_NMI': [0.4073372334241867,0.4954759031534195,
      #               0.5339595079421997,0.6010720431804657], #lic sal
      'L_B_EMI_NMI':[0.4329201579093933, 0.5022085607051849, 0.6016852259635925], #lic self
     'loan_type_purchase_flag': ['IHL_Non Under Construction','IHL_Under Construction',
                                 'LAP_Non Under Construction'],
      'L_B_EDUCATIONAL_QUALIFICATION_grp_PROF_PG_count': [0.5, 1.5]#lic self
      }
     
    feature_list=sal_model_thin_train.columns[~sal_model_thin_train.columns.isin(['COMP_APPL_ID','loan'])]
    feature_target= feature_list.tolist() + ['loan']
   
    sal_model_thin_train['loan'].value_counts()
    sal_model_thin_train['loan']=np.where(sal_model_thin_train['loan']==1,0,1)
   
    manually_adjusted_bins2 = sc.woebin(sal_model_thin_train[feature_target], y="loan", breaks_list=breaks_adj)
     
    manually_adjusted_bins_df=pd.DataFrame()
    for k,v in manually_adjusted_bins2.items():
         manually_adjusted_bins_df=pd.concat([manually_adjusted_bins_df,v])
         
    train_woe = sc.woebin_ply(sal_model_thin[list(manually_adjusted_bins2.keys())], manually_adjusted_bins2)    
    train_woe['COMP_APPL_ID']=sal_model_thin['COMP_APPL_ID'].values
   
    manually_adjusted_bins_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Sal\manually_adjusted_bins_May_22.csv',index=False)
     
     

   


    #LIC salaried
    data_oot_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Sal\data_oot_c_woe_May_10.csv')
    data_noot_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Sal\data_oot_nc_woe_May_10.csv')
    data_test_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Sal\data_test_woe_May_10.csv')
    data_train_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Sal\data_train_woe_May_10.csv')
   
    data_oot_woe=pd.merge(data_oot_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_noot_woe=pd.merge(data_noot_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_test_woe=pd.merge(data_test_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_train_woe=pd.merge(data_train_woe,train_woe,how='left',on='COMP_APPL_ID')

   


    #LIC self
    data_oot_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Self\data_oot_c_woe_self_May_10.csv')
    data_noot_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Self\data_oot_nc_woe_self_May_10.csv')
    data_test_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Self\data_test_woe_self_May_10.csv')
    data_train_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Self\data_train_woe_self_May_10.csv')
   
    data_oot_woe=pd.merge(data_oot_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_noot_woe=pd.merge(data_noot_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_test_woe=pd.merge(data_test_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_train_woe=pd.merge(data_train_woe,train_woe,how='left',on='COMP_APPL_ID')

   
    #cibil sal
    data_oot_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Sal\data_oot_c_woe_May_17.csv')
    data_noot_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Sal\data_oot_nc_woe_May_17.csv')
    data_test_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Sal\data_test_woe_May_17.csv')
    data_train_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Sal\data_train_woe_May_17.csv')
    #cibil self
    data_oot_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\data_oot_c_woe_May_17.csv')
    data_noot_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\data_oot_nc_woe_May_17.csv')
    data_test_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\data_test_woe_May_17.csv')
    data_train_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\data_train_woe_May_17.csv')
   
############################################################################################################  
    #cols=pd.read_excel(r'C:\Users\vishwesh kumar\Videos\LIC\CIBIL_models_May_10\Master Sheet_CIBIL_May_9.1_updt.xlsx' , sheet_name='Master Variable Sheet 2')
    cols=pd.read_excel(r'C:\Users\vishwesh kumar\Videos\LIC\LIC models_May_10\Master Sheet_May_5_v2.1.xlsx' , sheet_name='Master Variable Sheet 2')
   
    feat1=cols[cols['Analysed']==1]['Feature'].values.tolist()
    non_match=set(feat1)-set(data_noot_woe.columns.tolist())
    feat=list(set(feat1)-set(non_match))
   
    feat2=train_woe.columns.tolist()
   
    #lic sal
    feat=feat+['loan','loan_type_purchase_flag_woe','INDUSTRY_TYPE_grp_raw_woe','COMPANY_TYPE_grp_raw_woe',
               'PURPOSE_raw_woe','EMI_NMI_woe','L_B_EMI_NMI_woe','EDUCATIONAL_QUALIFICATION_grp_raw_woe','COMP_APPL_ID']
   
    feat_drop=['loan_type','Purchase_flag','INDUSTRY_TYPE_grp','COMPANY_TYPE_grp','PURPOSE','BUSS_PROF_NATURE_grp',
               'MATURITY_AGE','Area_mod','C_P_datediff_sancmin','L_B_APPLICATION_TYPE_New_count',
               'L_B_NET_MONTHLY_INCOME_sum','EDUCATIONAL_QUALIFICATION_grp']
    #lic self
    feat=feat+['loan','loan_type_purchase_flag_woe','INDUSTRY_TYPE_grp_raw_woe',
               'PURPOSE_raw_woe',
               'EMI_NMI_woe','L_B_EMI_NMI_woe','L_B_AGE_mean_raw_woe',
               'L_B_EDUCATIONAL_QUALIFICATION_grp_PROF_PG_count_woe','COMP_APPL_ID']
    feat_drop=['loan_type','Purchase_flag','INDUSTRY_TYPE_grp','PURPOSE','BUSS_PROF_NATURE_grp',
               'L_B_BUSS_PROF_NATURE_grp_Others_count',
               'MATURITY_AGE','Area_mod','C_P_datediff_sancmin','L_B_APPLICATION_TYPE_New_count',
               'L_B_NET_MONTHLY_INCOME_sum','GROSS_MONTHLY_OTHER_INCOME',
               'L_B_EDUCATIONAL_QUALIFICATION_grp_OTHER_count','income_prop_ratio',
               'L_B_COMPANY_TYPE_grp_CAP4_count','L_B_AGE_mean',
               'L_B_EDUCATIONAL_QUALIFICATION_grp_PROFESSIONAL_count',
               'L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count',
               'L_B_EDUCATIONAL_QUALIFICATION_grp_DIPLOMA_count',
               'L_B_EDUCATIONAL_QUALIFICATION_grp_GRADUATE_count',
               'L_B_INDUSTRY_TYPE_grp_Unlisted Co_count','L_B_COMPANY_TYPE_grp_CAP4_count',
               'L_B_COMPANY_TYPE_grp_Individual_count']
   
   
    feat = [x for x in feat if x not in feat_drop]
###############################################
    data_oot_woe=data_oot_woe[feat]
    data_noot_woe=data_noot_woe[feat]
    data_test_woe=data_test_woe[feat]
    data_train_woe=data_train_woe[feat]
   
    data_oot_woe['loan'].value_counts()
    data_noot_woe['loan'].value_counts()
    data_train_woe['loan'].value_counts()
    data_test_woe['loan'].value_counts()
   
    data_oot_woe=data_oot_woe.replace([-np.inf,np.inf], np.nan)
    data_noot_woe=data_noot_woe.replace([-np.inf,np.inf], np.nan)
    data_test_woe=data_test_woe.replace([-np.inf,np.inf], np.nan)
    data_train_woe=data_train_woe.replace([-np.inf,np.inf], np.nan)
   
    data_oot_woe.isna().sum()
    data_noot_woe.isna().sum()
   
    data_oot_woe=data_oot_woe.dropna()
    data_noot_woe=data_noot_woe.dropna()
    data_test_woe=data_test_woe.dropna()
    data_train_woe=data_train_woe.dropna()


#####################################################################################################    
############################CIBIL Self#########################################################################    
       
    #Remove noisy columns and rebin    
    #cibil self
    to_drop=['-2.0_loan_counts_x','-2.0_loan_counts_y','Total_outstanding_Balance_live_loans',
             'Credit Card_30DPD_instances_L6M','BL-PS-Small Business_30DPD_instances_L12M',
             'max_enquiries_Others_31_to_395','Two Wheeler Loan_30DPD_instances_L12M']
   
    data_oot_woe.drop(columns=to_drop,inplace=True)
    data_noot_woe.drop(columns=to_drop,inplace=True)
    data_test_woe.drop(columns=to_drop,inplace=True)
    data_train_woe.drop(columns=to_drop,inplace=True)
   
    cibil_self=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\cibil processed v1\cibil_long_self_iter_3.1.csv')
    cibil_self['Max_deliquency_L6M'].value_counts()
   
    cibil_self_thin=cibil_self[['COMP_APPL_ID','Max_deliquency_L6M','loan']]
    cibil_self_thin.columns=['COMP_APPL_ID','Max_deliquency_L6M_raw','loan']
   
    sal_model_thin_train=pd.merge(data_train_woe['COMP_APPL_ID'],cibil_self_thin,how='left',on='COMP_APPL_ID')
    sal_model_thin_train['Max_deliquency_L6M_raw'].value_counts(dropna=False)
   
    breaks_adj = {'Max_deliquency_L6M_raw': ["0%,%-1.0%,%-2.0","(0,29]%,%[30,59]%,%[60,89]%,%[90,149]%,%[150,179]%,%[180,359]%,%>=360"]}
     
    feature_list=sal_model_thin_train.columns[~sal_model_thin_train.columns.isin(['COMP_APPL_ID','loan'])]
    feature_target= feature_list.tolist() + ['loan']
   
    sal_model_thin_train['loan'].value_counts()
    sal_model_thin_train['loan']=np.where(sal_model_thin_train['loan']==1,0,1)
   
    manually_adjusted_bins2 = sc.woebin(sal_model_thin_train[feature_target], y="loan", breaks_list=breaks_adj)
     
    manually_adjusted_bins_df=pd.DataFrame()
    for k,v in manually_adjusted_bins2.items():
         manually_adjusted_bins_df=pd.concat([manually_adjusted_bins_df,v])
         
    train_woe = sc.woebin_ply(cibil_self_thin[list(manually_adjusted_bins2.keys())], manually_adjusted_bins2)    
    train_woe['COMP_APPL_ID']=cibil_self_thin['COMP_APPL_ID'].values
   
    manually_adjusted_bins_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\manually_adjusted_bins_May_21.csv',index=False)
   
    data_oot_woe=pd.merge(data_oot_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_noot_woe=pd.merge(data_noot_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_test_woe=pd.merge(data_test_woe,train_woe,how='left',on='COMP_APPL_ID')
    data_train_woe=pd.merge(data_train_woe,train_woe,how='left',on='COMP_APPL_ID')
   
   
    data_oot_woe.drop(columns=['Max_deliquency_L6M'],inplace=True)
    data_noot_woe.drop(columns=['Max_deliquency_L6M'],inplace=True)
    data_test_woe.drop(columns=['Max_deliquency_L6M'],inplace=True)
    data_train_woe.drop(columns=['Max_deliquency_L6M'],inplace=True)
   
   
   
    data_oot_woe.drop(columns=['Max_deliquency_L12m'],inplace=True)
    data_noot_woe.drop(columns=['Max_deliquency_L12m'],inplace=True)
    data_test_woe.drop(columns=['Max_deliquency_L12m'],inplace=True)
    data_train_woe.drop(columns=['Max_deliquency_L12m'],inplace=True)
   

     
#########################################################################################################
##########################################################################################################    
    #cibil sal
    data_oot_woe.drop(columns=['-1.0_loan_counts_y','-2.0_loan_counts_y','-1.0_loan_counts_x','-2.0_loan_counts_x'],inplace=True)
    data_noot_woe.drop(columns=['-1.0_loan_counts_y','-2.0_loan_counts_y','-1.0_loan_counts_x','-2.0_loan_counts_x'],inplace=True)
    data_test_woe.drop(columns=['-1.0_loan_counts_y','-2.0_loan_counts_y','-1.0_loan_counts_x','-2.0_loan_counts_x'],inplace=True)
    data_train_woe.drop(columns=['-1.0_loan_counts_y','-2.0_loan_counts_y','-1.0_loan_counts_x','-2.0_loan_counts_x'],inplace=True)
   
    data_oot_woe.drop(columns=['Overall_credit_vintage(months)'],inplace=True)
    data_noot_woe.drop(columns=['Overall_credit_vintage(months)'],inplace=True)
    data_test_woe.drop(columns=['Overall_credit_vintage(months)'],inplace=True)
    data_train_woe.drop(columns=['Overall_credit_vintage(months)'],inplace=True)
   
   
   
   
    data_oot_woe=data_oot_woe.replace([-np.inf,np.inf], np.nan)
    data_noot_woe=data_oot_woe.replace([-np.inf,np.inf], np.nan)
    data_test_woe=data_oot_woe.replace([-np.inf,np.inf], np.nan)
    data_train_woe=data_oot_woe.replace([-np.inf,np.inf], np.nan)
   
    #vif to get list of columns to be dropped, missing values needs to be handled
    #reload dataframe again as we dont need to handle missing values for other steps
    identify_correlation(data_train_woe, config2)
    data_train_woe.dtypes
    #self_application_train = missing_values_table(self_application_train)
    #2. Identify multicollinetrarity
    #self_application_train=handle_missing_value(self_application_train)
    calculate_vif(data_train_woe,config2)    
    #start_time = compute_time(start_time, 'Data load completed')
    #self employed    
    lst_vif_self=['COMPANY_TYPE_grp','LTV','L_B_FEMALE_INCLUSION_min','NET_MONTHLY_INCOME',
     'L_B_COMPANY_TYPE_grp_Unapproved Company_count']
   
    lst_vif_sal=["COMPANY_TYPE_grp"]
   
    data_train_woe.drop(lst_vif_self, axis = 1, inplace = True)
    data_test_woe = data_test_woe[data_train_woe.columns]
    data_noot_woe = data_noot_woe[data_train_woe.columns]
    data_oot_woe = data_oot_woe[data_train_woe.columns]

   
    #----------------------------------------Model Data Prep---------------------------------------------
    #Data Prep:  
    X,y= prepare_model_data(data_noot_woe, config2)
        #X=create_dummies(X,config2)
    model_stats_df, lift_table =train_model(data_train_woe, data_test_woe, data_oot_woe, config2)
#--------------------END OF MODULE 3-----------------------------------------------------

