# -*- coding: utf-8 -*-
"""
Created on Mon Jun  7 19:05:39 2021

@author: Vibhanshu Jain
"""




# -*- coding: utf-8 -*-
"""
Created on Wed Feb 24 16:34:41 2021

@author: Jain Vibhanshu
"""


"""
Spyder Editor

This is a temporary script file.
"""
'''
MODULE 1 - Reads Data from various sources and creates Target Variable

'''
#Add the requred libraries
import pandas as pd
import yaml
import swifter
import os
import pandas as pd
import numpy as np
import glob
import statistics
import time
import datetime as dt
from functools import reduce
from datetime import datetime, timedelta
#from shapely.geometry import Point, Polygon
import seaborn as sns
import matplotlib.pyplot as plt
import time
import re
from dateutil.relativedelta import relativedelta
import warnings
warnings.filterwarnings("ignore")

from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()

#%matplotlib notebook
import matplotlib.pyplot as plt
plt.style.use('seaborn-whitegrid')

pd.options.display.max_columns = None

pd.set_option('display.float_format', '{:.2f}'.format)
# =============================================================================
# root=os.getcwd()
# with open(root+ '\config\config_feature_engineering.yaml') as file:
#     config = yaml.full_load(file)
# =============================================================================

config = {    
   
    "REPO_PATH": r'C:\Users\vishwesh kumar\Videos\LIC',    
    "MODEL_DATA_SAL": r'\Processed Data\salaried',
    "MODEL_DATA_SELF": r'\Processed Data\self',
    "INPUT_DATA_CONSOLIDATED": r'C:\Users\vishwesh kumar\Videos\LIC\Raw Data UW\IHL.csv',
    "INPUT_DATA_CONSOLIDATED_LAP":  r'C:\Users\vishwesh kumar\Videos\LIC\Raw Data UW\LAP.xlsx',
    "INPUT_DATA_SHEETNAME" : r'IHL',
    "SAMPLED_DATA": r'C:\Users\vishwesh kumar\Videos\LIC\Bad Load Definition Customer Ids.xlsx',
    "TIDY_DATES": ['SANCTION_DATE','FIRST_DISB_DATE','EMISTARTDATE'],    
    "START_DATE": r'01-01-2013',#DD-MM-YYYY
    "END_DATE": r'31-03-2018', #DD-MM-YYYY
    "COHORT_DATE": ['FIRST_DISB_DATE'],
    "DPD_THRESHOLD": 30,
    "AGE_CAP":18,
    "ID_VAR": ['COMP_APPL_ID'],
    "DROP_LIST": [],
    "OBJ_LIST": ['COMP_APPL_ID', 'LOANNO', 'CUSTOMERID', 'SUPER_CIF'],
    "PIPELINE" : 'train',
    "CIBIL_ENQ": r'C:\Users\vishwesh kumar\Videos\LIC\Raw Data UW\retro_data_oq.csv',
    "CIBIL_CL": r'C:\Users\vishwesh kumar\Videos\LIC\Raw Data UW\retro_data_tl.csv'
   
}

#Helper Function

from datetime import datetime
import datetime as dt
from statsmodels.distributions.empirical_distribution import StepFunction
from datetime import date
import xlsxwriter
from datetime import datetime
#from dateutil import relativedelta
import gc

import re
import multiprocessing
import psutil
# import ray
import scipy.signal


def compute_time(start_time,name):
  """
  Compute the time taken to complete an action
  """

  new_time = time.time()
  delta =  datetime.fromtimestamp(new_time - start_time).strftime("%M:%S")
  print('\n')
  print('------------------------------')
  print(name,':',delta)
  print('------------------------------')
  return new_time
 
 
def save_csv_local(df, filename):
  """
  Save file as csv
  """
  df.to_csv(filename,  compression="gzip", index=False)

# =============================================================================
# Data Aggregation Calculations - Generic functions for calculating sum, mean and normalized counts per Customer ID
# =============================================================================

def count_categorical(df, group_var, df_name):
    """
   
    Inputs: df         = Dataframe on which calculations need to be done    
            group_var  = ID for grouping
            df_name    = prefix for identifying calculations
                 
           
    Output: categorical = data frame with sum and mean for categorical calculations
    """
   
    # Select the categorical columns
    categorical = pd.get_dummies(df.select_dtypes('object'))

    # Make sure to put the identifying id on the column
    categorical[group_var] = df[group_var]

    # Groupby the group var and calculate the sum and mean
    categorical = categorical.groupby(group_var).agg(['sum', 'mean'])
   
    column_names = []
   
    # Iterate through the columns in level 0
    for var in categorical.columns.levels[0]:
        # Iterate through the stats in level 1
        for stat in ['count', 'count_norm']:
            # Make a new column name
            column_names.append('%s_%s_%s' % (df_name, var, stat))
   
    categorical.columns = column_names
   
    return categorical
     

def agg_numeric(df, group_var, df_name):
    """
   
    Inputs: df         = Dataframe on which calculations need to be done    
            group_var  = ID for grouping
            df_name    = prefix for identifying calculations
                 
           
    Output: agg        = data frame with sum and mean for numeric caclulations
    """
    # Remove id variables other than grouping variable
    for col in df:
        if col != group_var and 'CUST_KEY' in col:
            df = df.drop(columns = col)
           
    group_ids = df[group_var]
    numeric_df = df.select_dtypes('number')
    numeric_df[group_var] = group_ids

    # Group by the specified variable and calculate the statistics
    agg = numeric_df.groupby(group_var).agg(['count', 'mean', 'max', 'min', 'sum']).reset_index()

    # Need to create new column names
    columns = [group_var]

    # Iterate through the variables names
    for var in agg.columns.levels[0]:
        # Skip the grouping variable
        if var != group_var:
            # Iterate through the stat names
            for stat in agg.columns.levels[1][:-1]:
                # Make a new column name for the variable and stat
                columns.append('%s_%s_%s' % (df_name, var, stat))

    agg.columns = columns
    return agg

 
# =============================================================================
# Date Cleaning Functions
# =============================================================================

def get_tidy_dates(df, config):
    """
    change format of the date column in a data frame

    Inputs: df                  = cleaned data
            config              = yaml file containing all config settings

    Output: df                  = data frame with cleaned date format
    """    
    df[config['TIDY_DATES']] = df[config['TIDY_DATES']].apply(pd.to_datetime, format = '%d/%m/%Y')
       
    return df  

def clean_additional_data(df):
    """
    Adhoc cleaning of additional outliers based on EDA

    Inputs:  df = model dataframe to be filtered

    Output:  df = filtered model dataframe
    """
   
    df = df.replace([np.inf, -np.inf], np.nan).copy()  

    return df

def convert_datatypes(model_df,config):
    """
    Preprocess data to convert datatypes of specified columns
    Inputs:     model_df            = dataframe that columns need to be converted
                config              = yaml file containing all config settings
    output:     model_df            = dataframe with converted datatypes
    """
   
    model_df[config['OBJ_LIST']] = model_df[config['OBJ_LIST']].astype(str)
    model_df=model_df.drop(config['DROP_LIST'],axis=1)
   
   
    return model_df

def perc_cap(df, i):
   
    low = df[i].quantile(0.1)
    high = df[i].quantile(0.99)
    df[i] = np.where(df[i]>high, high, df[i])
    df[i] = np.where(df[i]<low, low, df[i])
   
    return df


# =============================================================================
# Data filtering functions
# =============================================================================
def income_check(df):
    y = df.groupby('COMP_APPL_ID')['NET_MONTHLY_INCOME'].sum().reset_index()
    y = y[y['NET_MONTHLY_INCOME']<=0]
    y = y['COMP_APPL_ID'].values.tolist()
    df = df[~(df['COMP_APPL_ID'].isin(y))]
    del y
    y = df.groupby('COMP_APPL_ID')['GROSS_MONTHLY_OTHER_INCOME'].sum().reset_index()
    y = y[y['GROSS_MONTHLY_OTHER_INCOME']<=0]
    y = y['COMP_APPL_ID'].values.tolist()
    df = df[~(df['COMP_APPL_ID'].isin(y))]
    del y
    return df    

def appl_check(df):
    df = df[df['GUAR_COAP_FLAG']=='P']  
    return df


def disbemidiff_filter(df):
    df = df[df['disb_emi_diff']<= 61]
    df = df[~(df['DEF_DPD_MOM1']>31)]
    df = df[~(df['DEF_DPD_MOM2']>62)]
    df = df[~(df['DEF_DPD_MOM3']>92)]
    df = df[~(df['DEF_DPD_MOM4']>123)]
    df = df[~(df['DEF_DPD_MOM5']>153)]
    return df
 
# =============================================================================
# New Variable creation and transformations
# =============================================================================
def log_transformation(df, col):
    colnew = col.append('%s_%s_' %('log',col))
    df[colnew] = np.log(df[col])

def create_monthly_cohort(df, config):
    df['COHORT_DATE'+'_'+config['COHORT_DATE'][0]] = df[config['COHORT_DATE']].apply(lambda x: x.dt.strftime('%Y-%m'))
    return df

def income_flag(df):
    df['income_diff'] = ( df['GROSS_MONTHLY_OTHER_INCOME'] - df['NET_MONTHLY_INCOME'] )
    df['income_check_flag'] = np.where(df['NET_MONTHLY_INCOME']<=df['GROSS_MONTHLY_OTHER_INCOME'], 1, 0)
    return df

def datediff(df):
    df['disb_emi_diff'] = ( df['EMISTARTDATE'] - df['FIRST_DISB_DATE'] ).dt.days
    df['disb_emi_flag'] = np.where(df['EMISTARTDATE']>=df['FIRST_DISB_DATE'], 1, 0)
    df['disb_san_diff'] = ( df['FIRST_DISB_DATE'] - df['SANCTION_DATE'] ).dt.days
    df['disb_san_flag'] = np.where(df['FIRST_DISB_DATE']>=df['SANCTION_DATE'], 1, 0)
    df['san_emi_diff'] = ( df['EMISTARTDATE'] - df['SANCTION_DATE'] ).dt.days
    df['san_emi_flag'] = np.where(df['EMISTARTDATE']>=df['SANCTION_DATE'], 1, 0)
    return df

def sancfincdiff(df):
    df['sanc_fin_amt_diff'] = ( df['AMOUNTFINANCED'] - df['SANCTION_AMOUNT'] )
    df['sanc_fin_amt_flag'] = np.where(df['SANCTION_AMOUNT']>=df['AMOUNTFINANCED'], 1, 0)
    return df

def sancdiffpropdecvalue(df):
    df['sanc_prop_amt_diff'] = ( df['SANCTION_AMOUNT'] - df['PROP_VALUE'] )
    df['sanc_prop_amt_flag'] = np.where(df['SANCTION_AMOUNT']>=df['PROP_VALUE'], 1, 0)
    df['sanc_prop_amt_ratio'] = ( df['SANCTION_AMOUNT'] / df['PROP_VALUE'] )
    df['income_prop_ratio'] = df['NET_MONTHLY_INCOME']/df['PROP_VALUE']

    return df

def emp_var_mapping(df):
    df['EMPLOYEMENT_SLAB_grp'] = np.where(df['EMPLOYEMENT_SLAB']=='Professional', 'Self-Employed', df['EMPLOYEMENT_SLAB'] )
    return df

def purchase_flag(df):
    lst = ['Purchase of Ready House', 'Purchase of Flat Ready Built', 'Purchase of Plot']
    df['Purchase_flag'] = np.where(df['PURPOSE'].isin(lst), 'Non Under Construction', 'Under Construction')
    return df

def ppsqft(df):
    df['pricepersqft_builtup'] = df['PROP_VALUE']/df['Area_mod']
    df['pricepersqft_carpet'] = df['PROP_VALUE']/df['Area_modC']
    return df

def area_ratio(df):
    df['area_ratio'] = df['Area_mod']/df['Area_modC']
    return df

def inc_prop_ratio(df):
    df['inc_prop_ratio_loan_level'] = df['L_B_NET_MONTHLY_INCOME_sum']/df['PROP_VALUE']
    return df

def prop_ratio(df):
    df['prop_ratio'] = df['DECLARED_PROPERTY_VAL']/df['PROP_VALUE']
    return df

def add_additional_features(df):
    df = ppsqft(df)
    df = area_ratio(df)
    df = prop_ratio(df)
    return df

def age_check(df, age_cap):
    df = df[df['AGE']>age_cap]
    return df


# =============================================================================
# Mapping Variables
# =============================================================================
def map_var(model_df):
   
    marital_dict = {'Married':'Married','Single':'Single','Widowed':'Others','Divorced':'Others'}
   
    edu_dict = {'GRADUATE':'GRADUATE','HSC':'HSC','TILL SSC':'SSC','POST GRADUATE':'PG',
    'GRADUATE (ARTS)':'GRADUATE','GRADUATE (ENGINEER)-OTHERS':'GRADUATE',
    'POST GRADUATE (ARTS)':'PG','OTHER':'OTHER','GRADUATE (COMMERCE)':'GRADUATE',
    'DIPLOMA (Others)':'DIPLOMA','GRADUATE (SCIENCE)':'GRADUATE','PROFESSIONAL (MBA - OTH)':'PROFESSIONAL',
    'PROFESSIONAL (Others)':'PROFESSIONAL',
    'POST GRADUATE (SCIENCE)':'PG','DIPLOMA (Technical)':'DIPLOMA',
    'POST GRADUATE (COMMERCE)':'PG','POST GRADUATE (ENGINEER)-OTHERS':'PG',
    'DOCTORATE':'PROFESSIONAL',
    'GRADUATE (LAW)':'GRADUATE','GRADUATE (MEDICAL)-OTHER':'GRADUATE','PROFESSIONAL (C.A.)':'PROFESSIONAL',
    'DIPLOMA (Pharmacy)':'DIPLOMA','GRADUATE (MEDICAL)-MEDICIN':'GRADUATE',
    'POST GRADUATE (MEDICAL)-OTHER':'PG','DIPLOMA (Medical)':'DIPLOMA',
    'POST GRADUATE (MEDICAL)-MEDICIN':'PG','GRADUATE (ENGINEER)-IIT':'GRADUATE',
    'POST GRADUATE (LAW)':'PG','DIPLOMA (Computer)':'DIPLOMA','DIPLOMA (Management)':'DIPLOMA',
    'GRADUATE (MEDICAL)-AYURVED':'GRADUATE','POST GRADUATE (ENGINEER)-IIT':'PG',
    'GRADUATE (MEDICAL)-DENTAL':'GRADUATE','GRADUATE (MEDICAL)-HOMEOPATH':'GRADUATE',
    'POST GRADUATE (MEDICAL)-VETERNARY':'PG','PROFESSIONAL (I.C.W.A.)':'PROFESSIONAL',
    'PROFESSIONAL (MBA - IIM)':'PROFESSIONAL','GRADUATE (MEDICAL)-VETERNARY':'GRADUATE',
    'PROFESSIONAL (C.S.)':'PROFESSIONAL','PROFESSIONAL (ARCHITECT)':'PROFESSIONAL',
    'POST GRADUATE (MEDICAL)-DENTAL':'PG','POST GRADUATE (MEDICAL)-AYURVED':'PG',
    'POST GRADUATE (MEDICAL)-HOMEOPATH':'PG'}
   
    company_dict = {'CEHL':'CEHL','Unapproved Company':'Unapproved Company','CAP 4':'CAP4',
    'Proprietorship Firm':'Proprietorship Firm','Individual':'Individual',
    'Limited Liability Companies ( Outside India)':'Others','Partnership Firm':'Others',
    'Private Ltd. Companies( Unlisted )':'Others','Public Ltd. Companies( Listed )':'Others',
    'GOVT. BODY':'Others','Society':'Others','Public Ltd. Companies( Unlisted )':'Others',
    'Limited Liability Partnership Firm(LLP)':'Others'}
   
    industry_dict = {'Others':'Others','Govt.':'Govt','Companies (Unlisted)':'Unlisted Co',
    'Companies (Listed)':'Rest','Unincorporated association or body of individuals':'Rest',
    'Partnership':'Rest','NGO':'Rest'}
   
    buss_prof_dict = {'EDUCATION':'EDUCATION','SALES':'SALES','IT':'IT','POLICE':'POLICE'}
   
    cust_addr_dict = {'MAHARASHTRA':'WESTERN',
'RAJASTHAN':'NORTHERN',
'GOA':'WESTERN',
'HARYANA':'NORTHERN',
'TELANGANA':'SOUTH EASTERN',
'KERALA':'SOUTHERN',
'JHARKHAND':'EAST CENTRAL',
'BIHAR':'EAST CENTRAL',
'KARNATAKA':'SOUTH CENTRAL',
'ANDHRA PRADESH':'SOUTH EASTERN',
'CHHATTISGARH':'CENTRAL',
'ASSAM':'EASTERN',
'WEST BENGAL':'EASTERN',
'TAMIL NADU':'SOUTHERN',
'DELHI':'NORTHERN',
'MADHYA PRADESH':'CENTRAL',
'GUJARAT':'WESTERN',
'PUNJAB':'NORTHERN',
'HIMACHAL PRADESH':'NORTHERN',
'UTTAR PRADESH':'NORTHERN',
'ODISHA':'EAST CENTRAL',
'SIKKIM':'EASTERN',
'UTTARAKHAND':'NORTH CENTRAL',
'CHANDIGARH':'NORTHERN',
'PONDICHERRY':'SOUTHERN',
'TRIPURA':'EASTERN',

}
    model_df['INDUSTRY_TYPE'] = np.where(model_df['INDUSTRY_TYPE']=='Others', 'Uncategorised', model_df['INDUSTRY_TYPE'])
    model_df['MARITAL_STATUS_grp'] = model_df['MARITAL_STATUS'].map(marital_dict).fillna('Others')
    model_df['EDUCATIONAL_QUALIFICATION_grp'] = model_df['EDUCATIONAL_QUALIFICATION'].map(edu_dict).fillna('Others')
    model_df['COMPANY_TYPE_grp'] = model_df['COMPANY_TYPE'].map(company_dict).fillna('Others')
    model_df['INDUSTRY_TYPE_grp'] = model_df['INDUSTRY_TYPE'].map(industry_dict).fillna('Others')
    model_df['BUSS_PROF_NATURE_grp'] = model_df['BUSS_PROF_NATURE'].map(buss_prof_dict).fillna('Others')
    model_df['CUST_ADDR_STATE_grp'] = model_df['CUST_ADDR_STATE'].map(cust_addr_dict).fillna('Others')

   
    return model_df



# =============================================================================
# Getting customer attributes
# =============================================================================

def cust_attributes(df):
    df['L_B_gender_hybrid'] = df.groupby('COMP_APPL_ID')['GENDER'].transform('nunique')
    df['L_B_gender_hybrid'] = np.where(df['L_B_gender_hybrid']==1,'homogeneous', 'hybrid')
    df['C_P_existing_cust_flag'] = df.groupby('SUPER_CIF')['COMP_APPL_ID'].transform('nunique')
    df['C_P_existing_cust_flag'] = np.where(df['C_P_existing_cust_flag']==1,'New', 'Existing')

    #df = perc_cap(df, 'AGE')
    #df = perc_cap(df, 'MATURITY_AGE')
    x = df[['COMP_APPL_ID','GUAR_COAP_FLAG','GENDER','MARITAL_STATUS_grp','EDUCATIONAL_QUALIFICATION_grp',
            'INDUSTRY_TYPE_grp','COMPANY_TYPE_grp','BUSS_PROF_NATURE_grp','APPLICATION_TYPE', 'EMPLOYEMENT_SLAB_grp']]
    x = count_categorical(x, 'COMP_APPL_ID', 'L_B')
    x = x.reset_index()
    df = df.merge(x, on = 'COMP_APPL_ID', how = 'left')
    df = convert_datatypes(df, config)
    del x
   
   
    x = df[['COMP_APPL_ID', 'AGE', 'MATURITY_AGE','LTV',
            'FEMALE_INCLUSION',
            'NET_MONTHLY_INCOME','GROSS_MONTHLY_OTHER_INCOME',
            'Area_mod','Area_modC', 'income_prop_ratio']]
    x = agg_numeric(x, 'COMP_APPL_ID', 'L_B')
    x = x.reset_index()
    df = df.merge(x, on = 'COMP_APPL_ID', how = 'left')
    del x
    return df

def cust_duration(df):
    df['C_P_min_sanction_date'] = df.groupby('SUPER_CIF')['SANCTION_DATE'].transform('min')
    df['C_P_datediff_sancmin'] = (pd.to_datetime("today").normalize() - df['C_P_min_sanction_date']).dt.days
    return df

#CIBIL data processing functions
def clean_cibil_data(enq, cl):
    #used for cleaning data, file format only - no processing of variables
    enq['CUSTID|"MRN"|"LANNO"|"DATA_FLAG"|"RETRO_DATE"|"SHORT_NAME"|"ECN"|"ENQ_DATE"|"ENQ_PURPOSE"|"ENQ_AMT"|"ENQ_PURPOSE_DESC"']= enq['CUSTID|"MRN"|"LANNO"|"DATA_FLAG"|"RETRO_DATE"|"SHORT_NAME"|"ECN"|"ENQ_DATE"|"ENQ_PURPOSE"|"ENQ_AMT"|"ENQ_PURPOSE_DESC"'].astype(str)
    enq = enq['CUSTID|"MRN"|"LANNO"|"DATA_FLAG"|"RETRO_DATE"|"SHORT_NAME"|"ECN"|"ENQ_DATE"|"ENQ_PURPOSE"|"ENQ_AMT"|"ENQ_PURPOSE_DESC"'].apply(lambda z: pd.Series(z.split("|")))
    enq.columns = ['CUSTID','MRN','LANNO','DATA_FLAG','RETRO_DATE','SHORT_NAME','ECN','ENQ_DATE','ENQ_PURPOSE','ENQ_AMT','ENQ_PURPOSE_DESC']
   
   
    cl['CUSTID|"MRN"|"LANNO"|"DATA_FLAG"|"RETRO_DATE"|"REPORT_DT"|"OWNER_INDIC"|"CUR_BALANCE"|"CLOSE_DT"|"SHORT_NAME"|"ACCT_NUM"|"ACCT_TYPE"|"OPENED_DT"|"HIGH_CREDIT"|"AMT_PAST_DUE"|"PMT_START_DT"|"PMT_END_DT"|"SUIT_FILED"|"WO_SETTLED"|"P_HIST_01"|"P_HIST_02"|"P_HIST_03"|"P_HIST_04"|"P_HIST_05"|"P_HIST_06"|"P_HIST_07"|"P_HIST_08"|"P_HIST_09"|"P_HIST_10"|"P_HIST_11"|"P_HIST_12"|"P_HIST_13"|"P_HIST_14"|"P_HIST_15"|"P_HIST_16"|"P_HIST_17"|"P_HIST_18"|"P_HIST_19"|"P_HIST_20"|"P_HIST_21"|"P_HIST_22"|"P_HIST_23"|"P_HIST_24"|"P_HIST_25"|"P_HIST_26"|"P_HIST_27"|"P_HIST_28"|"P_HIST_29"|"P_HIST_30"|"P_HIST_31"|"P_HIST_32"|"P_HIST_33"|"P_HIST_34"|"P_HIST_35"|"P_HIST_36"|"V3_SCORE"|"ACCT_TYPE_DESC"|"SUIT_FILED_DESC"|"OWNER_INDIC_DESC"|"WO_SETTLED_DESC"'] = cl['CUSTID|"MRN"|"LANNO"|"DATA_FLAG"|"RETRO_DATE"|"REPORT_DT"|"OWNER_INDIC"|"CUR_BALANCE"|"CLOSE_DT"|"SHORT_NAME"|"ACCT_NUM"|"ACCT_TYPE"|"OPENED_DT"|"HIGH_CREDIT"|"AMT_PAST_DUE"|"PMT_START_DT"|"PMT_END_DT"|"SUIT_FILED"|"WO_SETTLED"|"P_HIST_01"|"P_HIST_02"|"P_HIST_03"|"P_HIST_04"|"P_HIST_05"|"P_HIST_06"|"P_HIST_07"|"P_HIST_08"|"P_HIST_09"|"P_HIST_10"|"P_HIST_11"|"P_HIST_12"|"P_HIST_13"|"P_HIST_14"|"P_HIST_15"|"P_HIST_16"|"P_HIST_17"|"P_HIST_18"|"P_HIST_19"|"P_HIST_20"|"P_HIST_21"|"P_HIST_22"|"P_HIST_23"|"P_HIST_24"|"P_HIST_25"|"P_HIST_26"|"P_HIST_27"|"P_HIST_28"|"P_HIST_29"|"P_HIST_30"|"P_HIST_31"|"P_HIST_32"|"P_HIST_33"|"P_HIST_34"|"P_HIST_35"|"P_HIST_36"|"V3_SCORE"|"ACCT_TYPE_DESC"|"SUIT_FILED_DESC"|"OWNER_INDIC_DESC"|"WO_SETTLED_DESC"'].astype(str)
    cl = cl['CUSTID|"MRN"|"LANNO"|"DATA_FLAG"|"RETRO_DATE"|"REPORT_DT"|"OWNER_INDIC"|"CUR_BALANCE"|"CLOSE_DT"|"SHORT_NAME"|"ACCT_NUM"|"ACCT_TYPE"|"OPENED_DT"|"HIGH_CREDIT"|"AMT_PAST_DUE"|"PMT_START_DT"|"PMT_END_DT"|"SUIT_FILED"|"WO_SETTLED"|"P_HIST_01"|"P_HIST_02"|"P_HIST_03"|"P_HIST_04"|"P_HIST_05"|"P_HIST_06"|"P_HIST_07"|"P_HIST_08"|"P_HIST_09"|"P_HIST_10"|"P_HIST_11"|"P_HIST_12"|"P_HIST_13"|"P_HIST_14"|"P_HIST_15"|"P_HIST_16"|"P_HIST_17"|"P_HIST_18"|"P_HIST_19"|"P_HIST_20"|"P_HIST_21"|"P_HIST_22"|"P_HIST_23"|"P_HIST_24"|"P_HIST_25"|"P_HIST_26"|"P_HIST_27"|"P_HIST_28"|"P_HIST_29"|"P_HIST_30"|"P_HIST_31"|"P_HIST_32"|"P_HIST_33"|"P_HIST_34"|"P_HIST_35"|"P_HIST_36"|"V3_SCORE"|"ACCT_TYPE_DESC"|"SUIT_FILED_DESC"|"OWNER_INDIC_DESC"|"WO_SETTLED_DESC"'].apply(lambda z: pd.Series(z.split("|")))
    cl.columns = ['CUSTID','MRN','LANNO','DATA_FLAG','RETRO_DATE','REPORT_DT','OWNER_INDIC','CUR_BALANCE','CLOSE_DT','SHORT_NAME','ACCT_NUM','ACCT_TYPE','OPENED_DT','HIGH_CREDIT','AMT_PAST_DUE','PMT_START_D','PMT_END_DT','SUIT_FILED','WO_SETTLED','P_HIST_01','P_HIST_02','P_HIST_03','P_HIST_04','P_HIST_05','P_HIST_06','P_HIST_07','P_HIST_08','P_HIST_09','P_HIST_10','P_HIST_11','P_HIST_12','P_HIST_13','P_HIST_14','P_HIST_15','P_HIST_16','P_HIST_17','P_HIST_18','P_HIST_19','P_HIST_20','P_HIST_21','P_HIST_22','P_HIST_23','P_HIST_24','P_HIST_25','P_HIST_26','P_HIST_27','P_HIST_28','P_HIST_29','P_HIST_30','P_HIST_31','P_HIST_32','P_HIST_33','P_HIST_34','P_HIST_35','P_HIST_36','V3_SCORE','ACCT_TYPE_DESC','SUIT_FILED_DESC','OWNER_INDIC_DESC','WO_SETTLED_DESC']
   
    for col in enq.columns:
        enq[col] = enq[col].str.replace('"', '')
       
    for col in cl.columns:
        cl[col] = cl[col].str.replace('"', '')
       
    enq['ENQ_AMT'] = enq['ENQ_AMT'].astype(float)
    cl['OWNER_INDIC_DESC'] = cl['OWNER_INDIC_DESC'].str.replace('\t','')
    s = ['CUR_BALANCE', 'HIGH_CREDIT','AMT_PAST_DUE','P_HIST_01','P_HIST_02','P_HIST_03','P_HIST_04','P_HIST_05','P_HIST_06','P_HIST_07','P_HIST_08','P_HIST_09','P_HIST_10','P_HIST_11','P_HIST_12','P_HIST_13','P_HIST_14','P_HIST_15','P_HIST_16','P_HIST_17','P_HIST_18','P_HIST_19','P_HIST_20','P_HIST_21','P_HIST_22','P_HIST_23','P_HIST_24','P_HIST_25','P_HIST_26','P_HIST_27','P_HIST_28','P_HIST_29','P_HIST_30','P_HIST_31','P_HIST_32','P_HIST_33','P_HIST_34','P_HIST_35','P_HIST_36','V3_SCORE']
    for i in s:
        cl[i] = cl[i].astype(float)
    del i, s, col
    return enq, cl
   
   
def cibil_data(cibil_enq, cibil_cl):
    #func is used for creating business variables, cleaning the data by creating unique keys - Bala's code
    x = ihl[['CUSTOMERID','FIRST_DISB_DATE', 'SANCTION_DATE']].drop_duplicates()
    y = lap[['CUSTOMERID','FIRST_DISB_DATE', 'SANCTION_DATE']].drop_duplicates()
    cibil_enq['MRN'] = cibil_enq['MRN'].astype(int)
    cibil_cl['MRN'] = cibil_cl['MRN'].astype(int)
    z = pd.concat([x, y], axis = 0)
    del x, y
    z['CUSTOMERID'] = pd.to_numeric(z['CUSTOMERID'])
    cibil_enq = cibil_enq.merge(z, left_on = 'MRN', right_on = 'CUSTOMERID', how = 'right', indicator = True)
    cibil_cl = cibil_cl.merge(z, left_on = 'MRN', right_on = 'CUSTOMERID', how = 'right', indicator = True)
   
    def cibil_tidy_dates(df, lst):
        df[lst] = df[lst].apply(pd.to_datetime)
        return df
    lst = ['FIRST_DISB_DATE', 'ENQ_DATE', 'RETRO_DATE', 'SANCTION_DATE']
    cibil_enq = cibil_tidy_dates(cibil_enq, lst)
    lst = ['OPENED_DT', 'FIRST_DISB_DATE', 'RETRO_DATE','REPORT_DT', 'SANCTION_DATE','PMT_START_D','CLOSE_DT','PMT_END_DT']
    cibil_cl = cibil_tidy_dates(cibil_cl, lst)
    del lst
    cibil_cl['CUSTOMERID'] = cibil_cl['CUSTOMERID'].astype(str)
    cibil_cl['MRN'] = cibil_cl['MRN'].astype(str)
    cibil_enq['CUSTOMERID'] = cibil_enq['CUSTOMERID'].astype(str)
    cibil_enq['MRN'] = cibil_enq['MRN'].astype(str)
    #retro date: The date when data is pulled for loan status (like as of date status)
    cibil_cl['sanc_retro'] = (cibil_cl['SANCTION_DATE']-cibil_cl['RETRO_DATE']).dt.days
    cibil_cl['disb_retro'] = (cibil_cl['FIRST_DISB_DATE']-cibil_cl['RETRO_DATE']).dt.days
    #open date: open date of any other past loan
    cibil_cl['sanc_open'] = (cibil_cl['SANCTION_DATE']-cibil_cl['OPENED_DT']).dt.days
    cibil_cl['disb_open'] = (cibil_cl['FIRST_DISB_DATE']-cibil_cl['OPENED_DT']).dt.days
    #report date: when the loan is reported fist to cibil
    cibil_cl['sanc_report'] = (cibil_cl['SANCTION_DATE']-cibil_cl['REPORT_DT']).dt.days
    cibil_cl['disb_report'] = (cibil_cl['FIRST_DISB_DATE']-cibil_cl['REPORT_DT']).dt.days
    #pmt start date, last emi of that loan
    cibil_cl['sanc_pmtstart'] = (cibil_cl['SANCTION_DATE']-cibil_cl['PMT_START_D']).dt.days
    cibil_cl['disb_pmtstart'] = (cibil_cl['FIRST_DISB_DATE']-cibil_cl['PMT_START_D']).dt.days
    cibil_cl['sanc_pmtend'] = (cibil_cl['SANCTION_DATE']-cibil_cl['PMT_END_DT']).dt.days
    cibil_cl['disb_pmtend'] = (cibil_cl['FIRST_DISB_DATE']-cibil_cl['PMT_END_DT']).dt.days
    cibil_enq['sanc_enq'] = (cibil_enq['SANCTION_DATE']-cibil_enq['ENQ_DATE']).dt.days
    cibil_enq['disb_enq'] = (cibil_enq['FIRST_DISB_DATE']-cibil_enq['ENQ_DATE']).dt.days
    cibil_enq['sanc_retro'] = (cibil_enq['SANCTION_DATE']-cibil_enq['RETRO_DATE']).dt.days
    cibil_enq['disb_retro'] = (cibil_enq['FIRST_DISB_DATE']-cibil_enq['RETRO_DATE']).dt.days
    #cibil_cl = cibil_cl[['CUSTOMERID', 'OPENED_DT', 'FIRST_DISB_DATE', 'SANCTION_DATE', 'RETRO_DATE','_merge']]
    #cibil_enq = cibil_enq[['CUSTOMERID', 'ENQ_DATE', 'FIRST_DISB_DATE',  '_merge']]
    cibil_cl['disb_closedt'] = (cibil_cl['FIRST_DISB_DATE']-cibil_cl['CLOSE_DT']).dt.days
    cibil_cl['sanc_closedt'] = (cibil_cl['SANCTION_DATE']-cibil_cl['CLOSE_DT']).dt.days

    cibil_cl['flagclosepmtstart'] = np.where(cibil_cl['CLOSE_DT']=='1900-01-01 00:00:00', 1,0 )
    cibil_enq = cibil_enq.drop_duplicates()
    cibil_cl = cibil_cl.drop_duplicates()
    cibil_cl['data_period_avlb_days'] = -(cibil_cl['disb_pmtstart'] - cibil_cl['disb_pmtend'])
    cibil_cl['data_period_avlb_months'] = -(cibil_cl['disb_pmtstart'] - cibil_cl['disb_pmtend'])/30
    cibil_cl['data_period_avlb_months'] = np.ceil(cibil_cl['data_period_avlb_months'])
   
    #apply filters
    #1. dont need future data
    cibil_cl = cibil_cl[cibil_cl['OPENED_DT']<cibil_cl['SANCTION_DATE']]
   
    cibil_cl['after2015'] = np.where(cibil_cl['FIRST_DISB_DATE']>'2014-12-31 00:00:00', 1, 0)
    df = cibil_cl.copy()
    ## Duplicates at Unique Identifier level
    subs = 'P_HIST'
    payment_cols=[i for i in list(cibil_cl) if re.search(subs,i)]
    for col in payment_cols:
        cibil_cl[col] = np.where(cibil_cl[col]==-1, 'FLP', (np.where(cibil_cl[col]==-2, 'NA', cibil_cl[col])))
       
    #cibil_cl = cibil_cl[(cibil_cl['disb_retro']>-30) & (cibil_cl['disb_retro']<30)]
    #minimum loan amount has to be greater than 1000
    cibil_cl2 = cibil_cl[cibil_cl['HIGH_CREDIT']>1000]
    #cibil_cl2['Key_derived']=cibil_cl2['MRN']+"_"+cibil_cl2["LANNO"]+"_"+cibil_cl2['REPORT_DT'].map(str)
    cibil_cl2=cibil_cl2[~cibil_cl2["ACCT_TYPE"].isnull()]
    #cibil_cl2["Account_type_description"]=cibil_cl2['ACCT_TYPE'].map(Account_type_description.set_index('ACCT_TYPE')['ACCT_TYPE_DESC'])
    # Loan Identifier creation
    cibil_cl2["Loan_identifier"]=cibil_cl2["ACCT_TYPE_DESC"]+"_"+cibil_cl2["OPENED_DT"].map(str)+"_"+cibil_cl2["HIGH_CREDIT"].map(str)

   
    # Cleaning closing date

   
   
# =============================================================================
#     Cosumer_bureau_overall_v1.loc[Cosumer_bureau_overall_v1["close_dt"]=="1900-01-01 00:00:00","close_dt"]=None
#     len(Cosumer_bureau_overall_v1[Cosumer_bureau_overall_v1["close_dt"].isnull()])
# =============================================================================
   
    # Unique Identifier - Cutomer ID + Loan ID + Reporting date
   
    cibil_cl2["Key_derived"]=cibil_cl2["MRN"]+"_"+cibil_cl2["Loan_identifier"]+"_"+cibil_cl2["REPORT_DT"].map(str)
   
    ## Duplicates at Unique Identifier level
   
    dups=cibil_cl2[cibil_cl2["Key_derived"].duplicated()]
    dups_data=cibil_cl2[cibil_cl2["Key_derived"].isin(dups["Key_derived"])].sort_values("Key_derived").reset_index()
    dups_data.head()
   
    ## Cleaning Duplicates at Key_derived level
    '''
    1. Considering the Monthly DPD info with Max Current balance at Customer-Loan-Reporting date level
    2. Considering the max DPD at Customer-Loan-Reporting date-Current balance level
    '''
   
    # 1. Considering the Monthly DPD info with Max Current balance at Customer-Loan-Reporting date level
   
   
   
    dups_data_cleaned=dups_data.groupby(["Key_derived","MRN","Loan_identifier","REPORT_DT","ACCT_TYPE_DESC","ACCT_TYPE","OPENED_DT","HIGH_CREDIT"]).agg({"CUR_BALANCE":"max"}).reset_index()
    dups_data_cleaned.head()
    list(dups_data_cleaned)
   
   
    dups_data_cleaned_v1=dups_data.merge(dups_data_cleaned,on=["Key_derived","MRN","Loan_identifier","REPORT_DT","ACCT_TYPE_DESC","ACCT_TYPE","OPENED_DT","HIGH_CREDIT","CUR_BALANCE"],how="inner")
   
    # 2. Considering the max DPD at Customer-Loan-Reporting date-Current balance level
    for col in payment_cols:
        dups_data_cleaned_v1[col] = dups_data_cleaned_v1[col].astype(float, errors = 'ignore')
    dups_data_cleaned_v1["DPD_score"]=dups_data_cleaned_v1[payment_cols].sum(axis=1, numeric_only = True)


    dups_data_cleaned_v1.head()
    temp_df=dups_data_cleaned_v1.groupby(["Key_derived"])
    dups_data_cleaned_v2 = dups_data_cleaned_v1.groupby(["Key_derived"]).head(1)
    dups_data_cleaned_v2.head()
   
   
    ## Final Cleaned Burea data
   
    Non_dups=cibil_cl2[~cibil_cl2["Key_derived"].isin(dups["Key_derived"])]
    len(Non_dups[["Key_derived"]].drop_duplicates())
    len(Non_dups)
   
    Final_bureau_data_cleaned=Non_dups.append(dups_data_cleaned_v2[list(Non_dups)]).reset_index(drop=True)
    len(Final_bureau_data_cleaned[["Key_derived"]].drop_duplicates())
    len(Final_bureau_data_cleaned)
   
# =============================================================================
#     # Account type info
#    
#     Final_bureau_data_cleaned["Customer_loancombo"]=Final_bureau_data_cleaned["member_reference"]+"_"+Final_bureau_data_cleaned["Loan_identifier"]
#     len(Final_bureau_data_cleaned["Key_derived"].drop_duplicates())
#    
#     Account_type_counts_info=Final_bureau_data_cleaned.groupby(["Loan_type_description"]).agg({"Customer_loancombo":"nunique","Key_derived":"count"}).reset_index()
#     Account_type_counts_info.head()
#
# =============================================================================
    df = Final_bureau_data_cleaned.copy()
   
    x = df[['Key_derived','PMT_START_D','P_HIST_01','P_HIST_02','P_HIST_03','P_HIST_04','P_HIST_05','P_HIST_06','P_HIST_07','P_HIST_08','P_HIST_09','P_HIST_10','P_HIST_11','P_HIST_12','P_HIST_13','P_HIST_14','P_HIST_15','P_HIST_16','P_HIST_17','P_HIST_18','P_HIST_19','P_HIST_20','P_HIST_21','P_HIST_22','P_HIST_23','P_HIST_24','P_HIST_25','P_HIST_26','P_HIST_27','P_HIST_28','P_HIST_29','P_HIST_30','P_HIST_31','P_HIST_32','P_HIST_33','P_HIST_34','P_HIST_35','P_HIST_36' ]]
    x = x.drop_duplicates()
    x = x.set_index(['Key_derived','PMT_START_D']).stack(dropna = False).reset_index(name = 'DPD_days')
    x['PMT_CALENDAR_MONTH_COHORT'] = x['PMT_START_D'].swifter.apply(lambda x: x.strftime('%Y-%m'))
    x['sequence']=x.groupby('Key_derived').cumcount()
    x['PMT_CALENDAR_MONTH'] = x.swifter.apply(lambda z: z['PMT_START_D']-relativedelta(months = z['sequence']), axis = 1)
    df2 = df[['Key_derived','PMT_END_DT', 'FIRST_DISB_DATE','after2015','flagclosepmtstart',
              'ACCT_TYPE', 'Loan_identifier', 'ACCT_TYPE_DESC', 'HIGH_CREDIT','CUSTID', 'SANCTION_DATE','MRN','OPENED_DT']].drop_duplicates()
    x = x.merge(df2, on = 'Key_derived', how = 'inner')
    x['disb_pmtend_diff'] = (x['FIRST_DISB_DATE'] - x['PMT_CALENDAR_MONTH']).dt.days
    x['disb_pmtend_diff'] = np.ceil(x['disb_pmtend_diff']/30)
    #cibil_cl2['CLOSE_DT'] = np.where(cibil_cl2['CLOSE_DT']=='1900-01-01 00:00:00', '', cibil_cl2['CLOSE_DT'])
    return x, cibil_enq, df
   
def get_cibil_features_cl(x):
    #x['DPD_days'].isin(['FLP','NA'])
    #z2 = x[~(z1)]
    z2=x.copy()
    y = z2[['MRN', 'Key_derived', 'Loan_identifier', 'FIRST_DISB_DATE', 'ACCT_TYPE_DESC',
           'HIGH_CREDIT', 'OPENED_DT', 'ACCT_TYPE']].drop_duplicates()
    z2['sequence2']=z2.groupby('Key_derived').cumcount()
    #z2['disb_open_diff']
    y1 = z2[z2['flagclosepmtstart']==0]
    y1 = y1[y1['disb_pmtend_diff']<37]
    y2 = y1.groupby('Key_derived')['sequence2'].count().reset_index()
    y1 = z2[z2['after2015']==0]
    y1 = y1[y1['disb_pmtend_diff']<37]
    y2 = y1.groupby('Key_derived')['sequence2'].count().reset_index()
    y1 = z2[z2['flagclosepmtstart']==1]
    y1 = y1[y1['disb_pmtend_diff']<37]

    y2 = y1.groupby('Key_derived')['sequence2'].count().reset_index()

    # =============================================================================
    #     Variable Preparation
    # Credit Maturity
    # Credit Vintage
    # Age of the Oldest account in the Bureau as of Loan sanction date
    #  1. Loant Type level and Overall In Years
    #  2. Loant Type level and Overall In Months
    # Overall Vintage and Loan Type level Vintage In Years
    # =============================================================================
    # Credit Vintage at Loan Type level in Years
    print(z2.columns)
    z2_bkp=z2.copy()
    #6 May 12 am
    z2=z2[['MRN','Key_derived','Loan_identifier',
        'SANCTION_DATE',
        #'cur_balance',
        # 'reporting_month',
        # 'Reporting_year_month',
        "ACCT_TYPE_DESC",
        "HIGH_CREDIT",
        "OPENED_DT",
        "ACCT_TYPE",
        #"close_dt"
        ]].drop_duplicates().reset_index(drop=True)
   
    overall_credit_vintage=z2.groupby(["MRN","SANCTION_DATE","ACCT_TYPE_DESC"]).agg({"OPENED_DT":"min"}).reset_index()
    overall_credit_vintage.columns
    overall_credit_vintage.columns=["MRN",'FIRST_DISB_DATE',"ACCT_TYPE_DESC","Oldest_account_opening_date"]
    overall_credit_vintage['Credit_vintage']=((overall_credit_vintage["FIRST_DISB_DATE"]-overall_credit_vintage['Oldest_account_opening_date'])/np.timedelta64(1, 'D'))/365
   
    # Summarizing the Values at Loan Type level in Columns and Calculating the Max Overall Vintage
    overall_credit_vintage_v1=overall_credit_vintage.pivot_table(index=["MRN",'FIRST_DISB_DATE'],values="Credit_vintage",columns=overall_credit_vintage["ACCT_TYPE_DESC"],aggfunc="max").reset_index()
    #overall_credit_vintage_v1.columns=["MRN","CUSTID",'FIRST_DISB_DATE',"Business loans_credit_vintage(years)","Credit Card_credit_vintage(years)","HL_credit_vintage(years)","LAP_credit_vintage(years)","Others_credit_vintage(years)","Personal Loan_credit_vintage(years)","Vehicular loans_credit_vintage(years)"]
    overall_credit_vintage_v1["Overall_credit_vintage(years)"]=overall_credit_vintage_v1[[ 'Auto Loan',
       'BL Against Bank Deposits', 'BL-General', 'BL-PS-Agriculture',
       'BL-PS-Others', 'BL-PS-Small Business', 'BNFCF-General',
       'BNFCF-PS-Agriculture', 'BNFCF-PS-Small Business',
       'Business Loan - Secured', 'Business Loan - Unsecured',
       'Commercial Vehicle Loans', 'Construction Equipment Loan',
       'Consumer Loan', 'Corporate Credit card', 'Credit Card',
       'Education Loan', 'Gold Loan', 'Housing Loan', 'Kisan Credit Card',
       'Leasing', 'Loan Against Bank Deposits',
       'Loan Against shares/Securities', 'Loan to Professional',
       'Microfinance-Business Loan', 'Microfinance-Others',
       'Microfinance-Personal Loan', 'Mudra Loans ? Shishu / Kishor / Tarun',
       'Non Funded Credit Facility', 'Others', 'Overdraft', 'Personal Loan',
       'Property Loan', 'Secured Credit Card', 'Tractor Loan',
       'Two Wheeler Loan', 'Used Car Loan']].max(axis=1,skipna=True)
    overall_credit_vintage_v1.head()
               
    #Overall Vintage and Loan Type level Vintage In Months
    def month_calc(d2,d1):
        delta=relativedelta(d2,d1)
        monthdiff=delta.years * 12 + delta.months
        return monthdiff
    z2.columns=['MRN',
         'Key_derived',
         'Loan_identifier',
         'FIRST_DISB_DATE',
         'ACCT_TYPE_DESC',
         'HIGH_CREDIT',
         'OPENED_DT',
         'ACCT_TYPE']
    overall_credit_vintage_months=z2.groupby(["MRN",'FIRST_DISB_DATE',"ACCT_TYPE_DESC"]).agg({"OPENED_DT":"min"}).reset_index()
    overall_credit_vintage_months.columns=["MRN",'FIRST_DISB_DATE',"ACCT_TYPE_DESC","Oldest_account_opening_date"]
    overall_credit_vintage_months['Credit_vintage']=overall_credit_vintage.apply(lambda x :month_calc(x['FIRST_DISB_DATE'], x['Oldest_account_opening_date']),axis=1)
    overall_credit_vintage_months.head()
   
    # Summarizing the Values at Loan Type level in Columns and Calculating the Max Overall Vintage
    overall_credit_vintage_months_v1=overall_credit_vintage_months.pivot_table(index=["MRN",'FIRST_DISB_DATE'],values="Credit_vintage",columns=overall_credit_vintage["ACCT_TYPE_DESC"],aggfunc="max").reset_index()
    #overall_credit_vintage_months_v1.columns=["cust_id","proposal_id","App_data_sanction_date","Business loans_credit_vintage(months)","Credit Card_credit_vintage(months)","HL_credit_vintage(months)","LAP_credit_vintage(months)","Others_credit_vintage(months)","Personal Loan_credit_vintage(months)","Vehicular loans_credit_vintage(months)"]
    overall_credit_vintage_months_v1["Overall_credit_vintage(months)"]=overall_credit_vintage_months_v1[['Auto Loan',
       'BL Against Bank Deposits', 'BL-General', 'BL-PS-Agriculture',
       'BL-PS-Others', 'BL-PS-Small Business', 'BNFCF-General',
       'BNFCF-PS-Agriculture', 'BNFCF-PS-Small Business',
       'Business Loan - Secured', 'Business Loan - Unsecured',
       'Commercial Vehicle Loans', 'Construction Equipment Loan',
       'Consumer Loan', 'Corporate Credit card', 'Credit Card',
       'Education Loan', 'Gold Loan', 'Housing Loan', 'Kisan Credit Card',
       'Leasing', 'Loan Against Bank Deposits',
       'Loan Against shares/Securities', 'Loan to Professional',
       'Microfinance-Business Loan', 'Microfinance-Others',
       'Microfinance-Personal Loan', 'Mudra Loans ? Shishu / Kishor / Tarun',
       'Non Funded Credit Facility', 'Others', 'Overdraft', 'Personal Loan',
       'Property Loan', 'Secured Credit Card', 'Tractor Loan',
       'Two Wheeler Loan', 'Used Car Loan']].max(axis=1,skipna=True)
    overall_credit_vintage_months_v1.head()

    #credit vintage summary
    overall_credit_vintage_summary=overall_credit_vintage_v1.merge(overall_credit_vintage_months_v1,on=["MRN",'FIRST_DISB_DATE'])
    overall_credit_vintage_summary.head()
   
    # =============================================================================
    #     Total Tradelines
    #     Total Tradelines taken till before the sanctioned date
    #    
    #     Tradelines at Loan type level
    #     Overall Tradelines with and without CC
    # =============================================================================
    # Loan Type Tradelines
    Loan_type_tradelines=z2.groupby(["MRN",'FIRST_DISB_DATE',"ACCT_TYPE_DESC"]).agg({'Loan_identifier':'nunique'}).reset_index()
    Loan_type_tradelines_v1=Loan_type_tradelines.pivot_table(index=["MRN"],columns=[Loan_type_tradelines['ACCT_TYPE_DESC']],values=['Loan_identifier'],aggfunc='sum').reset_index()
    #Loan_type_tradelines_v1.columns = ["".join(str(x)) for x in Loan_type_tradelines_v1.columns.ravel()]
    Loan_type_tradelines_v1.columns=["MRN",'Auto Loan', 'BL Against Bank Deposits', 'BL-General',
       'BL-PS-Agriculture', 'BL-PS-Others', 'BL-PS-Small Business',
       'BNFCF-General', 'BNFCF-PS-Agriculture', 'BNFCF-PS-Small Business',
       'Business Loan - Secured', 'Business Loan - Unsecured',
       'Commercial Vehicle Loans', 'Construction Equipment Loan',
       'Consumer Loan', 'Corporate Credit card', 'Credit Card',
       'Education Loan', 'Gold Loan', 'Housing Loan', 'Kisan Credit Card',
       'Leasing', 'Loan Against Bank Deposits',
       'Loan Against shares/Securities', 'Loan to Professional',
       'Microfinance-Business Loan', 'Microfinance-Others',
       'Microfinance-Personal Loan', 'Mudra Loans ? Shishu / Kishor / Tarun',
       'Non Funded Credit Facility', 'Others', 'Overdraft', 'Personal Loan',
       'Property Loan', 'Secured Credit Card', 'Tractor Loan',
       'Two Wheeler Loan', 'Used Car Loan']
   
    # Total Tradelines
    Loan_type_tradelines_v1["Total_tradelines"]=Loan_type_tradelines_v1[['Auto Loan', 'BL Against Bank Deposits', 'BL-General',
       'BL-PS-Agriculture', 'BL-PS-Others', 'BL-PS-Small Business',
       'BNFCF-General', 'BNFCF-PS-Agriculture', 'BNFCF-PS-Small Business',
       'Business Loan - Secured', 'Business Loan - Unsecured',
       'Commercial Vehicle Loans', 'Construction Equipment Loan',
       'Consumer Loan', 'Corporate Credit card', 'Credit Card',
       'Education Loan', 'Gold Loan', 'Housing Loan', 'Kisan Credit Card',
       'Leasing', 'Loan Against Bank Deposits',
       'Loan Against shares/Securities', 'Loan to Professional',
       'Microfinance-Business Loan', 'Microfinance-Others',
       'Microfinance-Personal Loan', 'Mudra Loans ? Shishu / Kishor / Tarun',
       'Non Funded Credit Facility', 'Others', 'Overdraft', 'Personal Loan',
       'Property Loan', 'Secured Credit Card', 'Tractor Loan',
       'Two Wheeler Loan', 'Used Car Loan']].sum(axis = 1, skipna = True)
    Loan_type_tradelines_v1["Total_tradelines_without_CC"]=Loan_type_tradelines_v1[['Auto Loan', 'BL Against Bank Deposits', 'BL-General',
       'BL-PS-Agriculture', 'BL-PS-Others', 'BL-PS-Small Business',
       'BNFCF-General', 'BNFCF-PS-Agriculture', 'BNFCF-PS-Small Business',
       'Business Loan - Secured', 'Business Loan - Unsecured',
       'Commercial Vehicle Loans', 'Construction Equipment Loan',
       'Consumer Loan',
       'Education Loan', 'Gold Loan', 'Housing Loan',
       'Leasing', 'Loan Against Bank Deposits',
       'Loan Against shares/Securities', 'Loan to Professional',
       'Microfinance-Business Loan', 'Microfinance-Others',
       'Microfinance-Personal Loan', 'Mudra Loans ? Shishu / Kishor / Tarun',
       'Non Funded Credit Facility', 'Others', 'Overdraft', 'Personal Loan',
       'Property Loan',  'Tractor Loan',
       'Two Wheeler Loan', 'Used Car Loan']].sum(axis = 1, skipna = True)
    Loan_type_tradelines_v1.head()
   
    # =============================================================================
    #         Credit Hungriness
    #     Accounts opened in the L12M at Loan Type level and Overall level
    #    
    #     Account Related Metrics
    #     Total Accounts opened in the L12M
    # =============================================================================
    Accounts_in_L12M=z2[(((z2["FIRST_DISB_DATE"]-z2["OPENED_DT"])/np.timedelta64(1, 'D'))<=365) & (((z2["FIRST_DISB_DATE"]-z2["OPENED_DT"])/np.timedelta64(1, 'D'))>0)]
    Accounts_in_L12M_loan_type=Accounts_in_L12M.groupby(["MRN",'FIRST_DISB_DATE',"ACCT_TYPE_DESC"]).agg({'Key_derived':'nunique'}).reset_index()
    Accounts_in_L12M_loan_type_v1=Accounts_in_L12M_loan_type.pivot_table(index=["MRN"],columns=[Accounts_in_L12M_loan_type['ACCT_TYPE_DESC']],values=['Key_derived'],aggfunc='sum').reset_index()
    #Accounts_in_L12M_loan_type_v1.columns = ["".join(str(x)) for x in Accounts_in_L12M_loan_type_v1.columns.ravel()]
    Accounts_in_L12M_loan_type_v1.columns=["MRN",'Auto Loan_L12M', 'BL Against Bank Deposits_L12M', 'BL-General_L12M',
       'BL-PS-Agriculture_L12M', 'BL-PS-Others_L12M', 'BL-PS-Small Business_L12M',
       'BNFCF-General_L12M', 'BNFCF-PS-Small Business_L12M', 'Business Loan - Secured_L12M',
       'Business Loan - Unsecured_L12M', 'Commercial Vehicle Loans_L12M',
       'Construction Equipment Loan_L12M', 'Consumer Loan_L12M', 'Corporate Credit card_L12M',
       'Credit Card_L12M', 'Education Loan_L12M', 'Gold Loan_L12M', 'Housing Loan_L12M',
       'Kisan Credit Card_L12M', 'Leasing_L12M', 'Loan Against Bank Deposits_L12M',
       'Loan Against shares/Securities_L12M', 'Loan to Professional_L12M',
       'Microfinance-Others_L12M', 'Mudra Loans ? Shishu / Kishor / Tarun_L12M',
       'Non Funded Credit Facility_L12M', 'Others_L12M', 'Overdraft_L12M', 'Personal Loan_L12M',
       'Property Loan_L12M', 'Secured Credit Card_L12M', 'Tractor Loan_L12M',
       'Two Wheeler Loan_L12M', 'Used Car Loan_L12M']
     
    Accounts_in_L12M_loan_type_v1["Accounts_opened_in_L12m"]=Accounts_in_L12M_loan_type_v1[['Auto Loan_L12M', 'BL Against Bank Deposits_L12M', 'BL-General_L12M',
       'BL-PS-Agriculture_L12M', 'BL-PS-Others_L12M', 'BL-PS-Small Business_L12M',
       'BNFCF-General_L12M', 'BNFCF-PS-Small Business_L12M', 'Business Loan - Secured_L12M',
       'Business Loan - Unsecured_L12M', 'Commercial Vehicle Loans_L12M',
       'Construction Equipment Loan_L12M', 'Consumer Loan_L12M', 'Corporate Credit card_L12M',
       'Credit Card_L12M', 'Education Loan_L12M', 'Gold Loan_L12M', 'Housing Loan_L12M',
       'Kisan Credit Card_L12M', 'Leasing_L12M', 'Loan Against Bank Deposits_L12M',
       'Loan Against shares/Securities_L12M', 'Loan to Professional_L12M',
       'Microfinance-Others_L12M', 'Mudra Loans ? Shishu / Kishor / Tarun_L12M',
       'Non Funded Credit Facility_L12M', 'Others_L12M', 'Overdraft_L12M', 'Personal Loan_L12M',
       'Property Loan_L12M', 'Secured Credit Card_L12M', 'Tractor Loan_L12M',
       'Two Wheeler Loan_L12M', 'Used Car Loan_L12M']].sum(axis = 1, skipna = True)
    Accounts_in_L12M_loan_type_v1.head()
    #Total Accounts opened in the L6M
    Accounts_in_L6M=z2[(((z2["FIRST_DISB_DATE"]-z2["OPENED_DT"])/np.timedelta64(1, 'D'))<=180) & (((z2["FIRST_DISB_DATE"]-z2["OPENED_DT"])/np.timedelta64(1, 'D'))>0)]
    Accounts_in_L6M_loan_type=Accounts_in_L6M.groupby(["MRN",'FIRST_DISB_DATE',"ACCT_TYPE_DESC"]).agg({'Key_derived':'nunique'}).reset_index()
    Accounts_in_L6M_loan_type_v1=Accounts_in_L6M_loan_type.pivot_table(index=["MRN"],columns=[Accounts_in_L6M_loan_type['ACCT_TYPE_DESC']],values=['Key_derived'],aggfunc='sum').reset_index()
    #Accounts_in_L6M_loan_type_v1.columns = ["".join(str(x)) for x in Accounts_in_L6M_loan_type_v1.columns.ravel()]
    len(Accounts_in_L6M_loan_type_v1.columns.tolist())
    Accounts_in_L6M_loan_type_v1.columns=["MRN",'Auto Loan_L6M',
    'BL Against Bank Deposits_L6M',
    'BL-General_L6M',
    'BL-PS-Agriculture_L6M',
    'BL-PS-Others_L6M',
    'BL-PS-Small Business_L6M',
    'BNFCF-General_L6M',
    'BNFCF-PS-Small Business_L6M',
    'Business Loan - Unsecured_L6M',
    'Commercial Vehicle Loans_L6M',
    'Construction Equipment Loan_L6M',
    'Consumer Loan_L6M',
    'Corporate Credit card_L6M',
    'Credit Card_L6M',
    'Education Loan_L6M',
    'Gold Loan_L6M',
    'Housing Loan_L6M',
    'Kisan Credit Card_L6M',
    'Loan Against Bank Deposits_L6M',
    'Loan Against shares/Securities_L6M',
    'Loan to Professional_L6M',
    'Microfinance-Others_L6M',
    'Mudra Loans ? Shishu / Kishor / Tarun_L6M',
    'Non Funded Credit Facility_L6M',
    'Others_L6M',
    'Overdraft_L6M',
    'Personal Loan_L6M',
    'Property Loan_L6M',
    'Secured Credit Card_L6M',
    'Tractor Loan_L6M',
    'Two Wheeler Loan_L6M',
    'Used Car Loan_L6M']
    Accounts_in_L6M_loan_type_v1["Accounts_opened_in_L6m"]=Accounts_in_L6M_loan_type_v1[['Auto Loan_L6M',
    'BL Against Bank Deposits_L6M',
    'BL-General_L6M',
    'BL-PS-Agriculture_L6M',
    'BL-PS-Others_L6M',
    'BL-PS-Small Business_L6M',
    'BNFCF-General_L6M',
    'BNFCF-PS-Small Business_L6M',
    'Commercial Vehicle Loans_L6M',
    'Construction Equipment Loan_L6M',
    'Consumer Loan_L6M',
    'Credit Card_L6M',
    'Education Loan_L6M',
    'Gold Loan_L6M',
    'Housing Loan_L6M',
    'Kisan Credit Card_L6M',
    'Loan Against Bank Deposits_L6M',
    'Loan Against shares/Securities_L6M',
    'Loan to Professional_L6M',
    'Microfinance-Others_L6M',
    'Mudra Loans ? Shishu / Kishor / Tarun_L6M',
    'Non Funded Credit Facility_L6M',
    'Others_L6M',
    'Overdraft_L6M',
    'Personal Loan_L6M',
    'Property Loan_L6M',
    'Secured Credit Card_L6M',
    'Tractor Loan_L6M',
    'Two Wheeler Loan_L6M',
    'Used Car Loan_L6M']].sum(axis = 1, skipna = True)
    Accounts_in_L6M_loan_type_v1.head()
    #Total Accounts opened in the L3M
    Accounts_in_L3M=z2[(((z2["FIRST_DISB_DATE"]-z2["OPENED_DT"])/np.timedelta64(1, 'D'))<=90) & (((z2["FIRST_DISB_DATE"]-z2["OPENED_DT"])/np.timedelta64(1, 'D'))>0)]    
    Accounts_in_L3M_loan_type=Accounts_in_L3M.groupby(["MRN",'FIRST_DISB_DATE',"ACCT_TYPE_DESC"]).agg({'Key_derived':'nunique'}).reset_index()
    Accounts_in_L3M_loan_type_v1=Accounts_in_L3M_loan_type.pivot_table(index=["MRN"],columns=[Accounts_in_L3M_loan_type['ACCT_TYPE_DESC']],values=['Key_derived'],aggfunc='sum').reset_index()
    #ccounts_in_L3M_loan_type_v1.columns = ["".join(str(x)) for x in Accounts_in_L3M_loan_type_v1.columns.ravel()]
    len(Accounts_in_L3M_loan_type_v1.columns)
    Accounts_in_L3M_loan_type_v1.columns=["MRN",'Auto Loan_L3M',
    'BL Against Bank Deposits_L3M',
    'BL-General_L3M',
    'BL-PS-Agriculture_L3M',
    'BL-PS-Others_L3M',
    'BL-PS-Small Business_L3M',
    'BNFCF-General_L3M',
    'BNFCF-PS-Small Business_L3M',
    'Commercial Vehicle Loans_L3M',
    'Construction Equipment Loan_L3M',
    'Consumer Loan_L3M',
    'Credit Card_L3M',
    'Education Loan_L3M',
    'Gold Loan_L3M',
    'Housing Loan_L3M',
    'Kisan Credit Card_L3M',
    'Loan Against Bank Deposits_L3M',
    'Loan Against shares/Securities_L3M',
    'Loan to Professional_L3M',
    'Mudra Loans ? Shishu / Kishor / Tarun_L3M',
    'Others_L3M',
    'Overdraft_L3M',
    'Personal Loan_L3M',
    'Property Loan_L3M',
    'Secured Credit Card_L3M',
    'Tractor Loan_L3M',
    'Two Wheeler Loan_L3M',
    'Used Car Loan_L3M'
    ]
    Accounts_in_L3M_loan_type_v1["Accounts_opened_in_L3m"]=Accounts_in_L3M_loan_type_v1[['Auto Loan_L3M',
    'BL Against Bank Deposits_L3M',
    'BL-General_L3M',
    'BL-PS-Agriculture_L3M',
    'BL-PS-Others_L3M',
    'BL-PS-Small Business_L3M',
    'BNFCF-General_L3M',
    'BNFCF-PS-Small Business_L3M',
    'Commercial Vehicle Loans_L3M',
    'Construction Equipment Loan_L3M',
    'Consumer Loan_L3M',
    'Credit Card_L3M',
    'Education Loan_L3M',
    'Gold Loan_L3M',
    'Housing Loan_L3M',
    'Kisan Credit Card_L3M',
    'Loan Against Bank Deposits_L3M',
    'Loan Against shares/Securities_L3M',
    'Loan to Professional_L3M',
    'Mudra Loans ? Shishu / Kishor / Tarun_L3M',
    'Others_L3M',
    'Overdraft_L3M',
    'Personal Loan_L3M',
    'Property Loan_L3M',
    'Secured Credit Card_L3M',
    'Tractor Loan_L3M',
    'Two Wheeler Loan_L3M',
    'Used Car Loan_L3M']].sum(axis = 1, skipna = True)
    Accounts_in_L3M_loan_type_v1.head()

    Accounts_summary=Accounts_in_L12M_loan_type_v1.merge(Accounts_in_L6M_loan_type_v1.merge(Accounts_in_L3M_loan_type_v1,on=["MRN"],how="left"),on=["MRN"],how="left")
    Accounts_summary.head()
    return Accounts_summary, overall_credit_vintage_summary, Loan_type_tradelines_v1

def get_cibil_features_enq(cibil_enq):
    Enquiries_L12m_31_to_395=cibil_enq[(cibil_enq["sanc_enq"]>30)&(cibil_enq["sanc_enq"]<=395)]
    Enquiries_L12m_31_to_395.head()
    Enquiries_L12m_31_to_395_v1=Enquiries_L12m_31_to_395.groupby(["MRN","SANCTION_DATE","ENQ_PURPOSE_DESC"]).agg({"ENQ_DATE":"nunique"}).reset_index()
    Enquiries_L12m_31_to_395_v1.head()
   
    Enquiries_L12m_31_to_395_v2=Enquiries_L12m_31_to_395_v1.pivot_table(index=["MRN","SANCTION_DATE"],columns=Enquiries_L12m_31_to_395_v1["ENQ_PURPOSE_DESC"],values="ENQ_DATE",aggfunc=sum).reset_index()
    Enquiries_L12m_31_to_395_v2.head()
   
    Enquiries_L12m_31_to_395_v2["Total_enquiries"]=Enquiries_L12m_31_to_395_v2[['Auto Loan',
    'BL Against Bank Deposits',
    'BL-General',
    'BL-PS-Agriculture',
    'BL-PS-Others',
    'BL-PS-Small Business',
    'BNFCF-General',
    'BNFCF-PS-Agriculture',
    'BNFCF-PS-Others',
    'BNFCF-PS-Small Business',
    'Business Loan - Secured',
    'Business Loan - Unsecured ',
    'Commercial Vehicle Loans',
    'Construction Equipment Loan',
    'Consumer Loan',
    'Corporate Credit card',
    'Credit Card',
    'Education Loan',
    'Fleet Card',
    'Gold Loan',
    'Housing Loan',
    'Kisan Credit Card',
    'Leasing',
    'Loan Against Bank Deposits',
    'Loan Against shares/Securities',
    'Loan to Professional',
    'Microfinance-Business Loan',
    'Microfinance-Housing Loan',
    'Microfinance-Others',
    'Microfinance-Personal Loan',
    'Mudra Loans ? Shishu / Kishor / Tarun',
    'Non Funded Credit Facility',
    'Others',
    'Overdraft',
    'Personal Loan',
    'Prime Minister Jaan Dhan Yojana - Overdraft',
    'Property Loan',
    'Secured Credit Card',
    'Tractor Loan',
    'Two Wheeler Loan',
    'Used Car Loan']].sum(axis=1,skipna=True)
    Enquiries_L12m_31_to_395_v2.head()
   
    Enquiries_L12m_31_to_395_v3=Enquiries_L12m_31_to_395_v2.groupby(["MRN","SANCTION_DATE"]).agg({'Auto Loan':'max',
    'BL Against Bank Deposits':'max',
    'BL-General':'max',
    'BL-PS-Agriculture':'max',
    'BL-PS-Others':'max',
    'BL-PS-Small Business':'max',
    'BNFCF-General':'max',
    'BNFCF-PS-Agriculture':'max',
    'BNFCF-PS-Others':'max',
    'BNFCF-PS-Small Business':'max',
    'Business Loan - Secured':'max',
    'Business Loan - Unsecured ':'max',
    'Commercial Vehicle Loans':'max',
    'Construction Equipment Loan':'max',
    'Consumer Loan':'max',
    'Corporate Credit card':'max',
    'Credit Card':'max',
    'Education Loan':'max',
    'Fleet Card':'max',
    'Gold Loan':'max',
    'Housing Loan':'max',
    'Kisan Credit Card':'max',
    'Leasing':'max',
    'Loan Against Bank Deposits':'max',
    'Loan Against shares/Securities':'max',
    'Loan to Professional':'max',
    'Microfinance-Business Loan':'max',
    'Microfinance-Housing Loan':'max',
    'Microfinance-Others':'max',
    'Microfinance-Personal Loan':'max',
    'Mudra Loans ? Shishu / Kishor / Tarun':'max',
    'Non Funded Credit Facility':'max',
    'Others':'max',
    'Overdraft':'max',
    'Personal Loan':'max',
    'Prime Minister Jaan Dhan Yojana - Overdraft':'max',
    'Property Loan':'max',
    'Secured Credit Card':'max',
    'Tractor Loan':'max',
    'Two Wheeler Loan':'max',
    'Used Car Loan':'max'}).reset_index()
    Enquiries_L12m_31_to_395_v3.head()
   
    Enquiries_L12m_31_to_395_v3.columns=['MRN','SANCTION_DATE','max_enquiries_Auto Loan_31_to_395',
    'max_enquiries_BL Against Bank Deposits_31_to_395',
    'max_enquiries_BL-General_31_to_395',
    'max_enquiries_BL-PS-Agriculture_31_to_395',
    'max_enquiries_BL-PS-Others_31_to_395',
    'max_enquiries_BL-PS-Small Business_31_to_395',
    'max_enquiries_BNFCF-General_31_to_395',
    'max_enquiries_BNFCF-PS-Agriculture_31_to_395',
    'max_enquiries_BNFCF-PS-Others_31_to_395',
    'max_enquiries_BNFCF-PS-Small Business_31_to_395',
    'max_enquiries_Business Loan - Secured_31_to_395',
    'max_enquiries_Business Loan - Unsecured_31_to_395',
    'max_enquiries_Commercial Vehicle Loans_31_to_395',
    'max_enquiries_Construction Equipment Loan_31_to_395',
    'max_enquiries_Consumer Loan_31_to_395',
    'max_enquiries_Corporate Credit card_31_to_395',
    'max_enquiries_Credit Card_31_to_395',
    'max_enquiries_Education Loan_31_to_395',
    'max_enquiries_Fleet Card_31_to_395',
    'max_enquiries_Gold Loan_31_to_395',
    'max_enquiries_Housing Loan_31_to_395',
    'max_enquiries_Kisan Credit Card_31_to_395',
    'max_enquiries_Leasing_31_to_395',
    'max_enquiries_Loan Against Bank Deposits_31_to_395',
    'max_enquiries_Loan Against shares/Securities_31_to_395',
    'max_enquiries_Loan to Professional_31_to_395',
    'max_enquiries_Microfinance-Business Loan_31_to_395',
    'max_enquiries_Microfinance-Housing Loan_31_to_395',
    'max_enquiries_Microfinance-Others_31_to_395',
    'max_enquiries_Microfinance-Personal Loan_31_to_395',
    'max_enquiries_Mudra Loans ? Shishu / Kishor / Tarun_31_to_395',
    'max_enquiries_Non Funded Credit Facility_31_to_395',
    'max_enquiries_Others_31_to_395',
    'max_enquiries_Overdraft_31_to_395',
    'max_enquiries_Personal Loan_31_to_395',
    'max_enquiries_Prime Minister Jaan Dhan Yojana - Overdraft_31_to_395',
    'max_enquiries_Property Loan_31_to_395',
    'max_enquiries_Secured Credit Card_31_to_395',
    'max_enquiries_Tractor Loan_31_to_395',
    'max_enquiries_Two Wheeler Loan_31_to_395',
    'max_enquiries_Used Car Loan_31_to_395']
   
    Enquiries_L12m_31_to_395_v3.head()
   
   
    Enquiries_L12m_211_to_395=cibil_enq[(cibil_enq["sanc_enq"]>211)&(cibil_enq["sanc_enq"]<=395)]
    Enquiries_L12m_211_to_395.head()
    Enquiries_L12m_211_to_395_v1=Enquiries_L12m_211_to_395.groupby(["MRN","SANCTION_DATE","ENQ_PURPOSE_DESC"]).agg({"ENQ_DATE":"nunique"}).reset_index()
    Enquiries_L12m_211_to_395_v1.head()
    Enquiries_L12m_211_to_395_v2=Enquiries_L12m_211_to_395_v1.pivot_table(index=["MRN","SANCTION_DATE","ENQ_PURPOSE_DESC"],columns=Enquiries_L12m_211_to_395_v1["ENQ_PURPOSE_DESC"],values="ENQ_DATE",aggfunc=sum).reset_index()
    Enquiries_L12m_211_to_395_v2.head()
   
    Enquiries_L12m_211_to_395_v2["Total_enquiries"]=Enquiries_L12m_211_to_395_v2[['Auto Loan',
       'BL Against Bank Deposits', 'BL-General', 'BL-PS-Agriculture',
       'BL-PS-Others', 'BL-PS-Small Business', 'BNFCF-General',
       'BNFCF-PS-Others', 'BNFCF-PS-Small Business', 'Business Loan - Secured',
       'Business Loan - Unsecured\t', 'Commercial Vehicle Loans',
       'Construction Equipment Loan', 'Consumer Loan', 'Corporate Credit card',
       'Credit Card', 'Education Loan', 'Gold Loan', 'Housing Loan',
       'Kisan Credit Card', 'Leasing', 'Loan Against Bank Deposits',
       'Loan Against shares/Securities', 'Loan to Professional',
       'Microfinance-Business Loan', 'Microfinance-Housing Loan',
       'Microfinance-Others', 'Microfinance-Personal Loan',
       'Non Funded Credit Facility', 'Others', 'Overdraft', 'Personal Loan',
       'Property Loan', 'Tractor Loan', 'Two Wheeler Loan', 'Used Car Loan']].sum(axis=1,skipna=True)
    Enquiries_L12m_211_to_395_v2.head()
   
    Enquiries_L12m_211_to_395_v3=Enquiries_L12m_211_to_395_v2.groupby(["MRN","SANCTION_DATE"]).agg({'Auto Loan':'max',
    'BL Against Bank Deposits':'max',
    'BL-General':'max',
    'BL-PS-Agriculture':'max',
    'BL-PS-Others':'max',
    'BL-PS-Small Business':'max',
    'BNFCF-General':'max',
    'BNFCF-PS-Others':'max',
    'BNFCF-PS-Small Business':'max',
    'Business Loan - Secured':'max',
    'Business Loan - Unsecured ':'max',
    'Commercial Vehicle Loans':'max',
    'Construction Equipment Loan':'max',
    'Consumer Loan':'max',
    'Corporate Credit card':'max',
    'Credit Card':'max',
    'Education Loan':'max',
    'Gold Loan':'max',
    'Housing Loan':'max',
    'Kisan Credit Card':'max',
    'Leasing':'max',
    'Loan Against Bank Deposits':'max',
    'Loan Against shares/Securities':'max',
    'Loan to Professional':'max',
    'Microfinance-Business Loan':'max',
    'Microfinance-Housing Loan':'max',
    'Microfinance-Others':'max',
    'Microfinance-Personal Loan':'max',
    'Non Funded Credit Facility':'max',
    'Others':'max',
    'Overdraft':'max',
    'Personal Loan':'max',
    'Property Loan':'max',
    'Tractor Loan':'max',
    'Two Wheeler Loan':'max',
    'Used Car Loan':'max',
    'Total_enquiries':'max'}).reset_index()
    Enquiries_L12m_211_to_395_v3.head()
   
    Enquiries_L12m_211_to_395_v3.columns=["MRN","SANCTION_DATE",'max_enquiries_Auto Loan_211_to_395',
    'max_enquiries_BL Against Bank Deposits_211_to_395',
    'max_enquiries_BL-General_211_to_395',
    'max_enquiries_BL-PS-Agriculture_211_to_395',
    'max_enquiries_BL-PS-Others_211_to_395',
    'max_enquiries_BL-PS-Small Business_211_to_395',
    'max_enquiries_BNFCF-General_211_to_395',
    'max_enquiries_BNFCF-PS-Others_211_to_395',
    'max_enquiries_BNFCF-PS-Small Business_211_to_395',
    'max_enquiries_Business Loan - Secured_211_to_395',
    'max_enquiries_Business Loan - Unsecured _211_to_395',
    'max_enquiries_Commercial Vehicle Loans_211_to_395',
    'max_enquiries_Construction Equipment Loan_211_to_395',
    'max_enquiries_Consumer Loan_211_to_395',
    'max_enquiries_Corporate Credit card_211_to_395',
    'max_enquiries_Credit Card_211_to_395',
    'max_enquiries_Education Loan_211_to_395',
    'max_enquiries_Gold Loan_211_to_395',
    'max_enquiries_Housing Loan_211_to_395',
    'max_enquiries_Kisan Credit Card_211_to_395',
    'max_enquiries_Leasing_211_to_395',
    'max_enquiries_Loan Against Bank Deposits_211_to_395',
    'max_enquiries_Loan Against shares/Securities_211_to_395',
    'max_enquiries_Loan to Professional_211_to_395',
    'max_enquiries_Microfinance-Business Loan_211_to_395',
    'max_enquiries_Microfinance-Housing Loan_211_to_395',
    'max_enquiries_Microfinance-Others_211_to_395',
    'max_enquiries_Microfinance-Personal Loan_211_to_395',
    'max_enquiries_Non Funded Credit Facility_211_to_395',
    'max_enquiries_Others_211_to_395',
    'max_enquiries_Overdraft_211_to_395',
    'max_enquiries_Personal Loan_211_to_395',
    'max_enquiries_Property Loan_211_to_395',
    'max_enquiries_Tractor Loan_211_to_395',
    'max_enquiries_Two Wheeler Loan_211_to_395',
    'max_enquiries_Used Car Loan_211_to_395',
    'max_enquiries_Total_enquiries_211_to_395']
   
    Enquiries_L12m_211_to_395_v3.head()

    Enquiries_L12m_31_to_300=cibil_enq[(cibil_enq["sanc_enq"]>30)&(cibil_enq["sanc_enq"]<=300)]
    Enquiries_L12m_31_to_300.head()
    Enquiries_L12m_31_to_300_v1=Enquiries_L12m_31_to_300.groupby(["MRN","SANCTION_DATE","ENQ_PURPOSE_DESC"]).agg({"ENQ_DATE":"nunique"}).reset_index()
    Enquiries_L12m_31_to_300_v1.head()
    Enquiries_L12m_31_to_300_v2=Enquiries_L12m_31_to_300_v1.pivot_table(index=["MRN","SANCTION_DATE"],columns=Enquiries_L12m_31_to_300_v1["ENQ_PURPOSE_DESC"],values="ENQ_DATE",aggfunc=sum).reset_index()
    Enquiries_L12m_31_to_300_v2.head()
   
    Enquiries_L12m_31_to_300_v2["Total_enquiries"]=Enquiries_L12m_31_to_300_v2[['Auto Loan', 'BL Against Bank Deposits',
       'BL-General', 'BL-PS-Agriculture', 'BL-PS-Others',
       'BL-PS-Small Business', 'BNFCF-General', 'BNFCF-PS-Agriculture',
       'BNFCF-PS-Others', 'BNFCF-PS-Small Business', 'Business Loan - Secured',
       'Business Loan - Unsecured\t', 'Commercial Vehicle Loans',
       'Construction Equipment Loan', 'Consumer Loan', 'Corporate Credit card',
       'Credit Card', 'Education Loan', 'Fleet Card', 'Gold Loan',
       'Housing Loan', 'Kisan Credit Card', 'Leasing',
       'Loan Against Bank Deposits', 'Loan Against shares/Securities',
       'Loan to Professional', 'Microfinance-Business Loan',
       'Microfinance-Housing Loan', 'Microfinance-Others',
       'Microfinance-Personal Loan', 'Mudra Loans ? Shishu / Kishor / Tarun',
       'Non Funded Credit Facility', 'Others', 'Overdraft', 'Personal Loan',
       'Prime Minister Jaan Dhan Yojana - Overdraft', 'Property Loan',
       'Secured Credit Card', 'Tractor Loan', 'Two Wheeler Loan',
       'Used Car Loan']].sum(axis=1,skipna=True)
    Enquiries_L12m_31_to_300_v2.head()
   
    Enquiries_L12m_31_to_300_v3=Enquiries_L12m_31_to_300_v2.groupby(["MRN","SANCTION_DATE"]).agg({'Auto Loan':'max',
    'BL Against Bank Deposits':'max',
    'BL-General':'max',
    'BL-PS-Agriculture':'max',
    'BL-PS-Others':'max',
    'BL-PS-Small Business':'max',
    'BNFCF-General':'max',
    'BNFCF-PS-Agriculture':'max',
    'BNFCF-PS-Others':'max',
    'BNFCF-PS-Small Business':'max',
    'Business Loan - Secured':'max',
    'Business Loan - Unsecured ':'max',
    'Commercial Vehicle Loans':'max',
    'Construction Equipment Loan':'max',
    'Consumer Loan':'max',
    'Corporate Credit card':'max',
    'Credit Card':'max',
    'Education Loan':'max',
    'Fleet Card':'max',
    'Gold Loan':'max',
    'Housing Loan':'max',
    'Kisan Credit Card':'max',
    'Leasing':'max',
    'Loan Against Bank Deposits':'max',
    'Loan Against shares/Securities':'max',
    'Loan to Professional':'max',
    'Microfinance-Business Loan':'max',
    'Microfinance-Housing Loan':'max',
    'Microfinance-Others':'max',
    'Microfinance-Personal Loan':'max',
    'Mudra Loans ? Shishu / Kishor / Tarun':'max',
    'Non Funded Credit Facility':'max',
    'Others':'max',
    'Overdraft':'max',
    'Personal Loan':'max',
    'Prime Minister Jaan Dhan Yojana - Overdraft':'max',
    'Property Loan':'max',
    'Secured Credit Card':'max',
    'Tractor Loan':'max',
    'Two Wheeler Loan':'max',
    'Used Car Loan':'max',
    'Total_enquiries':'max'
    }).reset_index()
    Enquiries_L12m_31_to_300_v3.head()
   
    Enquiries_L12m_31_to_300_v3.columns=['MRN','SANCTION_DATE','max_enquiries_Auto Loan_31_to_300',
    'max_enquiries_BL Against Bank Deposits_31_to_300',
    'max_enquiries_BL-General_31_to_300',
    'max_enquiries_BL-PS-Agriculture_31_to_300',
    'max_enquiries_BL-PS-Others_31_to_300',
    'max_enquiries_BL-PS-Small Business_31_to_300',
    'max_enquiries_BNFCF-General_31_to_300',
    'max_enquiries_BNFCF-PS-Agriculture_31_to_300',
    'max_enquiries_BNFCF-PS-Others_31_to_300',
    'max_enquiries_BNFCF-PS-Small Business_31_to_300',
    'max_enquiries_Business Loan - Secured_31_to_300',
    'max_enquiries_Business Loan - Unsecured _31_to_300',
    'max_enquiries_Commercial Vehicle Loans_31_to_300',
    'max_enquiries_Construction Equipment Loan_31_to_300',
    'max_enquiries_Consumer Loan_31_to_300',
    'max_enquiries_Corporate Credit card_31_to_300',
    'max_enquiries_Credit Card_31_to_300',
    'max_enquiries_Education Loan_31_to_300',
    'max_enquiries_Fleet Card_31_to_300',
    'max_enquiries_Gold Loan_31_to_300',
    'max_enquiries_Housing Loan_31_to_300',
    'max_enquiries_Kisan Credit Card_31_to_300',
    'max_enquiries_Leasing_31_to_300',
    'max_enquiries_Loan Against Bank Deposits_31_to_300',
    'max_enquiries_Loan Against shares/Securities_31_to_300',
    'max_enquiries_Loan to Professional_31_to_300',
    'max_enquiries_Microfinance-Business Loan_31_to_300',
    'max_enquiries_Microfinance-Housing Loan_31_to_300',
    'max_enquiries_Microfinance-Others_31_to_300',
    'max_enquiries_Microfinance-Personal Loan_31_to_300',
    'max_enquiries_Mudra Loans ? Shishu / Kishor / Tarun_31_to_300',
    'max_enquiries_Non Funded Credit Facility_31_to_300',
    'max_enquiries_Others_31_to_300',
    'max_enquiries_Overdraft_31_to_300',
    'max_enquiries_Personal Loan_31_to_300',
    'max_enquiries_Prime Minister Jaan Dhan Yojana - Overdraft_31_to_300',
    'max_enquiries_Property Loan_31_to_300',
    'max_enquiries_Secured Credit Card_31_to_300',
    'max_enquiries_Tractor Loan_31_to_300',
    'max_enquiries_Two Wheeler Loan_31_to_300',
    'max_enquiries_Used Car Loan_31_to_300',
    'max_enquiries_Total_enquiries_31_to_300'
    ]
   
    Enquiries_L12m_31_to_300_v3.head()
   
    Enquiries_L12m_31_to_210=cibil_enq[(cibil_enq["sanc_enq"]>30)&(cibil_enq["sanc_enq"]<=210)]
    Enquiries_L12m_31_to_210.head()
    Enquiries_L12m_31_to_210_v1=Enquiries_L12m_31_to_210.groupby(["MRN","SANCTION_DATE","ENQ_PURPOSE_DESC"]).agg({"ENQ_DATE":"nunique"}).reset_index()
    Enquiries_L12m_31_to_210_v1.head()
    Enquiries_L12m_31_to_210_v2=Enquiries_L12m_31_to_210_v1.pivot_table(index=["MRN","SANCTION_DATE"],columns=Enquiries_L12m_31_to_210_v1["ENQ_PURPOSE_DESC"],values="ENQ_DATE",aggfunc=sum).reset_index()
    Enquiries_L12m_31_to_210_v2.head()
   
    Enquiries_L12m_31_to_210_v2["Total_enquiries"]=Enquiries_L12m_31_to_210_v2[['Auto Loan', 'BL Against Bank Deposits',
       'BL-General', 'BL-PS-Agriculture', 'BL-PS-Others',
       'BL-PS-Small Business', 'BNFCF-General', 'BNFCF-PS-Agriculture',
       'BNFCF-PS-Others', 'BNFCF-PS-Small Business', 'Business Loan - Secured',
       'Business Loan - Unsecured\t', 'Commercial Vehicle Loans',
       'Construction Equipment Loan', 'Consumer Loan', 'Corporate Credit card',
       'Credit Card', 'Education Loan', 'Fleet Card', 'Gold Loan',
       'Housing Loan', 'Kisan Credit Card', 'Leasing',
       'Loan Against Bank Deposits', 'Loan Against shares/Securities',
       'Loan to Professional', 'Microfinance-Business Loan',
       'Microfinance-Housing Loan', 'Microfinance-Others',
       'Microfinance-Personal Loan', 'Mudra Loans ? Shishu / Kishor / Tarun',
       'Non Funded Credit Facility', 'Others', 'Overdraft', 'Personal Loan',
       'Prime Minister Jaan Dhan Yojana - Overdraft', 'Property Loan',
       'Secured Credit Card', 'Tractor Loan', 'Two Wheeler Loan',
       'Used Car Loan']].sum(axis=1,skipna=True)
    Enquiries_L12m_31_to_210_v2.head()
   
    Enquiries_L12m_31_to_210_v3=Enquiries_L12m_31_to_210_v2.groupby(["MRN","SANCTION_DATE"]).agg({'Auto Loan':'max',
    'BL Against Bank Deposits':'max',
    'BL-General':'max',
    'BL-PS-Agriculture':'max',
    'BL-PS-Others':'max',
    'BL-PS-Small Business':'max',
    'BNFCF-General':'max',
    'BNFCF-PS-Agriculture':'max',
    'BNFCF-PS-Others':'max',
    'BNFCF-PS-Small Business':'max',
    'Business Loan - Secured':'max',
    'Business Loan - Unsecured ':'max',
    'Commercial Vehicle Loans':'max',
    'Construction Equipment Loan':'max',
    'Consumer Loan':'max',
    'Corporate Credit card':'max',
    'Credit Card':'max',
    'Education Loan':'max',
    'Fleet Card':'max',
    'Gold Loan':'max',
    'Housing Loan':'max',
    'Kisan Credit Card':'max',
    'Leasing':'max',
    'Loan Against Bank Deposits':'max',
    'Loan Against shares/Securities':'max',
    'Loan to Professional':'max',
    'Microfinance-Business Loan':'max',
    'Microfinance-Housing Loan':'max',
    'Microfinance-Others':'max',
    'Microfinance-Personal Loan':'max',
    'Mudra Loans ? Shishu / Kishor / Tarun':'max',
    'Non Funded Credit Facility':'max',
    'Others':'max',
    'Overdraft':'max',
    'Personal Loan':'max',
    'Prime Minister Jaan Dhan Yojana - Overdraft':'max',
    'Property Loan':'max',
    'Secured Credit Card':'max',
    'Tractor Loan':'max',
    'Two Wheeler Loan':'max',
    'Used Car Loan':'max',
    'Total_enquiries':'max',
    }).reset_index()
    Enquiries_L12m_31_to_210_v3.head()
   
    Enquiries_L12m_31_to_210_v3.columns=["MRN","SANCTION_DATE",'max_enquiries_Auto Loan_31_to_210',
    'max_enquiries_BL Against Bank Deposits_31_to_210',
    'max_enquiries_BL-General_31_to_210',
    'max_enquiries_BL-PS-Agriculture_31_to_210',
    'max_enquiries_BL-PS-Others_31_to_210',
    'max_enquiries_BL-PS-Small Business_31_to_210',
    'max_enquiries_BNFCF-General_31_to_210',
    'max_enquiries_BNFCF-PS-Agriculture_31_to_210',
    'max_enquiries_BNFCF-PS-Others_31_to_210',
    'max_enquiries_BNFCF-PS-Small Business_31_to_210',
    'max_enquiries_Business Loan - Secured_31_to_210',
    'max_enquiries_Business Loan - Unsecured _31_to_210',
    'max_enquiries_Commercial Vehicle Loans_31_to_210',
    'max_enquiries_Construction Equipment Loan_31_to_210',
    'max_enquiries_Consumer Loan_31_to_210',
    'max_enquiries_Corporate Credit card_31_to_210',
    'max_enquiries_Credit Card_31_to_210',
    'max_enquiries_Education Loan_31_to_210',
    'max_enquiries_Fleet Card_31_to_210',
    'max_enquiries_Gold Loan_31_to_210',
    'max_enquiries_Housing Loan_31_to_210',
    'max_enquiries_Kisan Credit Card_31_to_210',
    'max_enquiries_Leasing_31_to_210',
    'max_enquiries_Loan Against Bank Deposits_31_to_210',
    'max_enquiries_Loan Against shares/Securities_31_to_210',
    'max_enquiries_Loan to Professional_31_to_210',
    'max_enquiries_Microfinance-Business Loan_31_to_210',
    'max_enquiries_Microfinance-Housing Loan_31_to_210',
    'max_enquiries_Microfinance-Others_31_to_210',
    'max_enquiries_Microfinance-Personal Loan_31_to_210',
    'max_enquiries_Mudra Loans ? Shishu / Kishor / Tarun_31_to_210',
    'max_enquiries_Non Funded Credit Facility_31_to_210',
    'max_enquiries_Others_31_to_210',
    'max_enquiries_Overdraft_31_to_210',
    'max_enquiries_Personal Loan_31_to_210',
    'max_enquiries_Prime Minister Jaan Dhan Yojana - Overdraft_31_to_210',
    'max_enquiries_Property Loan_31_to_210',
    'max_enquiries_Secured Credit Card_31_to_210',
    'max_enquiries_Tractor Loan_31_to_210',
    'max_enquiries_Two Wheeler Loan_31_to_210',
    'max_enquiries_Used Car Loan_31_to_210',
    'max_enquiries_Total_enquiries_31_to_210'
    ]
    Enquiries_L12m_31_to_210_v3.head()
    Enquiries_L12m_31_to_120=cibil_enq[(cibil_enq["sanc_enq"]>30)&(cibil_enq["sanc_enq"]<=120)]
    Enquiries_L12m_31_to_120.head()
    Enquiries_L12m_31_to_120_v1=Enquiries_L12m_31_to_120.groupby(["MRN","SANCTION_DATE","ENQ_PURPOSE_DESC"]).agg({"ENQ_DATE":"nunique"}).reset_index()
    Enquiries_L12m_31_to_120_v1.head()
    Enquiries_L12m_31_to_120_v2=Enquiries_L12m_31_to_120_v1.pivot_table(index=["MRN","SANCTION_DATE"],columns=Enquiries_L12m_31_to_120_v1["ENQ_PURPOSE_DESC"],values="ENQ_DATE",aggfunc=sum).reset_index()
    Enquiries_L12m_31_to_120_v2.head()
   
    Enquiries_L12m_31_to_120_v2["Total_enquiries"]=Enquiries_L12m_31_to_120_v2[['Auto Loan', 'BL Against Bank Deposits',
       'BL-General', 'BL-PS-Agriculture', 'BL-PS-Others',
       'BL-PS-Small Business', 'BNFCF-General', 'BNFCF-PS-Agriculture',
       'BNFCF-PS-Small Business', 'Business Loan - Secured',
       'Business Loan - Unsecured\t', 'Commercial Vehicle Loans',
       'Construction Equipment Loan', 'Consumer Loan', 'Corporate Credit card',
       'Credit Card', 'Education Loan', 'Gold Loan', 'Housing Loan',
       'Kisan Credit Card', 'Leasing', 'Loan Against Bank Deposits',
       'Loan Against shares/Securities', 'Loan to Professional',
       'Microfinance-Business Loan', 'Microfinance-Housing Loan',
       'Microfinance-Others', 'Microfinance-Personal Loan',
       'Mudra Loans ? Shishu / Kishor / Tarun', 'Non Funded Credit Facility',
       'Others', 'Overdraft', 'Personal Loan',
       'Prime Minister Jaan Dhan Yojana - Overdraft', 'Property Loan',
       'Secured Credit Card', 'Tractor Loan', 'Two Wheeler Loan',
       'Used Car Loan']].sum(axis=1,skipna=True)
    Enquiries_L12m_31_to_120_v2.head()
   
    Enquiries_L12m_31_to_120_v3=Enquiries_L12m_31_to_120_v2.groupby(["MRN","SANCTION_DATE"]).agg({'Auto Loan':'max',
    'BL Against Bank Deposits':'max',