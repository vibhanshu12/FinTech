# -*- coding: utf-8 -*-
"""
Created on Mon Jun  7 21:41:14 2021

@author: Vibhanshu Jain
"""

import pandas as pd
#import sweetviz as sv
import yaml
import os
import numpy as np
import glob
import statistics
import time
import datetime as dt
from functools import reduce
from datetime import datetime, timedelta
#from shapely.geometry import Point, Polygon
import seaborn as sns
import matplotlib.pyplot as plt
import time
#import pandas_profiling
from matplotlib.backends.backend_pdf import PdfPages
from statsmodels.stats.outliers_influence import variance_inflation_factor

from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()


import matplotlib.patches as mpatches
from matplotlib.ticker import MaxNLocator
from optbinning import BinningProcess
import scorecardpy as sc
import json
import ast

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
#%matplotlib notebook

#plt.style.use('seaborn-whitegrid')

pd.options.display.max_columns = None

pd.set_option('display.float_format', '{:.2f}'.format)

config={    
   
    "REPO_PATH": r"C:\Users\vishwesh kumar\Videos\LIC",    
    "MODEL_DATA_SAL": r"\Processed Data\salaried",
    "MODEL_DATA_SELF": r"\Processed Data\self",
    "EXPLORATORY_REPORTS": r'\reports',
    "SALARIED_DATA": r'model_train_data_sal',
    "SELF_EMPLOYED_DATA":r'model_train_data_self',
   
    "TARGET_VAR": r'loan',
    "ID_VAR": ['COMP_APPL_ID'],
    "DROP_LIST": [],
    "OBJ_LIST": ['loan','COMP_APPL_ID'],
   
    "VIF_THRES": 5,
    "TEST_SPLIT":2
   
}
config2={    
   
    "REPO_PATH": r"C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL",    
    "MODEL_DATA_SAL": r"\Processed Data\salaried",
    "MODEL_DATA_SELF": r"\Processed Data\self",
    "EXPLORATORY_REPORTS": r'\reports',
    "SALARIED_DATA": r'model_train_data_sal',
    "SELF_EMPLOYED_DATA":r'model_train_data_self',
   
    "TARGET_VAR": r'loan',
    "ID_VAR": ['COMP_APPL_ID'],
    "DROP_LIST": [],
    "OBJ_LIST": ['loan','COMP_APPL_ID'],
   
    "VIF_THRES": 5,
    "TEST_SPLIT":2
   
}

#helper Utils
def compute_time(start_time,name):
  """
  Compute the time taken to complete an action
  """

  new_time = time.time()
  delta =  datetime.fromtimestamp(new_time - start_time).strftime("%M:%S")
  print('\n')
  print('------------------------------')
  print(name,':',delta)
  print('------------------------------')
  return new_time

def make_dir(config,report_type):  
    """
    make directory based on the report type parameter
    """

    directory=os.path.join(config['REPO_PATH']+report_type+"/report_"+ datetime.today().strftime('%d-%m-%Y'))
    if not os.path.exists(directory):
        os.makedirs(directory)
   
    return directory

def read_data(regex,file_type):
    df = pd.DataFrame()
   
    for f in glob.glob(regex):
        # read files f
        if (file_type=="csv"):
            interm = pd.read_csv(f, compression = "gzip")          
        elif (file_type=="parquet"):
            interm=pd.read_parquet(f, engine='fastparquet')
        elif (file_type=="text"):
            interm=pd.read_csv(f, sep='|')  
       
        interm.drop(interm.tail(2).index,inplace=True)
        df = pd.concat([df, interm])

    return df

def read_latest_data(regex,filetype):
    list_of_files = glob.glob(regex)
    latest_model_data = max(list_of_files, key=os.path.getctime)
    model_df=read_data(latest_model_data,filetype)

    return model_df

def convert_datatypes(model_df,config):
    """
    Preprocess data to convert datatypes of specified columns
    Inputs:     model_df            = dataframe that columns need to be converted
                config              = yaml file containing all config settings
    output:     model_df            = dataframe with converted datatypes
    """
   
    model_df[config['OBJ_LIST']] = model_df[config['OBJ_LIST']].astype(str)
    model_df=model_df.drop(config['DROP_LIST'],axis=1)
   
   
    return model_df

def handle_missing_value(model_df):
    """
    Handles missing data points by adding no_info for object dtypes,
    and average for integer data types
    Inputs      : model_df          = model training dataframe
    outputs     : model data frame with dropped columns
    """
    object_vars = list(model_df.select_dtypes(include = ['O']).columns)
    numeric_vars= [x for x in model_df.columns if x not in object_vars]
    model_df=model_df.replace([np.inf, -np.inf], np.nan)
    model_df[object_vars]  = model_df[object_vars].fillna('no_info')
    model_df[numeric_vars] = model_df[numeric_vars].fillna(0)
   
    return model_df

def missing_values_table(df):
        #df = model_df.copy()
    # Total missing values
       
        #df=cibil_sal.copy()
        mis_val = df.isnull().sum()
       
        # Percentage of missing values
        mis_val_percent = 100 * df.isnull().sum() / len(df)
       
        # Make a table with the results
        mis_val_table = pd.concat([mis_val, mis_val_percent], axis=1)
       
        # Rename the columns
        mis_val_table_ren_columns = mis_val_table.rename(
        columns = {0 : 'Missing Values', 1 : '% of Total Values'})
       
        # Sort the table by percentage of missing descending
        mis_val_table_ren_columns = mis_val_table_ren_columns[
            mis_val_table_ren_columns.iloc[:,1] != 0].sort_values(
        '% of Total Values', ascending=False).round(1)
       
        # Print some summary information
        print ("Your selected dataframe has " + str(df.shape[1]) + " columns.\n"      
            "There are " + str(mis_val_table_ren_columns.shape[0]) +
              " columns that have missing values.")
        #missing_train = missing_values_table(model_df)
        #missing_train.head(10)
        missing_columns = list(mis_val_table_ren_columns[mis_val_table_ren_columns['% of Total Values'] > 50].index)
        print('We will remove %d columns from set.' % len(missing_columns))
        mis_val_table_ren_columns
       
        df = df.drop(columns=list(missing_columns))
       

        # Return the dataframe with missing columns removed
        return df

def missing_value_filter(df):
    lst = ['GENDER',
          'DECLARED_PROPERTY_VAL']  
    for i in lst:
        df = df[df[i].isnull()==False]
    del lst
    return df

#helper - exploratory anaysis
def data_check(model_df, config):
    """
    Generate EDA report using Pandas profiling library
    Inputs:  model_df = dataframe that columns need to be converted
             config   = yaml file containing all config settings
    Output:           = EDA report generated and saved in the local repo
    """

    directory = make_dir(config,(config['EXPLORATORY_REPORTS']+"/exploratory_analysis/"))
    report = pandas_profiling.ProfileReport(model_df)
    filepath = directory + "/exploratory_analysis.html"
    report.to_file(filepath)
   
def identify_distribution(model_df, config):
    """
    Generate distributions of all continuous variables

    Inputs:  model_df = dataframe that columns need to be converted
             config   = yaml file containing all config settings
    output:           = EDA report generated and saved in the local repo
    """

    sns.set(font_scale=1)
    directory = make_dir(config,(config['EXPLORATORY_REPORTS']+"/exploratory_analysis/"))
    filepath = directory + "/Univariate_analysis.pdf"
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    df = model_df.select_dtypes(include=numerics)
    with PdfPages(filepath) as pdf_pages:
        for col_index in df.columns:
            fig = plt.figure(col_index)
            img = sns.distplot(df[col_index], color='blue', bins=100, hist_kws={'alpha': 0.4})
            pdf_pages.savefig(fig)
           


def plot_target_vs_continuous(model_df, config):
    """
    Generate distributions of all continuous variables

    Inputs:  model_df = dataframe that columns need to be converted
             config   = yaml file containing all config settings
    output:           = EDA report generated and saved in the local repo
    """

    sns.set(font_scale=1)
    directory = make_dir(config,(config['EXPLORATORY_REPORTS']+"/exploratory_analysis/"))
    filepath = directory + "/Bivariate_analysis_target_vs_continuous.pdf"
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    df = model_df.select_dtypes(include=numerics)
    df[config['TARGET_VAR']] = model_df[config['TARGET_VAR']]
    with PdfPages(filepath) as pdf_pages:
        for col_index in df.columns:
            fig = plt.figure(col_index)
            img=sns.violinplot(data=df, x=config['TARGET_VAR'], y=df[col_index])
            pdf_pages.savefig(fig)
           


def plot_scatter(model_df, config):
    """
    Generate scatter plot for all continuous variables

    Inputs:  model_df = dataframe that columns need to be converted
             config   = yaml file containing all config settings

    Output:           = EDA report generated and saved in the local repo
    """

    directory = make_dir(config,(config['EXPLORATORY_REPORTS']+"/exploratory_analysis/"))
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    df = model_df.select_dtypes(include=numerics)
    df[config['TARGET_VAR']] = model_df[config['TARGET_VAR']]
    for j in range(0,len(df.columns)):
        for i in range(0, len(df.columns), 5):      
            filepath = directory + "/Bivariate_analysis_scatter_plots_" + df.columns[j] + "_" +str(i) + ".png"
            fig = plt.figure(i)      
            img=sns.pairplot(data=df, x_vars=df.columns[i:i+5], y_vars=df.columns[j], hue='churn')
            img.savefig(filepath)
       
       
def identify_correlation(model_df, config):
    """
    Identify multi collinearity in a dataframe
    Plot correlation matrix
    """
    #identify only numeric datatypes
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    model_df = model_df.select_dtypes(include=numerics)

    #calculate correlation matrix
    corr = model_df.corr()

    # Generate a mask for the upper triangle
    mask = np.triu(np.ones_like(corr, dtype=np.bool))

    # Set up the matplotlib figure
    f, ax = plt.subplots(figsize=(20, 9))

    # Generate a custom diverging colormap
    cmap = sns.diverging_palette(220, 10, as_cmap=True)

    # TODO: make name construction more generic for future model configurations
    directory = make_dir(config,(config['EXPLORATORY_REPORTS']+"/exploratory_analysis/"))
    filepath = directory + "/correlation_plots_sal_long_iter_3.1_0.01_P_0.1_B.png"

    # Draw the heatmap with the mask and correct aspect ratio
    img = sns.heatmap(corr, mask=mask, cmap=cmap, vmax=1, vmin=-1, center=0,
                      square=True, linewidths=.5, cbar_kws={"shrink": .5})
    img.figure.savefig(filepath)
    corr=corr.abs()
    corr.to_csv(directory + "/correlation_matrix_sal_long_iter_3.1_0.01_P_0.1_B.csv")

def calculate_vif(model_df,config):    
   
    dropped_cols=list()
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    df = model_df.select_dtypes(include=numerics)
    variables = list(range(df.shape[1]))
    directory = make_dir(config,(config['EXPLORATORY_REPORTS']+"/exploratory_analysis/"))
    filepath = directory + "/VIF.csv"
   
    dropped = True
    while dropped:
        dropped = False
        vif = [variance_inflation_factor(df.iloc[:, variables].values, ix)
               for ix in range(df.iloc[:, variables].shape[1])]

        maxloc = vif.index(max(vif))
        if max(vif) > config['VIF_THRES']:
            print('dropping \'' + df.iloc[:, variables].columns[maxloc] + '\' at index: ' + str(maxloc))
            dropped_cols.append(df.iloc[:, variables].columns[maxloc])
            del variables[maxloc]
            dropped = True
   
    variable_list=pd.DataFrame(df.columns[variables])
    dropped_cols=pd.DataFrame(dropped_cols)
    variable_list.to_csv(directory + "/VIF_final.csv")
    dropped_cols.to_csv(directory + "/VIF_dropped.csv")
   
def oot_split(df, datefilter):
    df_oot = df[df['FIRST_DISB_DATE']>datefilter]
    df_noot = df[df['FIRST_DISB_DATE']<=datefilter]
    return df_oot, df_noot

def train_split(df_noot, split):
#    df_application_train, df_application_test, y_train, y_test = train_test_split(
#    df_noot, df_noot.loan, test_size=split*0.1, random_state=42)
   
    df_application_train, df_application_test, y_train, y_test = train_test_split(
    df_noot, df_noot.loan, test_size=split*0.1,stratify=df_noot.loan)
    return df_application_train, df_application_test, y_train, y_test
   
config_func = {'prebin_method':'cart',
    'min_prebin_size':0.05,
    'max_n_prebins':1000,
    'min_n_bins':1,
    'solver':'cp',
    #'monotonic_trend':'auto_asc_desc',
    'special_values' : [-999999],
    'input_file_name':'woe_bin_dict'
    }

config_general_info = {'non_feature_columns':['loan', 'COMP_APPL_ID','GUAR_COAP_FLAG'],
    'target_col':'loan',
    'output_folder':r'C:\Users\vishwesh kumar\Videos\LIC',
    'date_col':'FIRST_DISB_DATE'
    }

def get_iv(df, thres):
#    d1=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC2\self_cib_iv.csv')
#    d2=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC2\sal_cib_iv.csv')
    #df=self_application_train.copy()
    #df=df.fillna(0)
    df=df.replace([-np.inf,np.inf], np.nan)
    binning_process = find_optimal_bins(df, config_func, config_general_info)
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(df,binning_process, config_func, config_general_info)
    woe_summary_df = binning_process.summary()
    woe_summary_df.drop(['dtype','status','selected','js','quality_score'], axis=1, inplace=True)
    woe_summary_df.columns = ['COLUMN NAME', 'NUMBER OF BINS', 'IV', 'GINI']
    col_to_drop = woe_summary_df[woe_summary_df['IV']< thres]
    col_to_drop = col_to_drop['COLUMN NAME'].tolist()
    df.drop(col_to_drop, axis = 1, inplace = True)
    return df,woe_summary_df,woe_detailed_df
def get_iv_old(df, thres):
#    d1=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC2\self_cib_iv.csv')
#    d2=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC2\sal_cib_iv.csv')
    #df=self_application_train.copy()
    #df=df.fillna(0)
    df=df.replace([-np.inf,np.inf], np.nan)
    binning_process = find_optimal_bins(df, config_func, config_general_info)
    woe_summary_df = binning_process.summary()
    woe_summary_df.drop(['dtype','status','selected','js','quality_score'], axis=1, inplace=True)
    woe_summary_df.columns = ['COLUMN NAME', 'NUMBER OF BINS', 'IV', 'GINI']
    col_to_drop = woe_summary_df[woe_summary_df['IV']< thres]
    col_to_drop = col_to_drop['COLUMN NAME'].tolist()
    df.drop(col_to_drop, axis = 1, inplace = True)
    return df
def woe_optimum_combined(data_train, data_test, data_oot_nc, data_oot_c, config_func, config_general_info) :

    config_excel_info=config_func['excel_info']
    output_folder=config_general_info['output_folder']
    excel_name=config_excel_info['excel_name']
    excel_writer=pd.ExcelWriter(output_folder+excel_name, engine='xlsxwriter')
    plot_file_name = config_func['woe_plot_pdf']
   
    # Get woe bins using train set
    binning_process = find_optimal_bins(data_train, config_func , config_general_info)
   
    # calculate and save the information
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(data_train,
    binning_process, config_func, config_general_info)
    woe_summary_df.to_excel(excel_writer, index=False, sheet_name=config_excel_info['sheet_name'][0])
    woe_detailed_df.to_excel(excel_writer, index=False, sheet_name=config_excel_info['sheet_name'][1])
    woe_bins.to_excel(excel_writer, index=False, sheet_name=config_excel_info['sheet_name'][2])
    excel_writer.save()
     
    #Save dictionary to a json file
    file_name = config_func['woe_bin_dict']
    with open(output_folder+file_name, 'w') as f:
        json.dump(woe_bin_dict, f)
       
    # Save plots
    plot_and_save_woe(data_train, binning_process, plot_file_name, config_func, config_general_info)
   
    # Encode datasets
    data_train_woe = woe_encode (data_train, binning_process, config_func, config_general_info)
    data_test_woe = woe_encode (data_test, binning_process, config_func, config_excel_info)
    data_oot_nc_woe = woe_encode (data_oot_nc, binning_process, config_func, config_general_info)
    data_oot_c_woe = woe_encode (data_oot_c, binning_process, config_func, config_general_info)
   
    return data_train_woe, data_test_woe, data_oot_nc_woe, data_oot_c_woe

def find_optimal_bins(data, config_func, config_general_info):
    '''
    find_optimal_bins_dict is a function to find the optimal bins of a given data.
    It is saved as a dictionary into a json file. These bins can be manually adjusted if required.

    Parameters
    ----------
    data: The dataframe that the column is present
    config_func: Config parameters related to this function
    config_general_info: General config parameters related to the data and model

    Output(s)
    ---------
    bin_dict_sc: A dictionary with bins values for each column
   
    '''
    #data=df.copy()
    #Defining the target and feature values
   
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)].tolist()
     
    feature_target = feature_list + [target_col]
   
    prebin_method = config_func['prebin_method']
    min_prebin_size = config_func['min_prebin_size']
    max_n_prebins = config_func['max_n_prebins']
    min_n_bins = config_func['min_n_bins']
    solver = config_func['solver']
    #monotonic_trend = config_func['monotonic_trend']
     
    param_dict = {
    'monotonic_trend':'auto_asc_desc',
    'divergence' : 'iv',
    'prebinning_method' : prebin_method,
    'min_prebin_size' : min_prebin_size,
    'max_n_prebins' : max_n_prebins,
    'min_n_bins' : min_n_bins,
    'solver': solver
    }
   
    binning_fit_params = {}
    for col in feature_list:
        binning_fit_params[col] = param_dict
       
    special_values = config_func['special_values']
     
    binning_process = BinningProcess(variable_names=feature_list,
                                     binning_fit_params=binning_fit_params,
                                     special_codes=special_values,verbose=True
                                )    
#    
#    list_categorical = df.select_dtypes(include=['object', 'category']).columns.values
#    selection_criteria = {"iv": {"min": 0.005, 'max':0.5, "strategy": "highest"}}
#    
#    binning_process= BinningProcess(categorical_variables=list_categorical,
#                            variable_names=feature_list
#                            )
                                     
    binning_process.fit(data[feature_list], data[target_col])
    return binning_process

def woe_encode(data, binning_process, config_func, config_general_info):
    #data=data_train.copy()
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)].tolist()
    feature_target=feature_list + [target_col]
    print('data:')
    print(data.shape)
    print(data['loan'].value_counts())
    data_woe = binning_process.transform(data[feature_list], metric='woe')
    print('data_woe:')
    print(data_woe.shape)
    #data2 = data[non_feature_columns]
    data_woe['loan']=data['loan'].values
    data_woe['COMP_APPL_ID']=data['COMP_APPL_ID'].values
    print(data_woe.shape)
    print(data_woe['loan'].value_counts())
    # Add non feature columns
    #data3 = pd.merge(data2, data_woe, left_index=True, right_index=True)
    # Re—adjust columns as original order
    #data4 = data3[data.columns]
     
    #return data4
    return data_woe
 
def get_bin_information(data, binning_process, config_func, config_general_info):
    #data=sal_application_train.copy()
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)].tolist()
 
    woe_summary_df = binning_process.summary()
    woe_summary_df.drop(['dtype','status','selected','js','quality_score'], axis=1, inplace=True)
    woe_summary_df.columns = ['COLUMN NAME', 'NUMBER OF BINS', 'IV', 'GINI']
   
    woe_bin_dict = {}
    woe_detailed_df_list = []
    for col in feature_list :
        #########
        optb = binning_process.get_binned_variable(col)
        try:
            woe_bin_dict[col]= optb.splits.tolist()
        except:
            woe_bin_dict[col]=[a.tolist() for a in optb.splits]
        # Remove total (Overall) row
        woe_detailed_df = optb.binning_table.build().iloc[:-1]
        # Remove if special or missing is empty
        woe_detailed_df = woe_detailed_df[woe_detailed_df['Count'] !=0]
        woe_detailed_df.drop('JS', axis=1, inplace=True)
        woe_detailed_df['COLUMN NAME'] = col
        woe_detailed_df = woe_detailed_df[['COLUMN NAME', 'Bin', 'Count', 'Count (%)', 'Non-event',
        'Event','Event rate', 'WoE', 'IV']]
        woe_detailed_df_list.append(woe_detailed_df)
       
    woe_detailed_df = pd.concat(woe_detailed_df_list)
 
    # Remove empty list
    woe_bin_dict = {k:v for k,v in woe_bin_dict.items() if v}
    #Relevant Mapping for scorecardpy (Accepts categorical with multiple seperated with %, %)
    woe_bin_dict = woe_bin_dict.copy()
    for col in data[feature_list].select_dtypes(['object', 'category']).columns:
        my_list = []
        for item in woe_bin_dict[col]:
            # If category is seperate keep it else combine them
            if len(item)==1:
                my_list.append(item[0])
            else:
                my_list.append('%,%'.join(str(item)))
        woe_bin_dict[col] = my_list
   
    # Format woe bin dict for excel
    woe_bins = pd.Series(woe_bin_dict).to_frame('BINS').reset_index()
    woe_bins.rename(columns={'index':'COLUMN NAME'}, inplace=True)
    woe_bins['BINS'] = woe_bins['BINS'].astype(str).str.strip('[]')
     
    return woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict

def plot_and_save_woe (data, binning_process, file_name, config_func, config_general_info):
 
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)].tolist()
    output_folder=config_general_info['output_folder']
   
    with PdfPages(output_folder+file_name) as pdf:
        for col in feature_list:
            if col in data.select_dtypes(np.number):
                optb = binning_process.get_binned_variable(col)
                df = optb.binning_table.build()
                # Remove overall row
                df = df.iloc[:-1]
                #Remove if special or missing is empty
                df = df[df['Count'] != 0]
         
                x = df['Bin'].values
                y1 = df['Non-event'].values
                y2 = df['Event'].values
                y3 = df['WoE'].values
                iv = np.round(df['IV'].sum(),3)

                fig , ax1 = plt.subplots(figsize=(12,6))
                p1 = ax1.bar(x, y1, color="tab:blue", label='Nonâ€”Event', bottom=df['Event'])
                p2 = ax1.bar(x, y2, color="tab:red", label='Event')
               
                ax1.set_ylabel('Bin Frequency', fontsize=14)
                ax1.set_xlabel('Bin', fontsize=14)
                ax1.set_title(f"{col},IV={iv}", fontsize=16)
                ax1.tick_params(axis='x', labelsize=14 , rotation=25)
                ax1.tick_params(axis='y', labelsize=14)
               
                ax2 = ax1.twinx()
               
                # Don't plot lines for special and null
                if 'Missing' in x and 'Special' in x:
                    ax2.plot(x[:-2],y3[:-2], linestyle="solid", marker="o", color="black")
                    ax2.scatter(x, y3, linestyle="solid", marker="o", color="black")
                    p1[-1].set_hatch('/')
                    p2[-1].set_hatch('/')
                    p1[-2].set_hatch('\\')
                    p1[-2].set_hatch('\\')
                elif 'Missing' in x or 'Special' in x:
                    ax2.plot(x[:-1],y3[:-1], linestyle="solid", marker="o", color="black")
                    ax2.scatter(x, y3, linestyle=" solid" ,marker="o", color="black")
                    p1[-1].set_hatch('/')
                    p2[-1].set_hatch('/')
                else :
                    ax2 .plot (x, y3, linestyle="solid", marker="o", color="black")
       
                    ax2.tick_params(axis='y', labelsize=14)
                    ax1.set_ylabel('WoE', fontsize=14)
                    ax1.legend(loc="upper left", bbox_to_anchor=(1.07,1), ncol=1)
                    plt.tight_layout()
                    pdf.savefig(fig, bbox_inches='tight')
                    plt.close()
                   
                    # Categorical features
            elif col in data.select_dtypes(['object','category']):
                optb = binning_process.get_binned_variable(col)
                df = optb.binning_table.build()
                df = df.iloc[:-1]
                y1 = df['Non-event'].values
                y2 = df['Event'].values
                y3 = df['WoE'].values
               
                iv = np.round(df['IV'].sum(), 3)
             
                fig, ax1 = plt.subplots(figsize=(12,6))
                p1 = ax1.bar(range(len(df)), y1, color="tab:blue", bottom=y2)
                p2 = ax1.bar(range(len(df)), y2, color="tab:red")
                handles = [p1[0], p2[0]]
                labels = ['Non-event','Event']
               
                p1[-1].set_hatch('\\')
                p2[-1].set_hatch('\\')
                handle_missing = mpatches.Patch(hatch= "\\", alpha=0.3)
                label_missing = "Bin Missing"
               
                p1[-2].set_hatch("/")
                p1[-2].set_hatch("/")
                handle_missing = mpatches.Patch(hatch= "/", alpha=0.3)
                label_missing = "Bin Special"
               
                handles.extend([handle_special, handle_missing])
                labels.extend([label_special, label_missing])
                 
                ax1.set_ylabel('Bin Frequency', fontsize=14)
                ax1.set_xlabel('Bin', fontsize=14)
                ax1.set_title(f"{col},IV={iv}", fontsize=16)
                ax1.tick_params(labelsize=14)
                ax2 = ax1.twinx()
               
                ax2.plot(range(len(df)-2),y3[:-2], linestyle="solid",marker="o",color="black")
                ax2.scatter(range(len(df)), y3, linestyle="solid",marker="o",color="black")
                ax2.tick_params(axis='y', labelsize=14)
                ax2.set_ylabel('WoE', fontsize=14)  
                ax1.xaxis.set_major_locator(MaxNLocator(integer=True))  
                ax1.legend(handles,labels,loc="upper left", bbox_to_anchor =(1.07 ,1), ncol=1)
                plt.tight_layout()
                pdf.savefig(fig, bbox_inches='tight')
                plt.close()
                     
def adjust_bins_interactively (data, config_func, config_general_info, woe_bin_dict):
    #data=sal_application_train.copy()
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)]
   
    feature_target= feature_list.tolist() + [target_col]
     
    special_values = config_func['special_values']
   
    # Read the file where the optimal bins are stored
    folder_path = config_general_info['output_folder']
    input_file_name = woe_bin_dict.copy()
    #with open (folder_path+input_file_name) as json_file:
    #    woe_bin_dict = json.load(json_file)

    # Create the binnings first
    print(data[feature_target].columns.tolist())
    optimal_bins = sc.woebin(data[feature_target] , y=target_col, break_list=woe_bin_dict,
    special_values=special_values)
    # Interactive Adjusting
    manually_adjusted_bins= sc.woebin_adj(data[feature_target] , y=target_col, bins=optimal_bins,
    adj_all_var=True)
    # Get the bins as list
    manually_adjusted_bins = ast.literal_eval(manually_adjusted_bins)

    #Save dictionary to a json file
# =============================================================================
#     output_file_name = config_func['woe_bin_dict_adjusted']
#     with open (folder_path+output_file_name, 'w') as f:
#         json.dump(manually_adjusted_bins, f)
# =============================================================================

    return manually_adjusted_bins
 
def apply_manually_adjusted_bins(data, manually_adjusted_bins, config_func, config_general_info):
    #data=sal_application_train.copy()
    non_feature_columns=config_general_info['non_feature_columns']
    target_col=config_general_info['target_col']
    feature_list=data.columns[~data.columns.isin(non_feature_columns)].tolist()
    feature_target = feature_list + [target_col]
     
    binning_fit_params = {}
   
    for k, v in manually_adjusted_bins.items():
        binning_fit_params[k] = {'user_splits':v}
        binning_fit_params[k].update({'user_splits_fixed': len(v)* [True]})

    special_values = config_func['special_values']
   
    binning_process = BinningProcess(variable_names=feature_list,
                                      binning_fit_params=binning_fit_params,
                                      special_codes=special_values,verbose=True)
   
    binning_process.fit(data[feature_list],data[target_col])
# =============================================================================
#     numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
#     data_num = data[feature_list].select_dtypes(include=numerics)
#    
#     feature_list=data_num.columns.tolist()
#     binning_process = BinningProcess(variable_names=feature_list,
#                                      binning_fit_params=binning_fit_params,
#                                      special_codes=special_values,verbose=True)
#    
#     binning_process.fit(data[feature_list],data[target_col])
#    
#     data_cat = data[feature_list].select_dtypes(include=['object', 'category'])
#     feature_list2=data_cat.columns.tolist()
#     binning_process2 = BinningProcess(variable_names=feature_list2,
#                                      binning_fit_params=binning_fit_params,
#                                      special_codes=special_values,verbose=True)
#    
#     binning_process2.fit(data[feature_list2],data[target_col])
#    
# =============================================================================
# =============================================================================
#     selection_criteria = {"iv": {"min": 0.005, 'max':0.5, "strategy": "highest"}}
#     data_cat = data[feature_list].select_dtypes(include=['object', 'category'])
#    
#     feature_list2=data_cat.columns.tolist()
#     len(feature_list)
#     feature_list_all=data.drop(columns=['loan']).columns.values
#    
#     binning_process = BinningProcess(
#     categorical_variables=feature_list2,
#     variable_names=feature_list,
#     binning_fit_params=binning_fit_params,
#     selection_criteria=selection_criteria)
#     binning_process.fit(data[feature_list],data[target_col])
# =============================================================================
   
    return binning_process
 
def woe_manual_combined(data_train, data_test, data_oot_nc, data_oot_c, config_func,
config_general_info):
# =============================================================================    
# =============================================================================
#     data_train=sal_application_train_num.copy()
#     data_test=sal_application_test[num_features].copy()
#     data_oot_nc=sal_noot[num_features].copy()
#     data_oot_c=sal_oot[num_features].copy()
# =============================================================================
# =============================================================================
   
# =============================================================================
#     config_excel_info = config_func['excel_info_adjusted']
#     output_folder=config_general_info['output_folder']
#     excel_name=config_excel_info['excel name']
#     excel_writer = pd.ExcelWriter(output_folder+excel_name, engine='xlsxwriter')
#     plot_file_name = config_func['woe_plot_pdf_adjusted']
#      
# =============================================================================
    #Read json file where manually adjusted bins are stored
# =============================================================================
#     folder_path = config_general_info['output_folder']
#     file_name = config_func['woe_bin_dict_adjusted']
#     with open(folder_path + file_name) as json_file:
#         manually_adjusted_bins = json.load(json_file)
#        
# =============================================================================
    # Get woe bins using train set
    binning_process = apply_manually_adjusted_bins(data_train,manually_adjusted_bins, config_func,
    config_general_info)
   
    # Calculate and save the information
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(data_train,binning_process, config_func, config_general_info)  
   
# =============================================================================
#     woe_summary_df.to_excel(excel_writer,index=False, sheet_name=config_excel_info['sheet_name'][0])
#     woe_detailed_df.to_excel(excel_writer, index=False, sheet_name=config_excel_info['sheet_name'][1])
#     woe_bins.to_excel(excel_writer, index=False, sheet_name=config_excel_info['sheet_name'][2])
#     excel_writer.save()
#      
#     # Save plots
#     plot_and_save_woe(data_train, binning_process , plot_file_name, config_func, config_general_info)
#     # Save plots
#     plot_and_save_woe(data_train, binning_process, plot_file_name, config_func, config_general_info)
#    
# =============================================================================
    # Encode datasets
    data_train_woe = woe_encode(data_train, binning_process, config_func, config_general_info)
   
    data_test_woe = woe_encode(data_test, binning_process, config_func, config_general_info)  
    data_oot_nc_woe = woe_encode(data_oot_nc, binning_process, config_func, config_general_info)
    data_oot_c_woe= woe_encode(data_oot_c, binning_process, config_func, config_general_info)
     
    return data_train_woe, data_test_woe, data_oot_nc_woe, data_oot_c_woe

def woe_manual_combined_no_change(binning_process,data_train, data_test, data_oot_nc, data_oot_c, config_func,
config_general_info):    
    # Calculate and save the information
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(data_train,binning_process, config_func, config_general_info)  
    # Encode datasets
    data_train_woe = woe_encode(data_train, binning_process, config_func, config_general_info)
   
    data_test_woe = woe_encode(data_test, binning_process, config_func, config_general_info)  
    data_oot_nc_woe = woe_encode(data_oot_nc, binning_process, config_func, config_general_info)
    data_oot_c_woe= woe_encode(data_oot_c, binning_process, config_func, config_general_info)
     
    return data_train_woe, data_test_woe, data_oot_nc_woe, data_oot_c_woe

def woe_test():
    self_model.set_index('COMP_APPL_ID', inplace = True)
    df_application_train, df_application_test, y_train, y_test = train_test_split(
    self_model, self_model.loan, test_size=0.2, random_state=42)
   
    df_application_train.dtypes.value_counts()
    df_application_train.select_dtypes(include='object')
   
   
    list_features = df_application_train.drop(columns=['loan']).columns.values
    list_categorical = df_application_train.select_dtypes(include=['object', 'category']).columns.values
    selection_criteria = {"iv": {"min": 0.005, 'max':0.5, "strategy": "highest"}}
       
    binning_process = BinningProcess(
    categorical_variables=list_categorical,
    variable_names=list_features,
    selection_criteria=selection_criteria)
   
    logreg = LogisticRegression(C=3, max_iter=1000, random_state=161)
   
    df_application_train.shape
    scaling_method = "min_max"
    scaling_method_data = {"min": 0, "max": 1000}
    scorecard = Scorecard(
    target='loan',
    binning_process=binning_process,
    estimator=logreg,
    scaling_method=scaling_method,
    scaling_method_params=scaling_method_data,
    intercept_based=False,
    reverse_scorecard=True)

    scorecard.fit(df_application_train)
    scorecard_summary = scorecard.table(style="detailed").round(3)
    scorecard_summary.to_csv(r'C:\Users\jain vibhanshu\Desktop\VJ\Cases\LICHFL\Processed Data\self_scr.csv')
    scorecard_summary

# =============================================================================
# def psi_calc():
#     def psi_func(data, config_func,config_general_info):
#         '''
#         psi_func is a function to find the PSI (Population Stability Index) values for each column between selected year combinations
#        
#         Parameters
#      .l;   ----------
#         data: The data that will be used in the models
#         config_func: Config parameters related to this function
#         config_general_info: General config parameters related to the data and model
#        
#         Output(s)
#         ---------
#         psi_final: PSI results for each feature for the given year pairs
#         psi_detailed: Detailed PSI results which shows the terms of PSI at each bi/year pair/column values
#         '''
#    
#         #Creating an array containing only features
#         non_feature_columns=config_general_info['non_feature_columns']
#         feature_list=data.columns[~data.columns.isin(non_feature_columns)]
#        
#         #Creating the year related data
#         data_psi=data.copy()
#         date_col=config_general_info['date_col']
#         data_psi['YEAR']=data_psi[date_col].dt.year
#         year_array=np.sort((data_psi['YEAR']).unique())
#         num_years=len(year_array)
#        
#         #Getting PSI related parameters
#         is_consecutive=config_func['is_consecutive']
#         is_first_last=config_func['is_first_last']
#         other_group_year1=config_func['other_groups_year1']
#         other_group_year2=config_func['other_groups_year2']
#         num_other_groups=len(other_groups_year1)
#        
#         #Creating the DataFrames which will contain PSI values
#         psi_final=pd.DataFrame()
#         psi_final['COLUMN NAME']=feature_list
#         psi_detailed=pd.DataFrame()
#        
#         #Getting the PSI values between consecutive years
#         if is_consecutive ==True:
#          
#             #Getting the PSI values
#             for i in range (num_years-1):
#            
#                 #Selecting the years for the first and the second group of years of PSI analysis
#                 years1=[year_array[i]]
#                 years2= [year_array[i+1]]
#                
#                 #Apply PSI for each feature for the given year periods
#                 psi_final_single, psi_detailed_single = psi_bw_years(data_psi, years1, years2, config_func, config_general_info)
#                
#                 #Combining the new results with the existing ones
#                 psi_detailed=pd.concat([psi_detailed,psi_detailed_single])
#                 psi_final=pd.merge(psi_final ,psi_final_single, on='COLUMN NAME', how='left')
#                
#             psi_final['MAX PSI CONSECUTIVE YEARS']=psi_final[psi_final.columns[1:]].max(axis=1)
#            
#         #Getting the PSI values between first and last
#         if is_first_last==True:
#        
#             #Selecting the years for the first and the second group of years fo PSI analysis
#             years1=[year_array[0]]
#             years2=[year_array[-1]]
#            
#                     #Apply PSI for each feature for the given year periods
#             psi_final_single, psi_detailed_single = psi_bw_years(data_psi, years1, years2, config_func, config_general_info)
#            
#             #Combining the new results with the existing ones
#             psi_detailed=pd.concat([psi_detailed,psi_detailed_single])
#             psi_final=pd.merge(psi_final,psi_final_single, on='COLUMN NAME', how='left')
#            
#         #Getting the PSI values for other year groups that were given in the config files
#         for i in range(num_other_groups):
#        
#             #Selecting the years for the first and the second group of years of PSI analysis
#             years1=other_groups_year1[i]
#             years2=other_groups_year2[i]
#            
#             #Apply PSI for each feature for the given year periods
#             psi_final_single, psi_detailed_single = psi_bw_years(data_psi, years1, years2, config_func, config_general_info)
#            
#             #Combining the new results with the existing ones
#             psi_detailed=pd.concat([psi_detailed,psi_detailed_single])
#             psi_final=pd.merge(psi_final,psi_final_single,on='COLUMN NAME',how='left')
#            
#         #Formatting the final tables
#         psi_final['MAX PSI VALUE']=psi_final[psi_final.columns[1:]].max(axis=1)
#         psi_detailed=psi_detailed.reset_index(drop=True)
#        
#         return psi_final, psi_detailed
#    
#     def feat_flag_psi(data,config_func,config_general_info):
#         '''
#         feat_flag_psi is a function to find the PSI (Population Stability Index) values for each column between different adjacent years and flag
#         features based on their PSI values
#        
#         Parameters
#         ----------
#         data: The data that will be used in the models
#         config_func: Config parameters related to this function
#         config_general_info: General config parameters related to data and model
#        
#         Output(s)
#         ---------
#         flagged_columns: Flagged columns after this feature flagging step
#         psi_final: PSI results for each feature for the given year pairs
#         psi_detailed: Detailed PSI results which shows the terms of PSI at each bin/year pair/column values
#         '''
#         #Getting the PSI results
#         psi_final, psi_detailed=psi_func(data, config_func, config_general_info)
#        
#         #Flagging features with high PSI values
#         psi_limit=config_func['psi_limit']
#         psi_final['FLAGGED BY PSI']=(psi_final['MAX PSI VALUE']>psi_limit).astype(int)
#          
#         #Getting the flagged column names
#         flagged_columns=psi_final['COLUMN NAME'][psi_final['FLAGGED BY PSI']==1].values
#        
#         return flagged_columns, psi_final, psi_detailed
#    
#     def feat_elim_psi(data,config_func, config_general_info):
#         '''
#         feat_elim_psi is a function to find the PSI (Population Stability Index) values for each column between different adiacent years and eliminate
#         features based on their PSI values
#    
#         feat_elim_psi is a function to find the PSI (Population Stability Index)values for each column between different adjacent years and eliminate  
#         features based on their PST values
#        
#         Parameters
#         ----------
#         data: The data that will be used in the models
#         config_func: Config parameters related to this function
#         config_general_info: General config parameters related to the data and model
#        
#         Output(s)
#         ---------
#         dropped_columns: Dropped columns after this feature elimination step
#         psi_final: PSI results for each feature for the given year pairs
#         psi_detailed: Detailed PSI results which shows the terms of PSI at each bin/year pair/column values
#         '''
#         #Getting the PSI results
#         psi_final, psi_detailed=psi_func(data, config_func, config_general_info)
#        
#         #Flagging features with high PSI values
#         psi_limit=config_func['psi_limit']
#         psi_final['ELIMINATED BY PSI']=(psi_final['MAX PSI VALUE']>psi_limit.astype(int)
#          
#         #Getting the flagged column names
#         #dropped_columns=psi_final['COLUMN NAME'][psi_final['ELIMINATED BY PSI']==1].values
#          
#         #return dropped_columns, psi_final, psi_detailed
#
# =============================================================================
# =============================================================================
# PSI
# =============================================================================
def calculate_psi(expected, actual, buckettype='bins', buckets=10, axis=0):
    '''Calculate the PSI (population stability index) across all variables
    Args:
       expected: numpy matrix of original values
       actual: numpy matrix of new values, same size as expected
       buckettype: type of strategy for creating buckets, bins splits into even splits, quantiles splits into quantile buckets
       buckets: number of quantiles to use in bucketing variables
       axis: axis by which variables are defined, 0 for vertical, 1 for horizontal
    Returns:
       psi_values: ndarray of psi values for each variable
    Author:
       Matthew Burke
       github.com/mwburke
       worksofchart.com
    '''

    def psi(expected_array, actual_array, buckets):
        '''Calculate the PSI for a single variable
        Args:
           expected_array: numpy array of original values
           actual_array: numpy array of new values, same size as expected
           buckets: number of percentile ranges to bucket the values into
        Returns:
           psi_value: calculated PSI value
        '''

        def scale_range (input, min, max):
            input += -(np.min(input))
            input /= np.max(input) / (max - min)
            input += min
            return input


        breakpoints = np.arange(0, buckets + 1) / (buckets) * 100

        if buckettype == 'bins':
            breakpoints = scale_range(breakpoints, np.min(expected_array), np.max(expected_array))
        elif buckettype == 'quantiles':
            breakpoints = np.stack([np.percentile(expected_array, b) for b in breakpoints])



        expected_percents = np.histogram(expected_array, breakpoints)[0] / len(expected_array)
        actual_percents = np.histogram(actual_array, breakpoints)[0] / len(actual_array)

        def sub_psi(e_perc, a_perc):
            '''Calculate the actual PSI value from comparing the values.
               Update the actual value to a very small number if equal to zero
            '''
            if a_perc == 0:
                a_perc = 0.0001
            if e_perc == 0:
                e_perc = 0.0001

            value = (e_perc - a_perc) * np.log(e_perc / a_perc)
            return(value)

        psi_value = np.sum(sub_psi(expected_percents[i], actual_percents[i]) for i in range(0, len(expected_percents)))

        return(psi_value)

    if len(expected.shape) == 1:
        psi_values = np.empty(len(expected.shape))
    else:
        psi_values = np.empty(expected.shape[axis])

    for i in range(0, len(psi_values)):
        if len(psi_values) == 1:
            psi_values = psi(expected, actual, buckets)
        elif axis == 0:
            psi_values[i] = psi(expected[:,i], actual[:,i], buckets)
        elif axis == 1:
            psi_values[i] = psi(expected[i,:], actual[i,:], buckets)

    return(psi_values)

def calc_psi(sal_oot, sal_application_train, sal_application_test):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    oot_data = sal_oot.select_dtypes(include=numerics)
    test_data = sal_application_test.select_dtypes(include=numerics)
    train_data = sal_application_train.select_dtypes(include=numerics)
    numerical_column_list=test_data.columns.tolist()
    print(numerical_column_list)
    train_data = train_data.to_numpy()
    test_data = test_data.to_numpy()
    oot_data = oot_data.to_numpy()
    psi_values_1 = calculate_psi(train_data, test_data, buckettype='bins', buckets=10, axis=1)
    psi_values_2 = calculate_psi(train_data, oot_data, buckettype='bins', buckets=10, axis=1)
    df_psi=pd.DataFrame()
    df_psi['psi_1_tt']=psi_values_1
    df_psi['psi_2_to']=psi_values_2
    df_psi['Column']=numerical_column_list
    return df_psi
# =============================================================================
#     numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
#     oot_data = self_oot.select_dtypes(include=numerics)
#     test_data = self_application_test.select_dtypes(include=numerics)
#     train_data = self_application_train.select_dtypes(include=numerics)
#     train_data = train_data.to_numpy()
#     test_data = test_data.to_numpy()
#     oot_data = oot_data.to_numpy()
#     psi_values = calculate_psi(train_data, test_data, buckettype='bins', buckets=10, axis=1)
#     psi_values = calculate_psi(train_data, oot_data, buckettype='bins', buckets=10, axis=1)
# =============================================================================

def del_extra_cols(sal_model_oot, sal_model_noot):
    lst = ['FIRST_DISB_DATE']
    for i in lst:
        sal_model_oot.drop(i, axis = 1, inplace = True)
        sal_model_noot.drop(i, axis = 1, inplace = True)
        #sal_application_test.drop(i, axis = 1, inplace = True)
    return sal_model_oot, sal_model_noot

def agg_numeric(df, group_var, df_name):
    """
    Inputs: df         = Dataframe on which calculations need to be done    
            group_var  = ID for grouping
            df_name    = prefix for identifying calculations
    Output: agg        = data frame with sum and mean for numeric caclulations
    """
    # Remove id variables other than grouping variable
    for col in df:
        if col != group_var and 'CUST_KEY' in col:
            df = df.drop(columns = col)
    group_ids = df[group_var]
    numeric_df = df.select_dtypes('number')
    numeric_df[group_var] = group_ids
    # Group by the specified variable and calculate the statistics
    agg = numeric_df.groupby(group_var).agg(['count', 'mean', 'max', 'min', 'sum']).reset_index()
    # Need to create new column names
    columns = [group_var]
    # Iterate through the variables names
    for var in agg.columns.levels[0]:
        # Skip the grouping variable
        if var != group_var:
            # Iterate through the stat names
            for stat in agg.columns.levels[1][:-1]:
                # Make a new column name for the variable and stat
                columns.append('%s_%s_%s' % (df_name, var, stat))
    agg.columns = columns
    return agg

#Launcher
def calc_vif_one_shot(df):
    # Calculating VIF
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    df = df.select_dtypes(include=numerics)
    vif = pd.DataFrame()
    vif["variables"] = df.columns
    vif["VIF"] = [variance_inflation_factor(df.values, i) for i in range(df.shape[1])]
    return(vif)
   
if __name__ == "__main__":

    start_time = time.time()

    #----------------------------------------read data-------------------------------------------------
    #Read model data file:  
    regex = os.path.join(config['REPO_PATH']+config['MODEL_DATA_SELF'])  + "\*"
    self_model = read_latest_data(regex,"csv")
       
    regex = os.path.join(config['REPO_PATH']+config['MODEL_DATA_SAL'])  + "\*"
    sal_model = read_latest_data(regex,"csv")
   
    sal_model.to_csv(r"C:\Users\vishwesh kumar\Videos\LIC\Processed Data\self\_LIC_sal.csv",index=False)
    self_model.to_csv(r"C:\Users\vishwesh kumar\Videos\LIC\Processed Data\self\LIC_self.csv",index=False)


#     test_self.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\Test\Test_self.csv')
#     test_sal.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\Test\Test_sal.csv')  
# =============================================================================
    start_time = compute_time(start_time, 'Data load completed')  
   
   
    for i in self_model.columns.tolist():
        if '_norm' in str(i):
            print(i)
            print(self_model[i].max())
            self_model[i]=self_model[i]*10
    self_model['L_B_EMPLOYEMENT_SLAB_grp_Self-Employed_count_norm'].max()
   
# =============================================================================
#     CIBIL at customer level    
# =============================================================================
    model_df=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\model_df.csv')
    model_df['COMP_APPL_ID'].nunique()

   
    cibil_model=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\cibil processed v1\final_CIBIL.csv')
    cibil_model.columns.tolist()[:100]
    # _x years, _y months or deduce by looking at values
    model_df2=model_df[['CUSTOMERID','GUAR_COAP_FLAG','FIRST_DISB_DATE']]
   
    cibil_model=pd.merge(cibil_model,model_df2,on='CUSTOMERID',how='left')
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# =====================================================================================
#     cibil_model_pre_roll_up_iv_filter 0.01
# =============================================================================
    not_all_miss_cibil_model=cibil_model.columns[~(cibil_model.isna().mean() == 1)].tolist()
   
    cibil_model_pre_roll_up_iv_filter,woe_summary_df,woe_detailed_df = get_iv(cibil_model, 0.01)

# =============================================================================
# split first as sal & self
# =============================================================================
    cibil_sal  =cibil_model[cibil_model['EMPLOYEMENT_SLAB_grp']=='Salaried']
    cibil_self =cibil_model[~(cibil_model['EMPLOYEMENT_SLAB_grp']=='Salaried')]
   
    #sal
    not_all_miss_cibil_model=cibil_sal.columns[~(cibil_sal.isna().mean() == 1)].tolist()
    cibil_sal=cibil_sal[not_all_miss_cibil_model]
    cibil_model_pre_roll_up_iv_filter,woe_summary_df,woe_detailed_df = get_iv(cibil_sal, 0.01)

   
    #self
    not_all_miss_cibil_model=cibil_self.columns[~(cibil_self.isna().mean() == 1)].tolist()
    cibil_self=cibil_self[not_all_miss_cibil_model]
    cibil_model_pre_roll_up_iv_filter,woe_summary_df,woe_detailed_df = get_iv(cibil_self, 0.01)


# =============================================================================
#     # split first as sal & self ends
# =============================================================================
   
   
    del cibil_model_pre_roll_up_iv_filter['MRN']
    del cibil_model_pre_roll_up_iv_filter['CUSTOMERID']
   
    cibil_model_P2=cibil_model_pre_roll_up_iv_filter[cibil_model_pre_roll_up_iv_filter['GUAR_COAP_FLAG']=='P']
   
   
    not_all_miss_cibil_model=cibil_model_pre_roll_up_iv_filter.columns[~(cibil_model_pre_roll_up_iv_filter.isna().mean() == 1)].tolist()
    cibil_model_pre_roll_up_iv_filter=cibil_model_pre_roll_up_iv_filter[not_all_miss_cibil_model]
   

   
    cibil_model_B2 = agg_numeric(cibil_model_pre_roll_up_iv_filter, 'COMP_APPL_ID', 'L_B')
   
# =============================================================================
#     for i in cibil_model_B.columns.tolist():
#         if 'CUSTOMERID' in i:
#             print(i)
# =============================================================================            
    del cibil_model_B2['L_B_loan_count']
    del cibil_model_B2['L_B_loan_mean']
    del cibil_model_B2['L_B_loan_max']
    del cibil_model_B2['L_B_loan_min']
    del cibil_model_B2['L_B_loan_sum']
   
    cibil_model_B2['COMP_APPL_ID']
    cibil_model_B2['GUAR_COAP_FLAG']
    cibil_model_B2['loan']
   
    cibil_model_pre_roll_up_iv_filter['COMP_APPL_ID'].nunique()
    cibil_model_pre_roll_up_iv_filter['loan'].nunique()
    cibil_model_pre_roll_up_iv_filter['GUAR_COAP_FLAG'].nunique()
   
    cibil_model_B2_loan= cibil_model_pre_roll_up_iv_filter[['COMP_APPL_ID','loan']].groupby(["COMP_APPL_ID"],as_index=False).max()
   
   
    cibil_model_B2= pd.merge(cibil_model_B2,cibil_model_B2_loan,on='COMP_APPL_ID',how='left')
    #56777
       
    cibil_model_B2,woe_summary_df2,woe_detailed_df2 = get_iv(cibil_model_B2, 0.1)
   
    del cibil_model_B2['loan']
   
    cibil_model_P2= pd.merge(cibil_model_P2,cibil_model_B2,on='COMP_APPL_ID',how='left')
    cibil_model_P2['loan'].value_counts()
       
 #not to run for iter 3  
#    cibil_sal  =cibil_model_P2[cibil_model_P2['EMPLOYEMENT_SLAB_grp']=='Salaried']
#    cibil_self =cibil_model_P2[~(cibil_model_P2['EMPLOYEMENT_SLAB_grp']=='Salaried')]        
# =============================================================================
#     cibil_sal2=handle_missing_value(cibil_sal)
#     cibil_sal2=get_iv_old(cibil_sal2, 0.01)
#     cibil_sal2.columns.tolist()    
#     cibil_self2=handle_missing_value(cibil_self)
#     cibil_self2=get_iv_old(cibil_self2, 0.01)
#    
#     cibil_sal=cibil_sal[cibil_sal2.columns.tolist()]
#    
#     cibil_self=cibil_self[cibil_self2.columns.tolist()]
#     #filter primary appl
#     cibil_sal2 = agg_numeric(cibil_sal, 'COMP_APPL_ID', 'L_B')
#     cibil_self2 = agg_numeric(cibil_self, 'COMP_APPL_ID', 'L_B')
#    
#     cibil_sal2=pd.merge(cibil_sal2,cibil_sal[['COMP_APPL_ID','loan']],on='COMP_APPL_ID',how='left')
#     cibil_self2=pd.merge(cibil_self2,cibil_self[['COMP_APPL_ID','loan']],on='COMP_APPL_ID',how='left')
#    
#     cibil_sal2=pd.merge(cibil_sal2,sal_model[['COMP_APPL_ID','FIRST_DISB_DATE']],on='COMP_APPL_ID',how='left')
#     cibil_self2=pd.merge(cibil_self2,self_model[['COMP_APPL_ID','FIRST_DISB_DATE']],on='COMP_APPL_ID',how='left')
#    
# =============================================================================
   
   
    cibil_sal.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\cibil processed v1\cibil_long_sal.csv',index=False)
    cibil_self.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\cibil processed v1\cibil_long_self.csv',index=False)

#----------------------------------------read data-------------------------------------------------
    cibil_sal= pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\cibil processed v1\cibil_sal.csv')
    cibil_self= pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\cibil processed v1\cibil_self.csv')
   
    cibil_sal=cibil_model_P2.copy()
   
    print(cibil_sal['loan'].value_counts())
    cibil_self['loan'].value_counts()
    #----------------------------------------Data cleaning----------------------------------------------
    cibil_sal=cibil_sal.replace([-np.inf,np.inf], np.nan)
    #cibil_sal=missing_values_table(cibil_sal)
   
    #sal 2015, self 2016
    sal_oot, sal_noot = oot_split(cibil_sal, '2016-12-31')
   
    sal_oot, sal_noot= del_extra_cols(sal_oot, sal_noot)
    sal_noot['loan'].value_counts()
    sal_oot['loan'].value_counts()
   
    sal_application_train, sal_application_test, y_train, y_test = train_split(sal_noot, config['TEST_SPLIT'])
    sal_application_train['loan'].value_counts()
    sal_application_test['loan'].value_counts()
   
    len( set(sal_application_train.columns.tolist()) )
   
    not_all_miss_train=sal_application_train.columns[~(sal_application_train.isna().mean() == 1)].tolist()
#    all_miss_test=sal_application_test.columns[sal_application_train.isna().mean() == 1].tolist()
#    all_miss_oot=sal_oot.columns[sal_application_train.isna().mean() == 1].tolist()
    sal_application_train=sal_application_train[not_all_miss_train]


   
   

    #sal_application_train,woe_summary_df,woe_detailed_df = get_iv(sal_application_train, 0.1)
#    woe_summary_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\IV_sal_v3_long_iter_3_vif_0.1.csv')
#    woe_detailed_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\IV_detailed_sal_v3_long_iter_3_vif_0.1.csv')

   
    sal_application_train2=handle_missing_value(sal_application_train)
    vif=calc_vif_one_shot(sal_application_train2)
    vif.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\VIF_sal_long_iter_3.1_vif_0.01_P_0.1_B.csv')
   
    woe_summary_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\IV_sal_long_iter_3.1_0.01_P_0.1_B_all.csv')
    woe_detailed_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\IV_detailed_sal_long_iter_3.1_0.01_P_0.1_B_all.csv')
    woe_summary_df2.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\IV_sal_long_iter_3.1_0.01_P_0.1_B_both.csv')
    woe_detailed_df2.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\IV_detailed_sal_long_iter_3.1_0.01_P_0.1_B_both.csv')

   
    identify_correlation(sal_application_train2, config2)
   
    cibil_sal.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\cibil processed v1\cibil_long_sal_iter_3.1.csv',index=False)
    #calculate_vif(sal_application_train,config2)
    #----------------------------------------Data cleaning CIBIL self----------------------------------------------
    cibil_self=cibil_self.replace([-np.inf,np.inf], np.nan)
    cibil_self=missing_values_table(cibil_self)

    cibil_self['loan'].value_counts()

    self_oot, self_noot = oot_split(cibil_self, '2016-12-31')
   
    self_oot, self_noot= del_extra_cols(self_oot, self_noot)
    self_noot['loan'].value_counts()
    self_oot['loan'].value_counts()
   
    self_application_train, self_application_test, y_train, y_test = train_split(self_noot, config['TEST_SPLIT'])
    self_application_train['loan'].value_counts()
    self_application_test['loan'].value_counts()

    self_application_train,woe_summary_df,woe_detailed_df = get_iv(self_application_train, 0.01)
    woe_summary_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\IV_self.csv')
    woe_detailed_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\IV_detailed_self.csv')
   
    self_application_train2=handle_missing_value(self_application_train)
    vif=calc_vif_one_shot(self_application_train2)
    vif.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\Report_KV\CIBIL\VIF_self.csv')
    identify_correlation(self_application_train, config2)

   
    #----------------------------------------Data cleaning----------------------------------------------
#salaried model
    cibil_sal=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\cibil processed v1\cibil_long_sal_iter_3.1.csv')
   
    cols=pd.read_excel(r'C:\Users\vishwesh kumar\Videos\LIC\CIBIL_models_May_10\Master Sheet_CIBIL_May_9.1_updt.xlsx' , sheet_name='Master Variable Sheet 2')
    feat1=cols[cols['Analysed']==1]['Feature'].values.tolist()
   
    feat2=cols[cols['Analysed']==1]['Next Best Feature'].dropna().values.tolist()
    feat2=[x for xs in feat2 for x in xs.split(',')]
    feat=list(set(feat1+feat2))
    #considering only first set of choices
    non_match=set(feat1)-set(cibil_sal.columns.tolist())
   
    feat=set(feat1)-set(non_match)
    non_match_corrected=['Accounts_opened_in_L3m']
    feat=list(feat.union(set(non_match_corrected)))
   
    cibil_sal['Accounts_opened_in_L3m']
 #self
 
 #'L_B_Accounts_opened_in_L3m_sum', #Accounts_opened_in_L3m chosen
 #'L_B_Credit Card_x_count'} # NA
   
    #sal
 #'Credit Card_30DPD_instances_L12M' vif 0.01 removed
 #'L_B_Overall_credit_vintage(months)_max' #Overall_credit_vintage(years)
 
   

    sal_model=cibil_sal[feat+['loan','COMP_APPL_ID','FIRST_DISB_DATE']]
    #2015 for sal and 2016 for self
    sal_oot, sal_noot = oot_split(sal_model, '2016-12-31')
    sal_oot, sal_noot= del_extra_cols(sal_oot, sal_noot)
    sal_oot = missing_value_filter(sal_oot)
    sal_noot = missing_value_filter(sal_noot)

    #sal
    data_test_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Sal\data_test_woe_May_10.csv')
    data_train_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Sal\data_train_woe_May_10.csv')
    #self
    data_test_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Self\data_test_woe_self_May_10.csv')
    data_train_woe=pd.read_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\May_10\Self\data_train_woe_self_May_10.csv')
   
    sal_application_train=pd.merge(data_train_woe['COMP_APPL_ID'],sal_noot,how='left',on='COMP_APPL_ID')
    sal_application_test=pd.merge(data_test_woe['COMP_APPL_ID'],sal_noot,how='left',on='COMP_APPL_ID')
    y_train=sal_application_train['loan'].values
    y_test=sal_application_test['loan'].values
   
    #sal_application_train, sal_application_test, y_train, y_test = train_split(sal_noot, config['TEST_SPLIT'])
   
    sal_application_train = get_iv(sal_application_train, 0.01)
   
    #drop vif columns and generate data again
    df_psi=calc_psi(sal_oot, sal_application_train, sal_application_test)
   
    df_psi[(df_psi['psi_1_tt']>0.4)|(df_psi['psi_2_tt']>0.4)]
    df_psi[(df_psi['psi_1_tt']>0.4)&(df_psi['psi_2_tt']>0.4)]
   



    #woe codes
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    sal_application_train_num = sal_application_train.select_dtypes(include=numerics)
   
    sal_application_train_cat = sal_application_train.select_dtypes(include=['object', 'category'])
    sal_application_train_cat['loan']=sal_application_train['loan']
    sal_application_train_cat['COMP_APPL_ID']=sal_application_train['COMP_APPL_ID']
   
    #column list
    num_features=sal_application_train_num.columns.tolist()
    cat_features=sal_application_train_cat.columns.tolist()
   
    #Numerical columns##############################################
    binning_process = find_optimal_bins(sal_application_train_num, config_func, config_general_info)
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(sal_application_train_num, binning_process, config_func, config_general_info)
   
    #manually_adjusted_bins = adjust_bins_interactively(sal_application_train_num, config_func, config_general_info, woe_bin_dict)
   
    #binning_process=apply_manually_adjusted_bins(sal_application_train_num, manually_adjusted_bins, config_func, config_general_info)
   
    #woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(sal_application_train_num, binning_process, config_func, config_general_info)
   
    data_train_woe_num, data_test_woe_num, data_oot_nc_woe_num, data_oot_c_woe_num = woe_manual_combined_no_change(binning_process, sal_application_train_num,
                                                                  sal_application_test[num_features],
                                                                  sal_noot[num_features],
                                                                  sal_oot[num_features],
                                                                  config_func,
                                                                  config_general_info)
   
    data_oot_c_woe_num['loan'].value_counts()
    data_oot_c_woe_num['loan'].value_counts(dropna=False)

    #Categorical columns##############################################
    binning_process_cat = find_optimal_bins(sal_application_train_cat, config_func, config_general_info)
    woe_summary_df_cat, woe_detailed_df_cat, woe_bins_cat, woe_bin_dict_cat = get_bin_information(sal_application_train_cat, binning_process_cat, config_func, config_general_info)
    data_train_woe_cat, data_test_woe_cat, data_oot_nc_woe_cat, data_oot_c_woe_cat = woe_manual_combined_no_change(binning_process_cat, sal_application_train_cat,
                                                                  sal_application_test[cat_features],
                                                                  sal_noot[cat_features],
                                                                  sal_oot[cat_features],
                                                                  config_func,
                                                                  config_general_info)
   
    #Merging_categorical_numerical################################################################
    data_oot_c_woe_num['loan'].value_counts()
   
    data_train_woe = pd.merge(data_train_woe_cat, data_train_woe_num, on=['COMP_APPL_ID','loan'])
    data_test_woe = pd.merge(data_test_woe_cat, data_test_woe_num, on=['COMP_APPL_ID','loan'])
    data_oot_nc_woe = pd.merge(data_oot_nc_woe_cat, data_oot_nc_woe_num, on=['COMP_APPL_ID','loan'])
    data_oot_c_woe = pd.merge(data_oot_c_woe_cat, data_oot_c_woe_num, on=['COMP_APPL_ID','loan'])

    data_oot_c_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\data_oot_c_woe_May_17.csv', index=False)
    data_oot_nc_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\data_oot_nc_woe_May_17.csv', index=False)
    data_test_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\data_test_woe_May_17.csv', index=False)
    data_train_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\data_train_woe_May_17.csv', index=False)
   
    woe_detailed_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\woe_detailed_df_May_17.csv', index=False)    
    woe_detailed_df_cat.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\CIBIL\Self\woe_detailed_df_cat_May_17.csv', index=False)
    #df_psi.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\df_psi_May_10.csv', index=False)


   
    #vif to get list of columns to be dropped, missing values needs to be handled
    #reload dataframe again as we dont need to handle missing values for other steps
    identify_correlation(sal_application_train, config)
    sal_application_train = missing_values_table(sal_application_train)
    #2. Identify multicollinetrarity
    sal_application_train=handle_missing_value(sal_application_train)
    calculate_vif(sal_application_train,config)
   
# =============================================================================
#self-employed model

    cols=pd.read_excel(r'C:\Users\vishwesh kumar\Videos\LIC\LIC models_May_10\Master Sheet_May_5_v2.1.xlsx' , sheet_name='Master Variable Sheet 2')
    feat1=cols[cols['Analysed']==1]['Feature'].values.tolist()
    feat2=cols[cols['Analysed']==1]['Next best'].dropna().values.tolist()
    feat=list(set(feat1+feat2))
   
    self_model=self_model[feat+['loan','COMP_APPL_ID','FIRST_DISB_DATE']]
   
    self_oot, self_noot = oot_split(self_model, '2016-12-31')
    self_oot, self_noot= del_extra_cols(self_oot, self_noot)
    self_oot = missing_value_filter(self_oot)
    self_noot = missing_value_filter(self_noot)

    self_application_train, self_application_test, y_train, y_test = train_split(self_noot, config['TEST_SPLIT'])
   
    self_oot['loan'].value_counts()
    self_application_train = get_iv(self_application_train, 0.01)
   
    #drop vif columns and generate data again
    df_psi=calc_psi(self_oot, self_application_train, self_application_test)
   
    df_psi[(df_psi['psi_1_tt']>0.4)|(df_psi['psi_2_tt']>0.4)]
    df_psi[(df_psi['psi_1_tt']>0.4)&(df_psi['psi_2_tt']>0.4)]
   



    #woe codes
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    self_application_train_num = self_application_train.select_dtypes(include=numerics)
   
   
    self_application_train_cat = self_application_train.select_dtypes(include=['object', 'category'])
    self_application_train_cat['loan']=self_application_train['loan']
    self_application_train_cat['COMP_APPL_ID']=self_application_train['COMP_APPL_ID']
   
    #column list
    num_features=self_application_train_num.columns.tolist()
    cat_features=self_application_train_cat.columns.tolist()
   
    #Numerical columns##############################################
    binning_process = find_optimal_bins(self_application_train_num, config_func, config_general_info)
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(self_application_train_num, binning_process, config_func, config_general_info)
   
    manually_adjusted_bins = adjust_bins_interactively(self_application_train_num, config_func, config_general_info, woe_bin_dict)
   
    binning_process=apply_manually_adjusted_bins(self_application_train_num, manually_adjusted_bins, config_func, config_general_info)
   
    woe_summary_df, woe_detailed_df, woe_bins, woe_bin_dict = get_bin_information(self_application_train_num, binning_process, config_func, config_general_info)
    data_train_woe_num, data_test_woe_num, data_oot_nc_woe_num, data_oot_c_woe_num = woe_manual_combined_no_change(binning_process,self_application_train_num,
                                                                  self_application_test[num_features],
                                                                  self_noot[num_features],
                                                                  self_oot[num_features],
                                                                  config_func,
                                                                  config_general_info)
   
    data_oot_c_woe_num['loan'].value_counts()
    data_oot_c_woe_num['loan'].value_counts(dropna=False)

    #Categorical columns##############################################
    binning_process_cat = find_optimal_bins(self_application_train_cat, config_func, config_general_info)
    woe_summary_df_cat, woe_detailed_df_cat, woe_bins_cat, woe_bin_dict_cat = get_bin_information(self_application_train_cat, binning_process_cat, config_func, config_general_info)
    data_train_woe_cat, data_test_woe_cat, data_oot_nc_woe_cat, data_oot_c_woe_cat = woe_manual_combined_no_change(binning_process_cat, self_application_train_cat,
                                                                  self_application_test[cat_features],
                                                                  self_noot[cat_features],
                                                                  self_oot[cat_features],
                                                                  config_func,
                                                                  config_general_info)
   
    #Merging_categorical_numerical################################################################
#    data_train_woe_cat.drop(columns=['loan'],inplace=True)
#    data_test_woe_cat.drop(columns=['loan'],inplace=True)
#    data_oot_nc_woe_cat.drop(columns=['loan'],inplace=True)
#    data_oot_c_woe_cat.drop(columns=['loan'],inplace=True)
    data_oot_c_woe_num['loan'].value_counts()
   
    data_train_woe = pd.merge(data_train_woe_cat, data_train_woe_num, on=['COMP_APPL_ID','loan'])
    data_test_woe = pd.merge(data_test_woe_cat, data_test_woe_num, on=['COMP_APPL_ID','loan'])
    data_oot_nc_woe = pd.merge(data_oot_nc_woe_cat, data_oot_nc_woe_num, on=['COMP_APPL_ID','loan'])
    data_oot_c_woe = pd.merge(data_oot_c_woe_cat, data_oot_c_woe_num, on=['COMP_APPL_ID','loan'])

    data_oot_c_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\data_oot_c_woe_self_May_10.csv', index=False)
    data_oot_nc_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\data_oot_nc_woe_self_May_10.csv', index=False)
    data_test_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\data_test_woe_self_May_10.csv', index=False)
    data_train_woe.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\data_train_woe_self_May_10.csv', index=False)
   
    woe_detailed_df.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\woe_detailed_df_self_May_10.csv', index=False)    
    woe_detailed_df_cat.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\woe_detailed_df_cat_self_May_10.csv', index=False)
    #df_psi.to_csv(r'C:\Users\vishwesh kumar\Videos\LIC\EDA_op\df_psi.csv', index=False)


   
    #vif to get list of columns to be dropped, missing values needs to be handled
    #reload dataframe again as we dont need to handle missing values for other steps
    identify_correlation(self_application_train, config)
    self_application_train = missing_values_table(self_application_train)
    #2. Identify multicollinetrarity
    self_application_train=handle_missing_value(self_application_train)
    calculate_vif(self_application_train,config)
   
# ===============================drop vif & psi for self employed==============================================

lst_vif_self = ['AGE',
'FEMALE_INCLUSION',
'L_B_GUAR_COAP_FLAG_C_count',
'L_B_GUAR_COAP_FLAG_C_count_norm',
'L_B_GENDER_Female_count_norm',
'L_B_EDUCATIONAL_QUALIFICATION_grp_OTHER_count_norm',
'L_B_EMPLOYEMENT_SLAB_grp_Salaried_count',
'L_B_AGE_mean',
'L_B_AGE_max',
'L_B_FEMALE_INCLUSION_mean',
'L_B_FEMALE_INCLUSION_max',
'L_B_income_prop_ratio_mean',
'inc_prop_ratio_loan_level',
'L_B_EDUCATIONAL_QUALIFICATION_grp_GRADUATE_count',
'L_B_MATURITY_AGE_mean',
'L_B_Area_mod_count',
'L_B_income_prop_ratio_max',
'L_B_EMPLOYEMENT_SLAB_grp_Self-Employed_count_norm',
'L_B_GROSS_MONTHLY_OTHER_INCOME_mean',
'L_B_MATURITY_AGE_min',
'L_B_BUSS_PROF_NATURE_grp_Others_count_norm',
'L_B_NET_MONTHLY_INCOME_max',
'L_B_MATURITY_AGE_max',
'L_B_EMPLOYEMENT_SLAB_grp_Self-Employed_count',
'PROP_VALUE',
'L_B_INDUSTRY_TYPE_grp_Others_count',
'L_B_GENDER_Female_count',
'L_B_COMPANY_TYPE_grp_CEHL_count_norm',
'L_B_COMPANY_TYPE_grp_CAP4_count_norm',
'L_B_NET_MONTHLY_INCOME_sum',
'L_B_GUAR_COAP_FLAG_P_count_norm',
'L_B_GROSS_MONTHLY_OTHER_INCOME_max',
'L_B_EDUCATIONAL_QUALIFICATION_grp_GRADUATE_count_norm',
'L_B_COMPANY_TYPE_grp_Unapproved Company_count_norm',
'MATURITY_AGE',
'L_B_MARITAL_STATUS_grp_Married_count',
'L_B_INDUSTRY_TYPE_grp_Unlisted Co_count_norm',
'C_P_datediff_sancmin',
'L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count',
'L_B_AGE_min',
'L_B_NET_MONTHLY_INCOME_mean',
'L_B_EDUCATIONAL_QUALIFICATION_grp_PROFESSIONAL_count',
'L_B_EDUCATIONAL_QUALIFICATION_grp_HSC_count_norm',
'L_B_GENDER_Male_count_norm',
'L_B_EMPLOYEMENT_SLAB_grp_Salaried_count_norm',
'L_B_COMPANY_TYPE_grp_Proprietorship Firm_count',
'L_B_EDUCATIONAL_QUALIFICATION_grp_DIPLOMA_count',
'L_B_EDUCATIONAL_QUALIFICATION_grp_SSC_count',
'GROSS_MONTHLY_OTHER_INCOME',
'L_B_COMPANY_TYPE_grp_Individual_count_norm',
'L_B_INDUSTRY_TYPE_grp_Others_count_norm',
'L_B_GROSS_MONTHLY_OTHER_INCOME_min',
'L_B_BUSS_PROF_NATURE_grp_Others_count',
'L_B_income_prop_ratio_min']
lst_psi_self = ['pricepersqft_builtup', 'LTV','L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count_norm',
                'L_B_INDUSTRY_TYPE_grp_Unlisted Co_count']
#lst_bin=['L_B_EDUCATIONAL_QUALIFICATION_grp_PROFESSIONAL_count_norm']
self_application_train.drop(lst_vif_self+lst_psi_self, axis = 1, inplace = True)
self_application_test = self_application_test[self_application_train.columns]
self_oot = self_oot[self_application_train.columns]
self_noot = self_noot[self_application_train.columns]


# ===============================drop vif & psi for salaried==============================================
lst_vif = [
       'FEMALE_INCLUSION',
'L_B_FEMALE_INCLUSION_mean',
'L_B_FEMALE_INCLUSION_max',
'L_B_AGE_mean',
'L_B_GROSS_MONTHLY_OTHER_INCOME_mean',
'L_B_GENDER_Male_count_norm',
'L_B_MATURITY_AGE_min',
'L_B_NET_MONTHLY_INCOME_max',
'L_B_MATURITY_AGE_mean',
'L_B_NET_MONTHLY_INCOME_mean',
'DECLARED_PROPERTY_VAL',
'L_B_GROSS_MONTHLY_OTHER_INCOME_sum',
'L_B_INDUSTRY_TYPE_grp_Others_count_norm',
'MATURITY_AGE',
'L_B_GENDER_Female_count',
'GROSS_MONTHLY_OTHER_INCOME',
'L_B_APPLICATION_TYPE_New_count_norm',
'L_B_NET_MONTHLY_INCOME_sum',
'C_P_datediff_sancmin',
'L_B_INDUSTRY_TYPE_grp_Others_count',
'Area_mod',
'L_B_FEMALE_INCLUSION_min',
'L_B_COMPANY_TYPE_grp_CEHL_count_norm',
'L_B_GROSS_MONTHLY_OTHER_INCOME_max',
'L_B_EMPLOYEMENT_SLAB_grp_Salaried_count',
'L_B_EDUCATIONAL_QUALIFICATION_grp_PG_count',
'L_B_COMPANY_TYPE_grp_CAP4_count_norm',
'L_B_EDUCATIONAL_QUALIFICATION_grp_HSC_count',
'L_B_INDUSTRY_TYPE_grp_Govt_count_norm',
'L_B_AGE_min']

lst_psi=['L_B_EDUCATIONAL_QUALIFICATION_grp_HSC_count_norm']


sal_application_train.drop(lst_vif+lst_psi, axis = 1, inplace = True)

sal_application_test = sal_application_test[sal_application_train.columns]
sal_oot = sal_oot[sal_application_train.columns]
sal_noot = sal_noot[sal_application_train.columns]
# =============================================================================
#
# my_report = sv.analyze(df2, target_feat = 'loan', pairwise_analysis="off")
# my_report.show_html(filepath='SWEETVIZ_REPORT_cibil_selfemp.html') # Default arguments will generate to "SWEETVIZ_REPORT.html"        
# =============================================================================